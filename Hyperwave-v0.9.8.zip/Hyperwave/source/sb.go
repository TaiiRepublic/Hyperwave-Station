package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"
)

// SB is Station's own connection to Streamer.bot's WebSocket Server. It posts chat replies
// (SendMessage), runs the Twitch-clip action (DoAction), and reads YouTube chat for the deck.
type SB struct {
	a *App

	mu      sync.Mutex
	gen     int
	ws      *wsConn
	authed  bool
	pending map[string]chan sbResp
	seq     int
	status  string
}

type sbResp struct {
	OK    bool
	Error string
	Raw   json.RawMessage
}

func (s *SB) Status() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.status
}

func (s *SB) Connected() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.ws != nil
}

func (s *SB) alive(g int) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.gen == g
}

func (s *SB) set(g int, st string) {
	s.mu.Lock()
	if s.gen == g {
		s.status = st
	}
	s.mu.Unlock()
}

// wanted is true when some setting needs Streamer.bot.
func sbWanted(c Config) bool {
	return c.SBEnabled
}

func (s *SB) Restart() {
	s.mu.Lock()
	s.gen++
	g := s.gen
	if s.ws != nil {
		s.ws.Close()
		s.ws = nil
	}
	s.status = "off"
	s.mu.Unlock()
	if !sbWanted(s.a.st.Get()) {
		return
	}
	go func() {
		delay := 3 * time.Second
		for s.alive(g) {
			s.set(g, "connecting")
			err := s.run(g)
			if !s.alive(g) {
				return
			}
			msg := "can't reach Streamer.bot"
			if err != nil {
				msg = err.Error()
			}
			s.set(g, msg)
			time.Sleep(delay)
			if delay < 20*time.Second {
				delay += 3 * time.Second
			}
		}
	}()
}

func sbHash(s string) string {
	h := sha256.Sum256([]byte(s))
	return base64.StdEncoding.EncodeToString(h[:])
}

func (s *SB) run(g int) error {
	c := s.a.st.Get()
	host := strings.TrimSpace(c.SBHost)
	if host == "" {
		host = "127.0.0.1"
	}
	port := c.SBPort
	if port == 0 {
		port = 8080
	}
	ws, err := wsDial(fmt.Sprintf("ws://%s:%d/", host, port))
	if err != nil {
		return errors.New("can't reach Streamer.bot. Start its WebSocket Server (Servers/Clients → WebSocket Server)")
	}
	defer ws.Close()
	go func() {
		for s.alive(g) {
			time.Sleep(time.Second)
		}
		ws.Close()
	}()
	s.mu.Lock()
	s.ws, s.authed = ws, false
	s.pending = map[string]chan sbResp{}
	s.mu.Unlock()
	defer func() {
		s.mu.Lock()
		if s.ws == ws {
			s.ws = nil
		}
		for _, ch := range s.pending {
			close(ch)
		}
		s.pending = map[string]chan sbResp{}
		s.mu.Unlock()
	}()

	ready := func() {
		s.set(g, "connected")
		if c.DeckYouTube {
			s.send(map[string]any{"request": "Subscribe", "id": "hws-sub", "events": map[string]any{"YouTube": []string{"Message"}}})
		}
	}
	gotHello := false
	go func() { // older Streamer.bot builds don't send Hello
		time.Sleep(1500 * time.Millisecond)
		s.mu.Lock()
		hello := gotHello
		s.mu.Unlock()
		if !hello && s.alive(g) {
			ready()
		}
	}()
	for {
		ws.conn.SetReadDeadline(time.Now().Add(10 * time.Minute))
		raw, err := ws.ReadMessage()
		if err != nil {
			return errors.New("lost connection to Streamer.bot")
		}
		var m map[string]json.RawMessage
		if json.Unmarshal(raw, &m) != nil {
			continue
		}
		var req, id, status string
		json.Unmarshal(m["request"], &req)
		json.Unmarshal(m["id"], &id)
		json.Unmarshal(m["status"], &status)
		if req == "Hello" {
			s.mu.Lock()
			gotHello = true
			s.mu.Unlock()
			var h struct {
				Auth *struct {
					Challenge string `json:"challenge"`
					Salt      string `json:"salt"`
				} `json:"authentication"`
			}
			json.Unmarshal(raw, &h)
			if h.Auth != nil {
				if c.SBPassword == "" {
					return errors.New("Streamer.bot wants its WebSocket password. Type it in under OBS & Deck → Streamer.bot")
				}
				auth := sbHash(sbHash(c.SBPassword+h.Auth.Salt) + h.Auth.Challenge)
				s.send(map[string]any{"request": "Authenticate", "id": "hws-auth", "authentication": auth})
				continue
			}
			ready()
			continue
		}
		if id == "hws-auth" {
			if status != "ok" {
				return errors.New("Streamer.bot rejected the password")
			}
			s.mu.Lock()
			s.authed = true
			s.mu.Unlock()
			ready()
			continue
		}
		if id != "" {
			s.mu.Lock()
			ch := s.pending[id]
			delete(s.pending, id)
			s.mu.Unlock()
			if ch != nil {
				var e struct {
					Error string `json:"error"`
				}
				json.Unmarshal(raw, &e)
				ch <- sbResp{status == "ok" || status == "", e.Error, raw}
				close(ch)
			}
			continue
		}
		if ev, ok := m["event"]; ok {
			var e struct {
				Source string `json:"source"`
				Type   string `json:"type"`
			}
			json.Unmarshal(ev, &e)
			s.onEvent(e.Source, e.Type, m["data"])
		}
	}
}

func (s *SB) send(v any) error {
	s.mu.Lock()
	ws := s.ws
	s.mu.Unlock()
	if ws == nil {
		return errors.New("not connected to Streamer.bot")
	}
	b, _ := json.Marshal(v)
	return ws.WriteText(b)
}

func (s *SB) request(v map[string]any) (sbResp, error) {
	s.mu.Lock()
	if s.ws == nil {
		s.mu.Unlock()
		if !s.a.st.Get().SBEnabled {
			return sbResp{}, errors.New("Streamer.bot isn't turned on. Turn it on under OBS & Deck → Streamer.bot")
		}
		return sbResp{}, errors.New("not connected to Streamer.bot (" + s.status + ")")
	}
	s.seq++
	id := fmt.Sprintf("hws-%d", s.seq)
	ch := make(chan sbResp, 1)
	s.pending[id] = ch
	s.mu.Unlock()
	v["id"] = id
	if err := s.send(v); err != nil {
		return sbResp{}, err
	}
	select {
	case r, ok := <-ch:
		if !ok {
			return sbResp{}, errors.New("lost connection to Streamer.bot")
		}
		return r, nil
	case <-time.After(6 * time.Second):
		s.mu.Lock()
		delete(s.pending, id)
		s.mu.Unlock()
		return sbResp{}, errors.New("Streamer.bot didn't answer in time")
	}
}

// SendMessage posts in the broadcaster's chat on twitch, kick or youtube.
func (s *SB) SendMessage(platform, msg string) error {
	r, err := s.request(map[string]any{"request": "SendMessage", "platform": platform, "message": msg, "bot": false, "internal": false})
	if err != nil {
		return err
	}
	if !r.OK {
		e := r.Error
		if e == "" {
			e = "it said no"
		}
		if strings.Contains(strings.ToLower(e), "auth") {
			e += ". Turn on Authentication for Streamer.bot's WebSocket Server and type the password into Hyperwave"
		}
		return errors.New("Streamer.bot couldn't send it: " + e)
	}
	return nil
}

// RunAction runs a Streamer.bot action by name (used for Twitch clips).
func (s *SB) RunAction(name string, args map[string]any) error {
	r, err := s.request(map[string]any{"request": "DoAction", "action": map[string]any{"name": name}, "args": args})
	if err != nil {
		return err
	}
	if !r.OK {
		return fmt.Errorf("Streamer.bot couldn't run the action %q. Check an action with exactly that name exists and is enabled", name)
	}
	return nil
}

func (s *SB) onEvent(source, kind string, data json.RawMessage) {
	if source != "YouTube" || kind != "Message" {
		return
	}
	var d struct {
		EventID   string `json:"eventId"`
		MessageID string `json:"messageId"`
		Message   any    `json:"message"`
		Text      string `json:"text"`
		User      struct {
			ID     string `json:"id"`
			Name   string `json:"name"`
			Avatar string `json:"profileImageUrl"`
			Owner  bool   `json:"isOwner"`
			Mod    bool   `json:"isModerator"`
		} `json:"user"`
	}
	json.Unmarshal(data, &d)
	text, _ := d.Message.(string)
	if text == "" {
		text = d.Text
	}
	if text == "" {
		return
	}
	key := "yt:" + d.EventID + d.MessageID
	if key == "yt:" {
		key = ""
	}
	s.a.feed.Add(FeedMsg{Platform: "youtube", User: d.User.Name, Avatar: d.User.Avatar, Parts: []FeedPart{{Text: text}}, Mod: d.User.Mod, Owner: d.User.Owner}, key)
}

// ---------------- TikTok through TikFinity (for the deck's chat) ----------------

type TikFinity struct {
	a      *App
	mu     sync.Mutex
	gen    int
	status string
}

func (t *TikFinity) Status() string {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.status
}

func (t *TikFinity) Restart() {
	t.mu.Lock()
	t.gen++
	g := t.gen
	t.status = "off"
	t.mu.Unlock()
	c := t.a.st.Get()
	if !c.DeckTikTok {
		return
	}
	port := c.TikFinityPort
	if port == 0 {
		port = 21213
	}
	alive := func() bool { t.mu.Lock(); defer t.mu.Unlock(); return t.gen == g }
	set := func(s string) {
		t.mu.Lock()
		if t.gen == g {
			t.status = s
		}
		t.mu.Unlock()
	}
	go func() {
		for alive() {
			set("connecting")
			ws, err := wsDial(fmt.Sprintf("ws://127.0.0.1:%d/", port))
			if err != nil {
				set("can't reach TikFinity. Open it and connect it to your LIVE")
				time.Sleep(8 * time.Second)
				continue
			}
			set("connected")
			go func() {
				for alive() {
					time.Sleep(time.Second)
				}
				ws.Close()
			}()
			for {
				raw, err := ws.ReadMessage()
				if err != nil {
					break
				}
				var e struct {
					Event string `json:"event"`
					Data  struct {
						MsgID   string `json:"msgId"`
						Nick    string `json:"nickname"`
						Unique  string `json:"uniqueId"`
						Comment string `json:"comment"`
						Avatar  string `json:"profilePictureUrl"`
						Mod     bool   `json:"isModerator"`
					} `json:"data"`
				}
				if json.Unmarshal(raw, &e) != nil || e.Event != "chat" || e.Data.Comment == "" {
					continue
				}
				name := e.Data.Nick
				if name == "" {
					name = e.Data.Unique
				}
				key := ""
				if e.Data.MsgID != "" {
					key = "tt:" + e.Data.MsgID
				}
				t.a.feed.Add(FeedMsg{Platform: "tiktok", User: name, Avatar: e.Data.Avatar, Parts: []FeedPart{{Text: e.Data.Comment}}, Mod: e.Data.Mod}, key)
			}
			ws.Close()
			if alive() {
				set("lost TikFinity, retrying")
				time.Sleep(5 * time.Second)
			}
		}
	}()
}
