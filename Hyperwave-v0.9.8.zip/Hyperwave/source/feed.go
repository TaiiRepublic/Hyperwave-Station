package main

import (
	"regexp"
	"strings"
	"sync"
	"time"
)

// Feed is the combined chat shown on the Hyperwave Deck. Station reads chat itself (Twitch and
// Kick anonymously, YouTube through Streamer.bot, TikTok through TikFinity) so the deck works on
// any device, including a phone on your Wi-Fi.
type Feed struct {
	mu   sync.Mutex
	seq  int
	msgs []FeedMsg
	seen map[string]bool
}

type FeedPart struct {
	Text string `json:"t,omitempty"`
	Img  string `json:"i,omitempty"`
}

type FeedMsg struct {
	ID       int        `json:"id"`
	Platform string     `json:"platform"`
	User     string     `json:"user"`
	Color    string     `json:"color,omitempty"`
	Avatar   string     `json:"avatar,omitempty"`
	Parts    []FeedPart `json:"parts"`
	Mod      bool       `json:"mod,omitempty"`
	Owner    bool       `json:"owner,omitempty"`
	Self     bool       `json:"self,omitempty"` // sent from the deck
	At       int64      `json:"at"`
	key      string
}

const feedMax = 300

func (f *Feed) Add(m FeedMsg, dedupeKey string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.seen == nil {
		f.seen = map[string]bool{}
	}
	if dedupeKey != "" {
		if f.seen[dedupeKey] {
			return
		}
		f.seen[dedupeKey] = true
		if len(f.seen) > 2000 {
			f.seen = map[string]bool{}
		}
	}
	f.seq++
	m.ID = f.seq
	if m.At == 0 {
		m.At = time.Now().UnixMilli()
	}
	m.key = dedupeKey
	f.msgs = append(f.msgs, m)
	if len(f.msgs) > feedMax {
		f.msgs = f.msgs[len(f.msgs)-feedMax:]
	}
}

func (f *Feed) After(id int) []FeedMsg {
	f.mu.Lock()
	defer f.mu.Unlock()
	out := []FeedMsg{}
	for _, m := range f.msgs {
		if m.ID > id {
			out = append(out, m)
		}
	}
	if len(out) > 150 {
		out = out[len(out)-150:]
	}
	return out
}

func (f *Feed) Last() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.seq
}

// twitchParts splits a message into text and emote images using the IRC emotes tag
// ("25:0-4,12-16/1902:6-10"); positions count Unicode characters.
func twitchParts(text, emotes string) []FeedPart {
	if emotes == "" {
		return []FeedPart{{Text: text}}
	}
	runes := []rune(text)
	type span struct {
		s, e int
		id   string
	}
	var spans []span
	for _, g := range strings.Split(emotes, "/") {
		id, ranges, ok := strings.Cut(g, ":")
		if !ok {
			continue
		}
		for _, r := range strings.Split(ranges, ",") {
			a, b, ok := strings.Cut(r, "-")
			if !ok {
				continue
			}
			s, e := atoiSafe(a), atoiSafe(b)
			if s >= 0 && e >= s && e < len(runes) {
				spans = append(spans, span{s, e, id})
			}
		}
	}
	// sort by start
	for i := 1; i < len(spans); i++ {
		for j := i; j > 0 && spans[j].s < spans[j-1].s; j-- {
			spans[j], spans[j-1] = spans[j-1], spans[j]
		}
	}
	var out []FeedPart
	pos := 0
	for _, sp := range spans {
		if sp.s < pos {
			continue
		}
		if sp.s > pos {
			out = append(out, FeedPart{Text: string(runes[pos:sp.s])})
		}
		out = append(out, FeedPart{Img: "https://static-cdn.jtvnw.net/emoticons/v2/" + sp.id + "/default/dark/2.0", Text: string(runes[sp.s : sp.e+1])})
		pos = sp.e + 1
	}
	if pos < len(runes) {
		out = append(out, FeedPart{Text: string(runes[pos:])})
	}
	return out
}

var kickEmote = regexp.MustCompile(`\[emote:(\d+):([^\]]*)\]`)

func kickParts(text string) []FeedPart {
	var out []FeedPart
	last := 0
	for _, m := range kickEmote.FindAllStringSubmatchIndex(text, -1) {
		if m[0] > last {
			out = append(out, FeedPart{Text: text[last:m[0]]})
		}
		out = append(out, FeedPart{Img: "https://files.kick.com/emotes/" + text[m[2]:m[3]] + "/fullsize", Text: text[m[4]:m[5]]})
		last = m[1]
	}
	if last < len(text) {
		out = append(out, FeedPart{Text: text[last:]})
	}
	if len(out) == 0 {
		out = []FeedPart{{Text: text}}
	}
	return out
}

func atoiSafe(s string) int {
	n := 0
	if s == "" {
		return -1
	}
	for _, c := range s {
		if c < '0' || c > '9' {
			return -1
		}
		n = n*10 + int(c-'0')
	}
	return n
}
