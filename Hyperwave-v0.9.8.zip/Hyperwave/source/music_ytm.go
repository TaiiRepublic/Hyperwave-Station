package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// YTMusic drives the free "YouTube Music" desktop app (github.com/th-ch/youtube-music, also called
// Pear Desktop) through its API Server plugin. It does nearly everything Spotify does: now playing,
// play/pause/skip/back, volume, shuffle, repeat, search, and real song requests into its queue.
// No YouTube Premium needed.

const ytmClientID = "hyperwave-station"

type YTMusic struct {
	a    *App
	http *http.Client

	mu        sync.Mutex
	status    string
	authState string // "", waiting, done, error
	authMsg   string
	polls     int
	volume    int
	repeat    string
	lastVideo string
}

func (y *YTMusic) ID() string   { return "ytmusic" }
func (y *YTMusic) Name() string { return "YouTube Music" }
func (y *YTMusic) Ready() bool  { return true } // it says itself if it needs Allow
func (y *YTMusic) Caps() Caps {
	return Caps{Play: true, Pause: true, Next: true, Prev: true, Volume: true, Shuffle: true, Repeat: true,
		Queue: true, UpNext: true, Search: true, Progress: true}
}

func (y *YTMusic) client() *http.Client {
	if y.http == nil {
		y.http = &http.Client{Timeout: 8 * time.Second}
	}
	return y.http
}

func (y *YTMusic) base() string {
	c := y.a.st.Get()
	host := strings.TrimSpace(c.YTMHost)
	if host == "" {
		host = "127.0.0.1"
	}
	port := c.YTMPort
	if port == 0 {
		port = 26538
	}
	return "http://" + net.JoinHostPort(host, strconv.Itoa(port))
}

var errYTMAuth = errors.New("YouTube Music needs you to allow Hyperwave. Click Connect YouTube Music on the dashboard, then Allow in YouTube Music")

func (y *YTMusic) setStatus(s string) {
	y.mu.Lock()
	y.status = s
	y.mu.Unlock()
}

func (y *YTMusic) Status() map[string]any {
	y.mu.Lock()
	defer y.mu.Unlock()
	return map[string]any{"status": y.status, "auth": y.authState, "authMsg": y.authMsg, "hasToken": y.a.st.Get().YTMToken != ""}
}

// do calls the API. 204 gives (204, nil, nil).
func (y *YTMusic) do(method, path string, body any) (int, []byte, error) {
	var rdr io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rdr = bytes.NewReader(b)
	}
	req, _ := http.NewRequest(method, y.base()+path, rdr)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if tok := y.a.st.Get().YTMToken; tok != "" {
		req.Header.Set("Authorization", "Bearer "+tok)
	}
	res, err := y.client().Do(req)
	if err != nil {
		y.setStatus("not open")
		return 0, nil, &notOpenErr{"YouTube Music isn't open. Open it and turn on its API Server plugin (Plugins → API Server)"}
	}
	defer res.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(res.Body, 8<<20))
	if res.StatusCode == 401 || res.StatusCode == 403 {
		y.setStatus("needs allow")
		return res.StatusCode, b, errYTMAuth
	}
	if res.StatusCode >= 400 {
		return res.StatusCode, b, fmt.Errorf("YouTube Music answered %d", res.StatusCode)
	}
	y.setStatus("connected")
	return res.StatusCode, b, nil
}

// Connect asks YouTube Music for access. YouTube Music pops up an Allow / Deny box.
func (y *YTMusic) Connect() {
	y.mu.Lock()
	if y.authState == "waiting" {
		y.mu.Unlock()
		return
	}
	y.authState, y.authMsg = "waiting", "Click Allow in the YouTube Music window"
	y.mu.Unlock()
	go func() {
		cl := &http.Client{Timeout: 2 * time.Minute}
		res, err := cl.Post(y.base()+"/auth/"+ytmClientID, "application/json", nil)
		state, msg := "error", ""
		switch {
		case err != nil:
			msg = "Can't reach YouTube Music. Open it, go to Plugins and turn on API Server, then try again."
		case res.StatusCode == 403:
			msg = "YouTube Music said Deny. Click Connect again and choose Allow."
		case res.StatusCode != 200:
			msg = fmt.Sprintf("YouTube Music answered %d. Check the port in its API Server plugin settings.", res.StatusCode)
		default:
			var r struct {
				Token string `json:"accessToken"`
			}
			json.NewDecoder(res.Body).Decode(&r)
			if r.Token == "" {
				msg = "YouTube Music didn't send a key. Update YouTube Music and try again."
			} else {
				y.a.st.Update(func(c *Config) { c.YTMToken = r.Token })
				state, msg = "done", "Connected"
				y.a.poke()
			}
		}
		if res != nil {
			res.Body.Close()
		}
		y.mu.Lock()
		y.authState, y.authMsg = state, msg
		y.mu.Unlock()
	}()
}

type ytmSong struct {
	Title    string  `json:"title"`
	Artist   string  `json:"artist"`
	Album    *string `json:"album"`
	Image    *string `json:"imageSrc"`
	Paused   *bool   `json:"isPaused"`
	Duration float64 `json:"songDuration"`
	Elapsed  float64 `json:"elapsedSeconds"`
	VideoID  string  `json:"videoId"`
	URL      string  `json:"url"`
}

func (y *YTMusic) Poll() (*Snapshot, error) {
	code, b, err := y.do("GET", "/api/v1/song", nil)
	if err != nil {
		return nil, err
	}
	y.mu.Lock()
	y.polls++
	extra := y.polls%3 == 1
	y.mu.Unlock()
	if extra { // volume and repeat change rarely
		if _, vb, err := y.do("GET", "/api/v1/volume", nil); err == nil {
			var v struct {
				State float64 `json:"state"`
			}
			if json.Unmarshal(vb, &v) == nil {
				y.mu.Lock()
				y.volume = int(v.State + .5)
				y.mu.Unlock()
			}
		}
		if _, rb, err := y.do("GET", "/api/v1/repeat-mode", nil); err == nil {
			var v struct {
				Mode *string `json:"mode"`
			}
			if json.Unmarshal(rb, &v) == nil && v.Mode != nil {
				y.mu.Lock()
				y.repeat = map[string]string{"NONE": "off", "ALL": "context", "ONE": "track"}[*v.Mode]
				y.mu.Unlock()
			}
		}
	}
	if code == 204 || len(b) == 0 {
		return nil, nil
	}
	var s ytmSong
	if err := json.Unmarshal(b, &s); err != nil || (s.Title == "" && s.VideoID == "") {
		return nil, nil
	}
	t := &TrackView{ID: s.VideoID, URI: "ytm:" + s.VideoID, Title: s.Title, Artist: s.Artist, Duration: int(s.Duration * 1000),
		Link: "https://music.youtube.com/watch?v=" + s.VideoID}
	if s.Album != nil {
		t.Album = *s.Album
	}
	if s.Image != nil {
		t.Art = *s.Image
	}
	y.mu.Lock()
	y.lastVideo = s.VideoID
	snap := &Snapshot{Playing: s.Paused == nil || !*s.Paused, Track: t, Progress: int(s.Elapsed * 1000), Device: "YouTube Music",
		Volume: y.volume, Repeat: y.repeat}
	y.mu.Unlock()
	return snap, nil
}

func (y *YTMusic) Control(cmd, arg string) error {
	var err error
	switch cmd {
	case "play":
		_, _, err = y.do("POST", "/api/v1/play", nil)
	case "pause":
		_, _, err = y.do("POST", "/api/v1/pause", nil)
	case "toggle":
		_, _, err = y.do("POST", "/api/v1/toggle-play", nil)
	case "next":
		_, _, err = y.do("POST", "/api/v1/next", nil)
	case "prev":
		_, _, err = y.do("POST", "/api/v1/previous", nil)
	case "volume":
		n, _ := strconv.Atoi(arg)
		_, _, err = y.do("POST", "/api/v1/volume", map[string]any{"volume": n})
		if err == nil {
			y.mu.Lock()
			y.volume = n
			y.mu.Unlock()
		}
	case "shuffle": // YouTube Music shuffles the queue once rather than switching a mode
		_, _, err = y.do("POST", "/api/v1/shuffle", nil)
	case "repeat":
		order := []string{"off", "context", "track"} // the repeat button goes off → all → one
		y.mu.Lock()
		cur := y.repeat
		y.mu.Unlock()
		ci, ti := 0, 0
		for i, m := range order {
			if m == cur {
				ci = i
			}
			if m == arg {
				ti = i
			}
		}
		if n := (ti - ci + 3) % 3; n > 0 {
			_, _, err = y.do("POST", "/api/v1/switch-repeat", map[string]any{"iteration": n})
			if err == nil {
				y.mu.Lock()
				y.repeat = arg
				y.mu.Unlock()
			}
		}
	default:
		return ErrUnsupported
	}
	return err
}

// ---------- search ----------

var durRe = regexp.MustCompile(`^\d{1,2}:\d{2}(:\d{2})?$`)

func parseClock(s string) int {
	parts := strings.Split(s, ":")
	total := 0
	for _, p := range parts {
		n, err := strconv.Atoi(p)
		if err != nil {
			return 0
		}
		total = total*60 + n
	}
	return total * 1000
}

func runsText(v any) []map[string]any {
	m, _ := v.(map[string]any)
	if m == nil {
		return nil
	}
	rs, _ := m["runs"].([]any)
	out := []map[string]any{}
	for _, r := range rs {
		if rm, ok := r.(map[string]any); ok {
			out = append(out, rm)
		}
	}
	return out
}

func str(v any) string { s, _ := v.(string); return s }

func dig(v any, path ...string) any {
	for _, p := range path {
		m, ok := v.(map[string]any)
		if !ok {
			return nil
		}
		v = m[p]
	}
	return v
}

// findKey returns the first value stored under key anywhere inside v.
func findKey(v any, key string) any {
	switch t := v.(type) {
	case map[string]any:
		if x, ok := t[key]; ok {
			return x
		}
		for _, x := range t {
			if r := findKey(x, key); r != nil {
				return r
			}
		}
	case []any:
		for _, x := range t {
			if r := findKey(x, key); r != nil {
				return r
			}
		}
	}
	return nil
}

func lastThumb(v any) string {
	ts, _ := findKey(v, "thumbnails").([]any)
	if len(ts) == 0 {
		return ""
	}
	u := str(dig(ts[len(ts)-1], "url"))
	if strings.HasPrefix(u, "//") {
		u = "https:" + u
	}
	return u
}

type ytmHit struct {
	t     TrackView
	kind  string // ATV (song), OMV (official video), UGC, ...
	label string // "Song", "Video", ...
}

// ytmItem reads one search result (a list row or the "top result" card).
func ytmItem(v map[string]any) *ytmHit {
	var titleRuns, subRuns []map[string]any
	if fc, ok := v["flexColumns"].([]any); ok {
		for i, c := range fc {
			r := runsText(dig(c, "musicResponsiveListItemFlexColumnRenderer", "text"))
			if i == 0 {
				titleRuns = r
			} else {
				subRuns = append(subRuns, r...)
			}
		}
	} else {
		titleRuns = runsText(v["title"])
		subRuns = runsText(v["subtitle"])
	}
	if len(titleRuns) == 0 {
		return nil
	}
	we, _ := dig(v, "overlay", "musicItemThumbnailOverlayRenderer", "content", "musicPlayButtonRenderer", "playNavigationEndpoint", "watchEndpoint").(map[string]any)
	if we == nil && len(titleRuns) > 0 {
		we, _ = dig(titleRuns[0], "navigationEndpoint", "watchEndpoint").(map[string]any)
	}
	if we == nil {
		we, _ = dig(v, "onTap", "watchEndpoint").(map[string]any)
	}
	if we == nil {
		cp := map[string]any{}
		for k, x := range v {
			if k != "menu" {
				cp[k] = x
			}
		}
		we, _ = findKey(cp, "watchEndpoint").(map[string]any)
	}
	vid := str(dig(v, "playlistItemData", "videoId"))
	if vid == "" && we != nil {
		vid = str(we["videoId"])
	}
	if vid == "" {
		return nil
	}
	h := &ytmHit{t: TrackView{ID: vid, URI: "ytm:" + vid, Title: str(titleRuns[0]["text"]), Art: lastThumb(v["thumbnail"]),
		Link: "https://music.youtube.com/watch?v=" + vid}}
	if we != nil {
		h.kind = strings.TrimPrefix(str(dig(we, "watchEndpointMusicSupportedConfigs", "watchEndpointMusicConfig", "musicVideoType")), "MUSIC_VIDEO_TYPE_")
	}
	var artists []string
	for i, r := range subRuns {
		txt := strings.TrimSpace(str(r["text"]))
		if txt == "" || txt == "•" || txt == "&" || txt == "," {
			continue
		}
		page := str(findKey(r["navigationEndpoint"], "pageType"))
		switch {
		case strings.Contains(page, "ARTIST") || strings.Contains(page, "USER_CHANNEL"):
			artists = append(artists, txt)
		case strings.Contains(page, "ALBUM"):
			h.t.Album = txt
		case durRe.MatchString(txt):
			h.t.Duration = parseClock(txt)
		case i == 0 && r["navigationEndpoint"] == nil && len(subRuns) > 2:
			h.label = txt
		}
	}
	h.t.Artist = strings.Join(artists, ", ")
	for _, b := range asList(v["badges"]) {
		if strings.Contains(str(findKey(b, "iconType")), "EXPLICIT") {
			h.t.Explicit = true
		}
	}
	if h.t.Artist == "" { // rows without artist links: "Song • Artist • 3:21"
		for _, r := range subRuns {
			txt := strings.TrimSpace(str(r["text"]))
			if txt != "" && txt != "•" && txt != h.label && !durRe.MatchString(txt) && !strings.Contains(txt, "views") && txt != h.t.Album {
				h.t.Artist = txt
				break
			}
		}
	}
	return h
}

func asList(v any) []any { l, _ := v.([]any); return l }

// collect walks the search answer and returns every song-like result in page order.
func ytmCollect(v any, out *[]*ytmHit) {
	switch t := v.(type) {
	case map[string]any:
		for _, k := range []string{"musicResponsiveListItemRenderer", "musicCardShelfRenderer"} {
			if r, ok := t[k].(map[string]any); ok {
				if h := ytmItem(r); h != nil {
					*out = append(*out, h)
				}
				if k == "musicCardShelfRenderer" { // the top-result card also holds a list of rows
					if c, ok := r["contents"]; ok {
						ytmCollect(c, out)
					}
				}
				return
			}
		}
		// keep page order: tabs → sections → rows
		for _, k := range []string{"contents", "tabs", "tabRenderer", "content", "sectionListRenderer", "musicShelfRenderer", "tabbedSearchResultsRenderer", "itemSectionRenderer"} {
			if x, ok := t[k]; ok {
				ytmCollect(x, out)
			}
		}
	case []any:
		for _, x := range t {
			ytmCollect(x, out)
		}
	}
}

func (y *YTMusic) search(q string) ([]*ytmHit, error) {
	_, b, err := y.do("POST", "/api/v1/search", map[string]any{"query": q})
	if err != nil {
		return nil, err
	}
	var v any
	if err := json.Unmarshal(b, &v); err != nil {
		return nil, err
	}
	var hits []*ytmHit
	ytmCollect(v, &hits)
	// the same song can show up as the top card and again in the list; keep one, with the
	// details from both (the list row has the album and the explicit mark)
	seen := map[string]*ytmHit{}
	out := []*ytmHit{}
	for _, h := range hits {
		if f := seen[h.t.ID]; f != nil {
			f.t.Explicit = f.t.Explicit || h.t.Explicit
			if f.t.Album == "" {
				f.t.Album = h.t.Album
			}
			if f.t.Artist == "" {
				f.t.Artist = h.t.Artist
			}
			if f.t.Duration == 0 {
				f.t.Duration = h.t.Duration
			}
			if f.kind == "" {
				f.kind = h.kind
			}
			continue
		}
		seen[h.t.ID] = h
		out = append(out, h)
	}
	return out, nil
}

// rank prefers real songs, then official videos, then anything else.
func ytmRank(h *ytmHit) int {
	switch {
	case h.kind == "ATV" || h.label == "Song":
		return 0
	case h.kind == "OMV" || h.label == "Video":
		return 1
	case strings.Contains(h.label, "Episode") || h.kind == "PODCAST_EPISODE":
		return 3
	}
	return 2
}

func (y *YTMusic) Find(input string) (*TrackView, error) {
	input = strings.TrimSpace(input)
	if id := ytLink(input); id != "" {
		t := &TrackView{ID: id, URI: "ytm:" + id, Title: "a YouTube video", Artist: "YouTube", Link: "https://music.youtube.com/watch?v=" + id}
		if ct, err := catalogFind("https://www.youtube.com/watch?v=" + id); err == nil && ct != nil {
			t.Title, t.Art = ct.Title, ct.Art
			if ct.Artist != "" {
				t.Artist = ct.Artist
			}
		}
		return t, nil
	}
	if kind, _ := ParseLink(input); kind != "" {
		if kind != "track" {
			return nil, &notTrackErr{"Spotify " + kind}
		}
		ct, err := catalogFind(input) // Spotify link → song name → search YouTube Music for it
		if err != nil || ct == nil {
			return nil, err
		}
		input = ct.Title + " " + ct.Artist
	}
	q := input
	low := strings.ToLower(q)
	for _, sep := range []string{" - ", " – ", " — ", " by "} {
		if i := strings.LastIndex(low, sep); i > 0 {
			q = strings.TrimSpace(q[:i]) + " " + strings.TrimSpace(q[i+len(sep):])
			break
		}
	}
	hits, err := y.search(q)
	if err != nil || len(hits) == 0 {
		return nil, err
	}
	best := hits[0]
	for _, h := range hits[1:] {
		if ytmRank(h) < ytmRank(best) {
			best = h
		}
		if ytmRank(best) == 0 {
			break
		}
	}
	t := best.t
	return &t, nil
}

func (y *YTMusic) Search(q string, limit int) ([]TrackView, error) {
	hits, err := y.search(q)
	if err != nil {
		return nil, err
	}
	out := []TrackView{}
	for _, h := range hits {
		if ytmRank(h) <= 1 && len(out) < limit {
			out = append(out, h.t)
		}
	}
	return out, nil
}

type ytmQueueItem struct {
	t        TrackView
	selected bool
}

func (y *YTMusic) queue() ([]ytmQueueItem, error) {
	code, b, err := y.do("GET", "/api/v1/queue", nil)
	if err != nil || code == 204 {
		return nil, err
	}
	var q struct {
		Items []map[string]any `json:"items"`
	}
	if err := json.Unmarshal(b, &q); err != nil {
		return nil, err
	}
	out := []ytmQueueItem{}
	for _, it := range q.Items {
		r, _ := it["playlistPanelVideoRenderer"].(map[string]any)
		if r == nil {
			r, _ = dig(it, "playlistPanelVideoWrapperRenderer", "primaryRenderer", "playlistPanelVideoRenderer").(map[string]any)
		}
		if r == nil {
			continue
		}
		vid := str(r["videoId"])
		var title, artist string
		if tr := runsText(r["title"]); len(tr) > 0 {
			title = str(tr[0]["text"])
		}
		var parts []string
		for _, x := range runsText(r["shortBylineText"]) {
			parts = append(parts, str(x["text"]))
		}
		artist = strings.TrimSpace(strings.Join(parts, ""))
		dur := 0
		if lr := runsText(r["lengthText"]); len(lr) > 0 {
			dur = parseClock(str(lr[0]["text"]))
		}
		sel, _ := r["selected"].(bool)
		out = append(out, ytmQueueItem{TrackView{ID: vid, URI: "ytm:" + vid, Title: title, Artist: artist, Art: lastThumb(r["thumbnail"]),
			Duration: dur, Link: "https://music.youtube.com/watch?v=" + vid}, sel})
	}
	return out, nil
}

func (y *YTMusic) UpNext() ([]TrackView, error) {
	q, err := y.queue()
	if err != nil {
		return nil, err
	}
	out := []TrackView{}
	after := false
	for _, it := range q {
		if after {
			out = append(out, it.t)
			if len(out) >= 30 {
				break
			}
		}
		if it.selected {
			after = true
		}
	}
	return out, nil
}

// Enqueue puts a request right after the song playing, behind any earlier requests that are still
// waiting, so requests play first-come first-served before YouTube Music's own autoplay.
func (y *YTMusic) Enqueue(t *TrackView) error {
	pending := map[string]bool{}
	y.a.mu.Lock()
	for _, r := range y.a.reqs {
		if !r.Played && strings.HasPrefix(r.URI, "ytm:") && time.Since(r.At) < 6*time.Hour {
			pending[r.URI] = true
		}
	}
	y.a.mu.Unlock()
	if _, _, err := y.do("POST", "/api/v1/queue", map[string]any{"videoId": t.ID, "insertPosition": "INSERT_AFTER_CURRENT_VIDEO"}); err != nil {
		return err
	}
	if len(pending) == 0 {
		return nil
	}
	go func() {
		for try := 0; try < 4; try++ {
			time.Sleep(700 * time.Millisecond)
			q, err := y.queue()
			if err != nil {
				return
			}
			cur := -1
			for i, it := range q {
				if it.selected {
					cur = i
					break
				}
			}
			if cur < 0 || cur+1 >= len(q) || q[cur+1].t.ID != t.ID {
				continue // not added yet
			}
			k := 0
			for i := cur + 2; i < len(q) && pending[q[i].t.URI]; i++ {
				k++
			}
			if k > 0 {
				y.do("PATCH", "/api/v1/queue/"+strconv.Itoa(cur+1), map[string]any{"toIndex": cur + 1 + k})
			}
			return
		}
	}()
	return nil
}

func (y *YTMusic) PlayNow(t *TrackView) error {
	if _, _, err := y.do("POST", "/api/v1/queue", map[string]any{"videoId": t.ID, "insertPosition": "INSERT_AFTER_CURRENT_VIDEO"}); err != nil {
		return err
	}
	time.Sleep(600 * time.Millisecond)
	_, _, err := y.do("POST", "/api/v1/next", nil)
	return err
}
