package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"
)

// OBS talks to OBS Studio through its built-in WebSocket server (OBS 28+, protocol v5).
// In OBS: Tools → WebSocket Server Settings → Enable WebSocket server.
type OBS struct {
	a *App

	mu      sync.Mutex
	gen     int
	ws      *wsConn
	pending map[string]chan obsResp
	seq     int
	st      OBSState
}

type OBSInput struct {
	Name  string `json:"name"`
	Muted bool   `json:"muted"`
}

type OBSState struct {
	Enabled    bool       `json:"enabled"`
	Connected  bool       `json:"connected"`
	Status     string     `json:"status"`
	Version    string     `json:"version,omitempty"`
	Scenes     []string   `json:"scenes"`
	Current    string     `json:"current"`
	Streaming  bool       `json:"streaming"`
	Recording  bool       `json:"recording"`
	ReplayOn   bool       `json:"replayOn"`
	ReplayOK   bool       `json:"replayAvailable"` // false when Replay Buffer is turned off in OBS settings
	Inputs     []OBSInput `json:"inputs"`
	LastClip   string     `json:"lastClip,omitempty"`
	LastClipAt int64      `json:"lastClipAt,omitempty"`
}

type obsResp struct {
	OK      bool
	Code    int
	Comment string
	Data    json.RawMessage
}

// eventSubscriptions: Scenes (4) | Inputs (8) | Outputs (64)
const obsEvents = 4 | 8 | 64

func (o *OBS) State() OBSState {
	o.mu.Lock()
	defer o.mu.Unlock()
	s := o.st
	s.Scenes = append([]string(nil), o.st.Scenes...)
	s.Inputs = append([]OBSInput(nil), o.st.Inputs...)
	return s
}

func (o *OBS) setStatus(g int, connected bool, status string) {
	o.mu.Lock()
	if o.gen == g {
		o.st.Connected = connected
		o.st.Status = status
	}
	o.mu.Unlock()
}

func (o *OBS) alive(g int) bool {
	o.mu.Lock()
	defer o.mu.Unlock()
	return o.gen == g
}

// Restart (re)connects with the current settings. Safe to call any time.
func (o *OBS) Restart() {
	o.mu.Lock()
	o.gen++
	g := o.gen
	if o.ws != nil {
		o.ws.Close()
		o.ws = nil
	}
	c := o.a.st.Get()
	o.st = OBSState{Enabled: c.OBSEnabled, Status: "off"}
	o.mu.Unlock()
	if !c.OBSEnabled {
		return
	}
	go func() {
		delay := 2 * time.Second
		for o.alive(g) {
			o.setStatus(g, false, "connecting")
			err := o.run(g)
			if !o.alive(g) {
				return
			}
			msg := "can't reach OBS"
			if err != nil {
				msg = err.Error()
			}
			o.setStatus(g, false, msg)
			time.Sleep(delay)
			if delay < 15*time.Second {
				delay += 2 * time.Second
			}
		}
	}()
}

func obsAuth(password, salt, challenge string) string {
	s := sha256.Sum256([]byte(password + salt))
	secret := base64.StdEncoding.EncodeToString(s[:])
	a := sha256.Sum256([]byte(secret + challenge))
	return base64.StdEncoding.EncodeToString(a[:])
}

func (o *OBS) run(g int) error {
	c := o.a.st.Get()
	host := strings.TrimSpace(c.OBSHost)
	if host == "" {
		host = "127.0.0.1"
	}
	port := c.OBSPort
	if port == 0 {
		port = 4455
	}
	ws, err := wsDial(fmt.Sprintf("ws://%s:%d/", host, port))
	if err != nil {
		return errors.New("can't reach OBS. In OBS open Tools → WebSocket Server Settings and tick Enable WebSocket server")
	}
	defer ws.Close()
	go func() { // close when settings change
		for o.alive(g) {
			time.Sleep(time.Second)
		}
		ws.Close()
	}()

	// Hello → Identify → Identified
	ws.conn.SetReadDeadline(time.Now().Add(10 * time.Second))
	raw, err := ws.ReadMessage()
	if err != nil {
		return err
	}
	var hello struct {
		Op int `json:"op"`
		D  struct {
			Version string `json:"obsWebSocketVersion"`
			Auth    *struct {
				Challenge string `json:"challenge"`
				Salt      string `json:"salt"`
			} `json:"authentication"`
		} `json:"d"`
	}
	if json.Unmarshal(raw, &hello) != nil || hello.Op != 0 {
		return errors.New("that port isn't OBS's WebSocket server")
	}
	ident := map[string]any{"rpcVersion": 1, "eventSubscriptions": obsEvents}
	if hello.D.Auth != nil {
		if c.OBSPassword == "" {
			return errors.New("OBS wants a password. Copy it from OBS → Tools → WebSocket Server Settings → Show Connect Info")
		}
		ident["authentication"] = obsAuth(c.OBSPassword, hello.D.Auth.Salt, hello.D.Auth.Challenge)
	}
	b, _ := json.Marshal(map[string]any{"op": 1, "d": ident})
	if err := ws.WriteText(b); err != nil {
		return err
	}
	raw, err = ws.ReadMessage()
	if err != nil {
		if strings.Contains(err.Error(), "closed") {
			return errors.New("OBS rejected the password. Copy it again from OBS → Tools → WebSocket Server Settings → Show Connect Info")
		}
		return err
	}
	var idf struct {
		Op int `json:"op"`
	}
	if json.Unmarshal(raw, &idf) != nil || idf.Op != 2 {
		return errors.New("OBS didn't accept the connection")
	}
	ws.conn.SetReadDeadline(time.Time{})

	o.mu.Lock()
	o.ws = ws
	o.pending = map[string]chan obsResp{}
	o.st.Version = hello.D.Version
	o.mu.Unlock()
	o.setStatus(g, true, "connected")
	log.Println("[obs] connected to OBS WebSocket " + hello.D.Version)

	go o.refreshAll()

	for {
		ws.conn.SetReadDeadline(time.Now().Add(5 * time.Minute))
		raw, err := ws.ReadMessage()
		if err != nil {
			o.mu.Lock()
			if o.ws == ws {
				o.ws = nil
			}
			for _, ch := range o.pending {
				close(ch)
			}
			o.pending = map[string]chan obsResp{}
			o.mu.Unlock()
			return errors.New("lost connection to OBS (is it still open?)")
		}
		var m struct {
			Op int             `json:"op"`
			D  json.RawMessage `json:"d"`
		}
		if json.Unmarshal(raw, &m) != nil {
			continue
		}
		switch m.Op {
		case 7: // RequestResponse
			var r struct {
				ID     string `json:"requestId"`
				Status struct {
					Result  bool   `json:"result"`
					Code    int    `json:"code"`
					Comment string `json:"comment"`
				} `json:"requestStatus"`
				Data json.RawMessage `json:"responseData"`
			}
			if json.Unmarshal(m.D, &r) != nil {
				continue
			}
			o.mu.Lock()
			ch := o.pending[r.ID]
			delete(o.pending, r.ID)
			o.mu.Unlock()
			if ch != nil {
				ch <- obsResp{r.Status.Result, r.Status.Code, r.Status.Comment, r.Data}
				close(ch)
			}
		case 5: // Event
			var e struct {
				Type string          `json:"eventType"`
				Data json.RawMessage `json:"eventData"`
			}
			if json.Unmarshal(m.D, &e) == nil {
				o.onEvent(e.Type, e.Data)
			}
		}
	}
}

// Request sends one OBS request and waits up to 6 seconds for the answer.
func (o *OBS) Request(kind string, data any) (json.RawMessage, error) {
	o.mu.Lock()
	ws := o.ws
	if ws == nil {
		o.mu.Unlock()
		if !o.a.st.Get().OBSEnabled {
			return nil, errors.New("OBS isn't set up yet. Turn it on in the dashboard under OBS & Deck")
		}
		return nil, errors.New("not connected to OBS")
	}
	o.seq++
	id := fmt.Sprintf("hws-%d", o.seq)
	ch := make(chan obsResp, 1)
	o.pending[id] = ch
	o.mu.Unlock()
	d := map[string]any{"requestType": kind, "requestId": id}
	if data != nil {
		d["requestData"] = data
	}
	b, _ := json.Marshal(map[string]any{"op": 6, "d": d})
	if err := ws.WriteText(b); err != nil {
		return nil, err
	}
	select {
	case r, ok := <-ch:
		if !ok {
			return nil, errors.New("lost connection to OBS")
		}
		if !r.OK {
			msg := r.Comment
			if msg == "" {
				msg = fmt.Sprintf("OBS said no (code %d)", r.Code)
			}
			return r.Data, &obsErr{r.Code, msg}
		}
		return r.Data, nil
	case <-time.After(6 * time.Second):
		o.mu.Lock()
		delete(o.pending, id)
		o.mu.Unlock()
		return nil, errors.New("OBS didn't answer in time")
	}
}

type obsErr struct {
	Code int
	Msg  string
}

func (e *obsErr) Error() string { return e.Msg }

func isAudioKind(kind string) bool {
	k := strings.ToLower(kind)
	for _, s := range []string{"wasapi", "audio", "pulse", "coreaudio", "alsa", "jack", "sndio"} {
		if strings.Contains(k, s) {
			return true
		}
	}
	return false
}

func (o *OBS) refreshScenes() {
	raw, err := o.Request("GetSceneList", nil)
	if err != nil {
		return
	}
	var r struct {
		Current string `json:"currentProgramSceneName"`
		Scenes  []struct {
			Name  string `json:"sceneName"`
			Index int    `json:"sceneIndex"`
		} `json:"scenes"`
	}
	json.Unmarshal(raw, &r)
	names := make([]string, len(r.Scenes))
	// OBS lists the bottom scene first; show them in the same order as the OBS Scenes dock.
	for i, s := range r.Scenes {
		names[len(r.Scenes)-1-i] = s.Name
	}
	o.mu.Lock()
	o.st.Scenes = names
	o.st.Current = r.Current
	o.mu.Unlock()
}

func (o *OBS) refreshInputs() {
	raw, err := o.Request("GetInputList", nil)
	if err != nil {
		return
	}
	var r struct {
		Inputs []struct {
			Name string `json:"inputName"`
			Kind string `json:"inputKind"`
		} `json:"inputs"`
	}
	json.Unmarshal(raw, &r)
	var out []OBSInput
	for _, in := range r.Inputs {
		if !isAudioKind(in.Kind) {
			continue
		}
		mr, err := o.Request("GetInputMute", map[string]any{"inputName": in.Name})
		if err != nil {
			continue
		}
		var m struct {
			Muted bool `json:"inputMuted"`
		}
		json.Unmarshal(mr, &m)
		out = append(out, OBSInput{in.Name, m.Muted})
	}
	o.mu.Lock()
	o.st.Inputs = out
	o.mu.Unlock()
}

func (o *OBS) outputActive(req string) (bool, error) {
	raw, err := o.Request(req, nil)
	if err != nil {
		return false, err
	}
	var r struct {
		Active bool `json:"outputActive"`
	}
	json.Unmarshal(raw, &r)
	return r.Active, nil
}

func (o *OBS) refreshOutputs() {
	s, _ := o.outputActive("GetStreamStatus")
	rec, _ := o.outputActive("GetRecordStatus")
	rb, err := o.outputActive("GetReplayBufferStatus")
	o.mu.Lock()
	o.st.Streaming, o.st.Recording = s, rec
	o.st.ReplayOn = rb
	o.st.ReplayOK = err == nil
	o.mu.Unlock()
	if err == nil && !rb && o.a.st.Get().OBSKeepReplay {
		if _, err := o.Request("StartReplayBuffer", nil); err == nil {
			log.Println("[obs] started the replay buffer so clips are ready")
		}
	}
}

func (o *OBS) refreshAll() {
	o.refreshScenes()
	o.refreshOutputs()
	o.refreshInputs()
}

func (o *OBS) onEvent(kind string, data json.RawMessage) {
	var d map[string]any
	json.Unmarshal(data, &d)
	str := func(k string) string { s, _ := d[k].(string); return s }
	boolean := func(k string) bool { b, _ := d[k].(bool); return b }
	switch kind {
	case "CurrentProgramSceneChanged":
		o.mu.Lock()
		o.st.Current = str("sceneName")
		o.mu.Unlock()
	case "SceneListChanged", "SceneCreated", "SceneRemoved", "SceneNameChanged":
		go o.refreshScenes()
	case "StreamStateChanged":
		o.mu.Lock()
		o.st.Streaming = boolean("outputActive")
		o.mu.Unlock()
	case "RecordStateChanged":
		o.mu.Lock()
		o.st.Recording = boolean("outputActive")
		o.mu.Unlock()
	case "ReplayBufferStateChanged":
		o.mu.Lock()
		o.st.ReplayOn = boolean("outputActive")
		o.st.ReplayOK = true
		o.mu.Unlock()
	case "ReplayBufferSaved":
		o.mu.Lock()
		o.st.LastClip = str("savedReplayPath")
		o.st.LastClipAt = time.Now().UnixMilli()
		o.mu.Unlock()
		log.Println("[obs] replay saved: " + str("savedReplayPath"))
	case "InputMuteStateChanged":
		o.mu.Lock()
		for i := range o.st.Inputs {
			if o.st.Inputs[i].Name == str("inputName") {
				o.st.Inputs[i].Muted = boolean("inputMuted")
			}
		}
		o.mu.Unlock()
	case "InputCreated", "InputRemoved", "InputNameChanged":
		go o.refreshInputs()
	}
}

// ---------- actions ----------

func (o *OBS) SetScene(name string) error {
	if strings.TrimSpace(name) == "" {
		return errors.New("which scene?")
	}
	_, err := o.Request("SetCurrentProgramScene", map[string]any{"sceneName": name})
	if e, ok := err.(*obsErr); ok && e.Code == 600 {
		return fmt.Errorf("OBS has no scene called %q", name)
	}
	return err
}

// SaveReplay saves the replay buffer. If it's off, it switches it on and explains.
func (o *OBS) SaveReplay() (string, error) {
	_, err := o.Request("SaveReplayBuffer", nil)
	if err == nil {
		return "Replay saved", nil
	}
	if e, ok := err.(*obsErr); ok {
		switch e.Code {
		case 501: // OutputNotRunning
			if _, err2 := o.Request("StartReplayBuffer", nil); err2 == nil {
				return "", errors.New("the replay buffer was off, so it's on now. It can only save what it records from here, so press Clip again in a little while")
			}
			return "", errors.New("turn on Replay Buffer in OBS: Settings → Output → Replay Buffer, then press Clip again")
		case 504, 604: // OutputDisabled / InvalidResourceState: Replay Buffer is off in OBS settings
			return "", errors.New("turn on Replay Buffer in OBS: Settings → Output → Replay Buffer, then press Clip again")
		}
	}
	return "", err
}

func (o *OBS) setOutput(kind string, on bool) error {
	verb := "Stop"
	if on {
		verb = "Start"
	}
	_, err := o.Request(verb+kind, nil)
	if e, ok := err.(*obsErr); ok && (e.Code == 500 || e.Code == 501) {
		return nil // already in that state
	}
	return err
}

func (o *OBS) ToggleRecord() (string, error) {
	on := !o.State().Recording
	if err := o.setOutput("Record", on); err != nil {
		return "", err
	}
	if on {
		return "Recording started", nil
	}
	return "Recording stopped", nil
}

func (o *OBS) SetStream(on bool) (string, error) {
	if err := o.setOutput("Stream", on); err != nil {
		return "", err
	}
	if on {
		return "Going live", nil
	}
	return "Stream ended", nil
}

func (o *OBS) ToggleMute(input string) (string, error) {
	raw, err := o.Request("ToggleInputMute", map[string]any{"inputName": input})
	if err != nil {
		if e, ok := err.(*obsErr); ok && e.Code == 600 {
			return "", fmt.Errorf("OBS has no audio source called %q", input)
		}
		return "", err
	}
	var r struct {
		Muted bool `json:"inputMuted"`
	}
	json.Unmarshal(raw, &r)
	o.mu.Lock()
	for i := range o.st.Inputs {
		if o.st.Inputs[i].Name == input {
			o.st.Inputs[i].Muted = r.Muted
		}
	}
	o.mu.Unlock()
	if r.Muted {
		return input + " muted", nil
	}
	return input + " unmuted", nil
}
