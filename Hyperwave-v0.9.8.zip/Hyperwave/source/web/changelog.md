# What's new in Hyperwave

## 0.9.8
- **Music without Spotify Premium.** Pick where your music comes from under the new **Music** section of the dashboard:
  - **Any player on this PC** (new, no setup): Spotify Free, Apple Music, YouTube or SoundCloud in a browser, TIDAL, Deezer, Amazon Music, foobar2000, MusicBee and most others. Now playing with album art and progress, plus play/pause, skip and back from the deck, chat commands and the DJ page. You can pin it to one player so a video in another tab doesn't take over.
  - **YouTube Music app** (new, free): full control, including volume, shuffle, repeat, search, Up next and real song requests that go straight into its queue in the order viewers asked.
  - **Spotify Premium**: works exactly as before, with playlists and devices.
  - **Last.fm** (new): shows whatever you scrobble from your phone, console, Plex or a record player app.
- **Request list** for players that can't take requests directly. Requests are still checked against your rules (length, explicit, repeats, limits), then wait on a list on the dashboard, the deck and the DJ page. A **Find** button searches for each one in the player you're using, and Hyperwave ticks it off when it sees the song playing.
- Requests can now be a **YouTube link** as well as a song name or Spotify link.
- The deck, DJ page, chat commands and overlay only show the controls your music source can really do, and explain why when something isn't available.
- The overlay hides its progress bar when the player doesn't share the song length.
- Chat replies that mentioned Spotify now say "the music player" (only if you hadn't changed them).
- New installs start on **Any player on this PC**. If you already use Spotify, nothing changes.

## 0.9.7
- **New: My Deck**, your own stream deck that works without an Elgato. Design big buttons with a name, icon and color, and make one button do several things in order (switch scene, mute, post in chat, clip, music and more, with waits in between). Optional press-and-hold for risky buttons. Reorder and resize them. Your buttons sync across your PC, phone and tablet. Every button can also go on an Elgato Stream Deck key.
- **Phone sign-in is easier:** the dashboard shows a QR code and a Copy link button that open the deck already signed in.
- **Pick your own deck passkey**, or generate a random one.
- **What's new** on the dashboard lists every update from 0.9.7 on, and a banner tells you when you've just updated.
- **Fixed:** the deck page could lock you out within seconds on a phone. Its background checks were being counted as wrong passkeys.
- The Twitch app instructions now say `https://localhost` for the redirect URL (Twitch rejects an empty extra box).
- Clearer message when a music button is pressed before Spotify is connected.


