Hyperwave Chat is now built into Hyperwave Station (0.9.5 and later).
Open http://127.0.0.1:7575/chat while the app is running.

If you copied an older chat.html into this folder, delete it.
Any page you put here replaces the built-in copy, so an old chat.html
would hide the new version.

about.json controls the About section on the dashboard (edit in Notepad).
Other pages you can replace here: index.html, nowplaying.html, dj.html, chat.html.
