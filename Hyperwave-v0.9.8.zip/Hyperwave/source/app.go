package main

import (
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Requester struct {
	User     string `json:"user"`
	Platform string `json:"platform"`
}

type Req struct {
	ID       int       `json:"id"`
	URI      string    `json:"uri"`
	Title    string    `json:"title"`
	Artist   string    `json:"artist"`
	Art      string    `json:"art"`
	User     string    `json:"user"`
	Platform string    `json:"platform"`
	At       time.Time `json:"at"`
	Played   bool      `json:"played"`
	Link     string    `json:"link,omitempty"`
	Duration int       `json:"duration,omitempty"`
	ListOnly bool      `json:"listOnly,omitempty"` // on the request list, not in the player's queue
}

type Event struct {
	ID   int    `json:"id"`
	Kind string `json:"kind"` // request | dj
	Text string `json:"text"`
	User string `json:"user"`
	Art  string `json:"art,omitempty"`
	At   int64  `json:"at"`
}

type NowState struct {
	Connected   bool       `json:"connected"`
	Playing     bool       `json:"playing"`
	Track       *TrackView `json:"track"`
	Progress    int        `json:"progress"`
	At          int64      `json:"at"` // unix ms when progress was sampled
	Device      string     `json:"device"`
	Volume      int        `json:"volume"`
	Shuffle     bool       `json:"shuffle"`
	Repeat      string     `json:"repeat"`
	Context     string     `json:"context"`
	RequestedBy *Requester `json:"requestedBy"`
	Events      []Event    `json:"events"`
	Error       string     `json:"error,omitempty"`
	Source      string     `json:"source"`     // spotify | windows | ytmusic | lastfm
	SourceName  string     `json:"sourceName"` // shown to people: "Spotify", "YouTube Music"...
	Caps        Caps       `json:"caps"`       // which controls work right now
	ListMode    bool       `json:"listMode"`   // requests go on a list the streamer plays from
}

type App struct {
	st   *Store
	sp   *Spotify
	tun  *Tunnel
	chat *ChatHub
	obs  *OBS
	sb   *SB
	tw   *Twitch
	tik  *TikFinity
	lan  *DeckLAN
	feed *Feed

	spot *spotifySource
	win  *WinMedia
	ytm  *YTMusic
	lfm  *LastFM

	mu       sync.Mutex
	now      NowState
	reqs     []*Req
	reqSeq   int
	events   []Event
	evSeq    int
	lastUser map[string]time.Time
	lastPoll time.Time
	wake     chan struct{}

	qMu    sync.Mutex
	qCache []TrackView
	qAt    time.Time
	qSrc   string
}

func NewApp(st *Store) *App {
	a := &App{st: st, sp: NewSpotify(st), lastUser: map[string]time.Time{}, wake: make(chan struct{}, 1), feed: &Feed{}, tw: NewTwitch(st)}
	a.obs = &OBS{a: a}
	a.sb = &SB{a: a}
	a.tik = &TikFinity{a: a}
	a.lan = &DeckLAN{a: a}
	a.spot = &spotifySource{a: a}
	a.win = &WinMedia{a: a}
	a.ytm = &YTMusic{a: a}
	a.lfm = &LastFM{a: a}
	return a
}

func (a *App) poke() {
	select {
	case a.wake <- struct{}{}:
	default:
	}
}

// Poller keeps the now-playing state fresh (every 2s while playing, 5s when idle).
func (a *App) Poller() {
	for {
		wait := a.pollOnce()
		select {
		case <-time.After(wait):
		case <-a.wake:
			time.Sleep(350 * time.Millisecond) // let Spotify catch up after a command
		}
	}
}

func (a *App) pollOnce() time.Duration {
	src := a.source()
	base := NowState{Source: src.ID(), SourceName: src.Name(), Caps: src.Caps()}
	base.ListMode = !base.Caps.Queue
	if !src.Ready() {
		a.mu.Lock()
		base.Events = a.now.Events
		a.now = base
		a.mu.Unlock()
		return 3 * time.Second
	}
	snap, err := src.Poll()
	a.mu.Lock()
	defer a.mu.Unlock()
	a.lastPoll = time.Now()
	ns := base
	ns.Connected, ns.At, ns.Events = true, time.Now().UnixMilli(), a.now.Events
	if err != nil {
		if a.now.Source == base.Source {
			ns = a.now // keep showing the last song through a hiccup
			ns.Caps, ns.ListMode, ns.SourceName = base.Caps, base.ListMode, base.SourceName
		}
		ns.Error = err.Error()
		// A failed check (network hiccup, rate limit, a player refusing a request) doesn't mean
		// you're logged out. Only a missing or ended login does. Before this, the first failed
		// check after logging in left this at "not connected" while the dashboard's login check
		// said "connected", so the page flipped between the two.
		ns.Connected = src.Ready() && !errors.Is(err, ErrNoAuth)
		if errors.Is(err, ErrNotOpen) {
			ns.Track, ns.Playing = nil, false
		}
		a.now = ns
		return 6 * time.Second
	}
	if snap != nil {
		ns.Playing = snap.Playing
		ns.Track = snap.Track
		ns.Progress = snap.Progress
		ns.Device = snap.Device
		ns.Volume = snap.Volume
		ns.Shuffle = snap.Shuffle
		ns.Repeat = snap.Repeat
		ns.Context = snap.Context
		if snap.Caps != nil {
			ns.Caps = *snap.Caps
			ns.Caps.Queue, ns.Caps.UpNext, ns.Caps.Search = base.Caps.Queue, base.Caps.UpNext, base.Caps.Search
		}
	}
	if ns.Track != nil {
		// attribute the playing track to the oldest unplayed request for it
		for _, r := range a.reqs {
			if !r.Played && time.Since(r.At) < 6*time.Hour && reqMatches(r, ns.Track) {
				r.Played = true
				ns.RequestedBy = &Requester{r.User, r.Platform}
				break
			}
		}
		if ns.RequestedBy == nil && a.now.Track != nil && a.now.Track.URI == ns.Track.URI {
			ns.RequestedBy = a.now.RequestedBy
		}
	}
	a.now = ns
	if ns.Playing {
		return 2 * time.Second
	}
	return 5 * time.Second
}

func (a *App) State() NowState {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.now
	s.Events = append([]Event(nil), a.events...)
	return s
}

func (a *App) addEvent(kind, text, user, art string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.evSeq++
	a.events = append(a.events, Event{a.evSeq, kind, text, user, art, time.Now().UnixMilli()})
	if len(a.events) > 20 {
		a.events = a.events[len(a.events)-20:]
	}
}

func (a *App) Requests() []Req {
	a.mu.Lock()
	defer a.mu.Unlock()
	out := make([]Req, 0, len(a.reqs))
	for i := len(a.reqs) - 1; i >= 0; i-- {
		out = append(out, *a.reqs[i])
	}
	return out
}

func fill(tpl string, kv map[string]string) string {
	for k, v := range kv {
		tpl = strings.ReplaceAll(tpl, "{"+k+"}", v)
	}
	return tpl
}

func fmtMin(f float64) string {
	return strconv.FormatFloat(f, 'f', -1, 64)
}

// ---------------- song requests ----------------

type SRResult struct {
	OK    bool       `json:"ok"`
	Reply string     `json:"reply"`
	Code  string     `json:"code"`
	Track *TrackView `json:"track,omitempty"`
	Pos   int        `json:"position,omitempty"`
}

// Request runs every request rule, queues the song and returns the chat reply.
// bypass=true is for DJs/mods (skips limits but still needs a device).
func (a *App) Request(input, user, platform string, bypass bool) SRResult {
	c := a.st.Get()
	t := c.T
	if user == "" {
		user = "someone"
	}
	user = strings.TrimPrefix(user, "@")
	kv := map[string]string{"user": user, "max": "", "title": "", "artist": "", "pos": ""}
	rep := func(code, tpl string) SRResult { return SRResult{Code: code, Reply: fill(tpl, kv)} }

	input = strings.TrimSpace(input)
	if !c.RequestsOpen && !bypass {
		return rep("closed", t.Closed)
	}
	if input == "" {
		return rep("empty", t.Empty)
	}
	src := a.source()
	if !src.Ready() {
		return SRResult{Code: "auth", Reply: "@" + user + " song requests aren't hooked up to a music player yet."}
	}
	if !bypass && c.UserCooldownSec > 0 {
		a.mu.Lock()
		last := a.lastUser[strings.ToLower(user)]
		a.mu.Unlock()
		if left := time.Until(last.Add(time.Duration(c.UserCooldownSec) * time.Second)); left > 0 {
			return SRResult{Code: "cooldown", Reply: fmt.Sprintf("@%s slow down — you can request again in %ds.", user, int(left.Seconds())+1)}
		}
	}

	caps := src.Caps()
	var tr *TrackView
	var err error
	if caps.Search {
		tr, err = src.Find(input)
	} else {
		tr, err = catalogFind(input) // the player can't search, so look it up and put it on the request list
	}
	if errors.Is(err, ErrNotOpen) {
		return rep("noDevice", t.NoDevice)
	}
	if errors.Is(err, errYTMAuth) {
		return SRResult{Code: "auth", Reply: "@" + user + " song requests aren't hooked up to a music player yet."}
	}
	var nt *notTrackErr
	if errors.As(err, &nt) {
		return SRResult{Code: "notTrack", Reply: "@" + user + " that's a " + nt.kind + " link — song requests need a link to one song."}
	}
	if err != nil || tr == nil {
		if err != nil {
			log.Println("request search:", err)
		}
		return rep("notFound", t.NotFound)
	}
	kv["title"], kv["artist"] = tr.Title, tr.Artist

	if !bypass {
		low := strings.ToLower(tr.Title + " " + tr.Artist + " " + tr.ID)
		for _, w := range c.Blocklist {
			w = strings.ToLower(strings.TrimSpace(w))
			if w != "" && strings.Contains(low, w) {
				return rep("blocked", t.Blocked)
			}
		}
		if c.BlockExplicit && tr.Explicit {
			return rep("explicit", t.Explicit)
		}
		if c.MaxMinutes > 0 && float64(tr.Duration) > c.MaxMinutes*60000 {
			kv["max"] = fmtMin(c.MaxMinutes)
			return rep("tooLong", t.TooLong)
		}
		a.mu.Lock()
		pending := 0
		dup := false
		for _, r := range a.reqs {
			if strings.EqualFold(r.User, user) && !r.Played && time.Since(r.At) < 90*time.Minute {
				pending++
			}
			if c.NoDupMinutes > 0 && time.Since(r.At) < time.Duration(c.NoDupMinutes)*time.Minute &&
				(r.URI == tr.URI || sameSong(r.Title, r.Artist, tr.Title, tr.Artist)) {
				dup = true
			}
		}
		a.mu.Unlock()
		if dup {
			return rep("duplicate", t.Duplicate)
		}
		if c.MaxPerUser > 0 && pending >= c.MaxPerUser {
			kv["max"] = strconv.Itoa(c.MaxPerUser)
			return rep("limit", t.Limit)
		}
	}

	if caps.Queue {
		if err := src.Enqueue(tr); err != nil {
			if errors.Is(err, ErrNoDevice) || errors.Is(err, ErrNotOpen) {
				return rep("noDevice", t.NoDevice)
			}
			log.Println("queue add:", err)
			msg := err.Error()
			if !strings.Contains(msg, "refused") {
				msg = src.Name() + " didn't accept that one, try again in a moment"
			}
			return SRResult{Code: "error", Reply: "@" + user + " " + msg + "."}
		}
	}

	a.mu.Lock()
	a.reqSeq++
	pos := 1
	for _, r := range a.reqs {
		if !r.Played && time.Since(r.At) < 90*time.Minute {
			pos++
		}
	}
	a.reqs = append(a.reqs, &Req{ID: a.reqSeq, URI: tr.URI, Title: tr.Title, Artist: tr.Artist, Art: tr.Art, User: user, Platform: platform,
		At: time.Now(), Link: tr.Link, Duration: tr.Duration, ListOnly: !caps.Queue})
	if len(a.reqs) > 200 {
		a.reqs = a.reqs[len(a.reqs)-200:]
	}
	a.lastUser[strings.ToLower(user)] = time.Now()
	a.mu.Unlock()
	a.qMu.Lock()
	a.qAt = time.Time{}
	a.qMu.Unlock()

	kv["pos"] = strconv.Itoa(pos)
	a.addEvent("request", tr.Title+" — "+tr.Artist, user, tr.Art)
	log.Printf("[request] %s (%s) -> %s by %s", user, platform, tr.Title, tr.Artist)
	res := rep("added", t.Added)
	res.OK = true
	res.Track = tr
	res.Pos = pos
	return res
}

func (a *App) searchOne(input string) (*Track, error) {
	filtered, plain := BuildQuery(input)
	try := func(q string) (*Track, error) {
		r, err := a.sp.Search(q, "track", 5)
		if err != nil || len(r.Tracks) == 0 {
			return nil, err
		}
		v := r.Tracks[0]
		return &Track{ID: v.ID, URI: v.URI, Name: v.Title, Duration: v.Duration, Explicit: v.Explicit,
			Artists: []Artist{{v.Artist}}, Album: struct {
				Name   string  `json:"name"`
				Images []Image `json:"images"`
			}{v.Album, []Image{{URL: v.Art, W: 300}}}}, nil
	}
	if filtered != "" {
		if t, err := try(filtered); t != nil || err != nil {
			return t, err
		}
	}
	return try(plain)
}

func (a *App) NowPlayingText() string {
	s := a.State()
	c := a.st.Get()
	if s.Track == nil {
		return c.T.Nothing
	}
	req := ""
	if s.RequestedBy != nil {
		req = " (requested by @" + s.RequestedBy.User + ")"
	}
	link := ""
	if s.Track.Link != "" {
		link = " " + s.Track.Link
	}
	out := fill(c.T.NowPlay, map[string]string{"title": s.Track.Title, "artist": s.Track.Artist, "req": req})
	if strings.Contains(c.T.NowPlay, "{link}") {
		return strings.ReplaceAll(out, "{link}", link)
	}
	return out
}

// ---------------- DJ / mod commands ----------------

// Command runs a DJ action and returns a chat-friendly reply.
func (a *App) Command(cmd, arg, user string) (string, error) {
	cmd = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(cmd, "!")))
	arg = strings.TrimSpace(arg)
	src := a.source()
	defer a.poke()
	who := ""
	if user != "" {
		who = " by @" + strings.TrimPrefix(user, "@")
	}
	djEvent := func(text string) { a.addEvent("dj", text, user, "") }
	caps := a.State().Caps
	if !src.Ready() {
		caps = Caps{}
	}
	need := func(ok bool, what string) error {
		if !src.Ready() {
			return errors.New(src.Name() + " isn't set up yet. Pick and connect your music on the Station dashboard")
		}
		if ok {
			return nil
		}
		return cantErr(a.State(), src, what)
	}
	ctl := func(c, v string) error {
		err := src.Control(c, v)
		if errors.Is(err, ErrUnsupported) {
			return need(false, "do that")
		}
		if errors.Is(err, ErrNotOpen) {
			return errors.New(src.Name() + " isn't open on the streaming PC")
		}
		return err
	}
	switch cmd {
	case "skip", "next":
		if err := need(caps.Next, "skip songs"); err != nil {
			return "", err
		}
		if err := ctl("next", ""); err != nil {
			return "", err
		}
		djEvent("Skipped" + who)
		return "⏭ Skipped" + who, nil
	case "prev", "previous", "back":
		if err := need(caps.Prev, "go back a song"); err != nil {
			return "", err
		}
		if err := ctl("prev", ""); err != nil {
			return "", err
		}
		djEvent("Went back" + who)
		return "⏮ Back one track", nil
	case "pause", "stop":
		if err := need(caps.Pause, "pause"); err != nil {
			return "", err
		}
		if err := ctl("pause", ""); err != nil {
			return "", err
		}
		djEvent("Music paused" + who)
		return "⏸ Music paused" + who, nil
	case "play", "resume", "start":
		if arg != "" {
			return a.PlayNow(arg, user)
		}
		if err := need(caps.Play, "start playback"); err != nil {
			return "", err
		}
		if err := ctl("play", ""); err != nil {
			return "", err
		}
		djEvent("Music resumed" + who)
		return "▶ Music resumed" + who, nil
	case "toggle":
		if a.State().Playing {
			return a.Command("pause", "", user)
		}
		return a.Command("play", "", user)
	case "vol", "volume":
		if err := need(caps.Volume, "change the volume. Use the player's own volume or OBS"); err != nil {
			return "", err
		}
		v := a.State().Volume
		if v < 0 {
			v = 50
		}
		switch {
		case arg == "":
			return fmt.Sprintf("🔊 Volume is %d%%", v), nil
		case arg == "up" || arg == "+":
			v += 10
		case arg == "down" || arg == "-":
			v -= 10
		case strings.HasPrefix(arg, "+") || strings.HasPrefix(arg, "-"):
			d, _ := strconv.Atoi(arg)
			v += d
		default:
			n, err := strconv.Atoi(strings.TrimSuffix(arg, "%"))
			if err != nil {
				return "", errors.New("volume must be 0-100, up or down")
			}
			v = n
		}
		if v < 0 {
			v = 0
		}
		if v > 100 {
			v = 100
		}
		if err := ctl("volume", strconv.Itoa(v)); err != nil {
			return "", err
		}
		a.mu.Lock()
		a.now.Volume = v
		a.mu.Unlock()
		return fmt.Sprintf("🔊 Volume %d%%", v), nil
	case "shuffle":
		if err := need(caps.Shuffle, "shuffle"); err != nil {
			return "", err
		}
		on := !a.State().Shuffle
		if arg != "" {
			on = arg == "on" || arg == "true" || arg == "1"
		}
		v := "off"
		if on {
			v = "on"
		}
		if err := ctl("shuffle", v); err != nil {
			return "", err
		}
		if src.ID() == "ytmusic" {
			return "🔀 Queue shuffled", nil
		}
		return "🔀 Shuffle " + v, nil
	case "repeat":
		if err := need(caps.Repeat, "change repeat"); err != nil {
			return "", err
		}
		m := map[string]string{"off": "off", "track": "track", "song": "track", "one": "track", "context": "context", "all": "context", "on": "context", "playlist": "context"}
		st, ok := m[strings.ToLower(arg)]
		if !ok {
			cur := a.State().Repeat
			st = map[string]string{"off": "context", "context": "track", "track": "off"}[cur]
			if st == "" {
				st = "context"
			}
		}
		if err := ctl("repeat", st); err != nil {
			return "", err
		}
		return "🔁 Repeat " + st, nil
	case "playlist", "pl", "album":
		if arg == "" {
			return "", errors.New("add a playlist link or name")
		}
		if err := need(caps.Playlists, "start playlists from chat"); err != nil {
			return "", err
		}
		return a.PlayContext(arg, user)
	case "playnow", "pn":
		return a.PlayNow(arg, user)
	case "queue", "sr", "add":
		r := a.Request(arg, user, "dj", true)
		if !r.OK {
			return "", errors.New(r.Reply)
		}
		return r.Reply, nil
	case "requests", "sron", "sroff":
		open := !a.st.Get().RequestsOpen
		if cmd == "sron" || arg == "on" || arg == "open" {
			open = true
		}
		if cmd == "sroff" || arg == "off" || arg == "close" || arg == "closed" {
			open = false
		}
		a.st.Update(func(c *Config) { c.RequestsOpen = open })
		if open {
			djEvent("Song requests are OPEN")
			return "✅ Song requests are open!", nil
		}
		djEvent("Song requests are closed")
		return "⛔ Song requests are closed.", nil
	case "np", "song", "nowplaying":
		return a.NowPlayingText(), nil
	case "played", "done":
		return a.MarkRequest(arg, "done")
	case "unrequest", "remove":
		return a.MarkRequest(arg, "remove")
	}
	return "", fmt.Errorf("unknown command %q", cmd)
}

// cantErr explains why a control isn't available with this music source.
func cantErr(s NowState, src Source, what string) error {
	switch src.ID() {
	case "windows":
		p := "the player"
		if s.Device != "" {
			p = s.Device
		}
		switch what {
		case "skip songs", "go back a song", "pause", "start playback", "shuffle", "change repeat":
			return fmt.Errorf("%s isn't offering that button to Windows right now, so Hyperwave can't %s", p, what)
		}
		return fmt.Errorf("Through Windows media, Hyperwave can only press play, pause and skip in %s, so it can't %s", p, what)
	case "lastfm":
		return fmt.Errorf("Last.fm only shows what's playing, so Hyperwave can't %s", what)
	}
	return fmt.Errorf("%s doesn't let apps %s", src.Name(), what)
}

// playerName is the app the music is coming from ("Chrome", "Apple Music") or the source's name.
func playerName(s NowState, src Source) string {
	if src.ID() == "windows" && s.Device != "" {
		return s.Device
	}
	return src.Name()
}

// PlayContext starts a Spotify playlist/album/artist from a link, URI or by matching one of the streamer's playlist names.
func (a *App) PlayContext(arg, user string) (string, error) {
	if a.source().ID() != "spotify" {
		return "", errors.New("starting playlists from Hyperwave works with Spotify only for now")
	}
	var uri, label string
	if kind, id := ParseLink(arg); kind != "" {
		if kind == "track" || kind == "episode" {
			return a.PlayNow(arg, user)
		}
		uri, label = "spotify:"+kind+":"+id, kind
	} else {
		pls, err := a.sp.MyPlaylists()
		if err != nil {
			return "", err
		}
		want := strings.ToLower(arg)
		for _, p := range pls {
			if strings.ToLower(p.Name) == want {
				uri, label = p.URI, p.Name
				break
			}
		}
		if uri == "" {
			for _, p := range pls {
				if strings.Contains(strings.ToLower(p.Name), want) {
					uri, label = p.URI, p.Name
					break
				}
			}
		}
		if uri == "" {
			return "", fmt.Errorf("no playlist called %q in the streamer's library", arg)
		}
	}
	if _, _, err := a.sp.Do("PUT", "/me/player/play", nil, map[string]any{"context_uri": uri}); err != nil {
		if errors.Is(err, ErrNoDevice) {
			return "", errors.New("no active Spotify device on the streaming PC")
		}
		return "", err
	}
	a.poke()
	a.addEvent("dj", "Now playing "+label, user, "")
	return "💿 Now playing " + label, nil
}

func (a *App) PlayNow(arg, user string) (string, error) {
	src := a.source()
	if !src.Ready() {
		return "", errors.New(src.Name() + " isn't set up yet")
	}
	if !src.Caps().Search {
		return "", fmt.Errorf("%s. Use !sr to put it on the request list", cantErr(a.State(), src, "pick what plays"))
	}
	if kind, _ := ParseLink(arg); kind != "" && kind != "track" && kind != "episode" {
		return a.PlayContext(arg, user)
	}
	in := arg
	if strings.HasPrefix(in, "spotify:track:") {
		in = "https://open.spotify.com/track/" + strings.TrimPrefix(in, "spotify:track:")
	}
	tr, err := src.Find(in)
	if err != nil || tr == nil {
		return "", errors.New("couldn't find that track")
	}
	if err := src.PlayNow(tr); err != nil {
		return "", err
	}
	a.poke()
	a.addEvent("dj", "Playing "+tr.Title+" — "+tr.Artist, user, tr.Art)
	return "▶ Playing " + tr.Title + " by " + tr.Artist, nil
}

// UpNext is what plays next: the player's own queue when it shares one, otherwise the request list.
func (a *App) UpNext() ([]TrackView, error) {
	src := a.source()
	if !src.Caps().UpNext {
		out := []TrackView{}
		a.mu.Lock()
		for _, r := range a.reqs {
			if !r.Played && time.Since(r.At) < 6*time.Hour {
				out = append(out, TrackView{URI: r.URI, Title: r.Title, Artist: r.Artist, Art: r.Art, Duration: r.Duration, Link: r.Link})
			}
		}
		a.mu.Unlock()
		return out, nil
	}
	a.qMu.Lock()
	defer a.qMu.Unlock()
	if time.Since(a.qAt) < 4*time.Second && a.qSrc == src.ID() {
		return a.qCache, nil
	}
	q, err := src.UpNext()
	if err != nil {
		return a.qCache, err
	}
	if q == nil {
		q = []TrackView{}
	}
	a.qCache, a.qAt, a.qSrc = q, time.Now(), src.ID()
	return q, nil
}

// MarkRequest ticks a request off the list (done) or deletes it (remove). Empty id = the oldest waiting one.
func (a *App) MarkRequest(id, action string) (string, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	n, _ := strconv.Atoi(strings.TrimPrefix(strings.TrimSpace(id), "#"))
	if action == "clear" {
		k := 0
		for _, r := range a.reqs {
			if !r.Played {
				r.Played = true
				k++
			}
		}
		return fmt.Sprintf("Cleared %d waiting requests", k), nil
	}
	for i, r := range a.reqs {
		if (n == 0 && !r.Played) || r.ID == n {
			if action == "remove" {
				a.reqs = append(a.reqs[:i], a.reqs[i+1:]...)
				return "Removed " + r.Title, nil
			}
			r.Played = true
			return "✓ " + r.Title + " marked as played", nil
		}
	}
	return "", errors.New("no waiting request with that number")
}
