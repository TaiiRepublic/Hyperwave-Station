package main

import (
	"errors"
	"net/url"
	"strconv"
	"strings"
)

// spotifySource is Spotify through its Web API (needs Premium and a developer app). It can do everything.
type spotifySource struct{ a *App }

func (s *spotifySource) ID() string   { return "spotify" }
func (s *spotifySource) Name() string { return "Spotify" }
func (s *spotifySource) Ready() bool  { return s.a.sp.Connected() }
func (s *spotifySource) Caps() Caps {
	return Caps{Play: true, Pause: true, Next: true, Prev: true, Volume: true, Shuffle: true, Repeat: true,
		Queue: true, UpNext: true, Search: true, Playlists: true, Devices: true, Progress: true}
}

func (s *spotifySource) Poll() (*Snapshot, error) {
	p, err := s.a.sp.Player()
	if err != nil || p == nil {
		return nil, err
	}
	snap := &Snapshot{Playing: p.Playing, Track: p.Item.View(), Progress: p.Progress, Device: p.Device.Name,
		Volume: -1, Shuffle: p.Shuffle, Repeat: p.Repeat}
	if p.Device.Volume != nil {
		snap.Volume = *p.Device.Volume
	}
	if p.Context != nil {
		snap.Context = p.Context.URI
	}
	return snap, nil
}

func (s *spotifySource) Control(cmd, arg string) error {
	sp := s.a.sp
	var err error
	switch cmd {
	case "next":
		_, _, err = sp.Do("POST", "/me/player/next", nil, nil)
	case "prev":
		_, _, err = sp.Do("POST", "/me/player/previous", nil, nil)
	case "pause":
		_, _, err = sp.Do("PUT", "/me/player/pause", nil, nil)
	case "play":
		_, _, err = sp.Do("PUT", "/me/player/play", nil, nil)
	case "volume":
		_, _, err = sp.Do("PUT", "/me/player/volume", url.Values{"volume_percent": {arg}}, nil)
	case "shuffle":
		_, _, err = sp.Do("PUT", "/me/player/shuffle", url.Values{"state": {strconv.FormatBool(arg == "on")}}, nil)
	case "repeat":
		_, _, err = sp.Do("PUT", "/me/player/repeat", url.Values{"state": {arg}}, nil)
	default:
		return ErrUnsupported
	}
	if errors.Is(err, ErrNoDevice) {
		return errors.New("no active Spotify device. Start playing something on the streaming PC first")
	}
	return err
}

func (s *spotifySource) Find(input string) (*TrackView, error) {
	input = strings.TrimSpace(input)
	if kind, id := ParseLink(input); kind != "" {
		if kind != "track" {
			return nil, &notTrackErr{"Spotify " + kind}
		}
		t, err := s.a.sp.GetTrack(id)
		return t.View(), err
	}
	t, err := s.a.searchOne(input)
	return t.View(), err
}

func (s *spotifySource) Search(q string, limit int) ([]TrackView, error) {
	r, err := s.a.sp.Search(q, "track", limit)
	if err != nil {
		return nil, err
	}
	return r.Tracks, nil
}

func (s *spotifySource) Enqueue(t *TrackView) error {
	_, _, err := s.a.sp.Do("POST", "/me/player/queue", url.Values{"uri": {t.URI}}, nil)
	var ae *APIError
	if errors.As(err, &ae) && ae.Status == 403 {
		return errors.New("Spotify refused the queue (Premium required on the streamer's account)")
	}
	return err
}

func (s *spotifySource) PlayNow(t *TrackView) error {
	_, _, err := s.a.sp.Do("PUT", "/me/player/play", nil, map[string]any{"uris": []string{t.URI}})
	if errors.Is(err, ErrNoDevice) {
		return errors.New("no active Spotify device on the streaming PC")
	}
	return err
}

func (s *spotifySource) UpNext() ([]TrackView, error) {
	_, q, err := s.a.sp.Queue()
	if err != nil {
		return nil, err
	}
	out := []TrackView{}
	for i := range q {
		if v := q[i].View(); v != nil {
			out = append(out, *v)
		}
	}
	return out, nil
}
