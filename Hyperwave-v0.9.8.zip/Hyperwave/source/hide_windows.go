//go:build windows

package main

import (
	"os/exec"
	"syscall"
)

// hideWindow keeps cloudflared from popping its own console window.
func hideWindow(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}
