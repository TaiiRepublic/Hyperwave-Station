package main

import (
	"bufio"
	"bytes"
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// WinMedia follows whatever is playing through Windows' own media controls (the box that pops up
// when you press a media key). That covers Spotify Free, Apple Music, YouTube or SoundCloud in a
// browser, TIDAL, Deezer, Amazon Music, foobar2000, MusicBee and most other players, with no
// accounts. Windows only offers play/pause/next/previous (plus shuffle/repeat on some players),
// so requests go on a list the streamer plays from.
//
// Go can't call Windows' media API directly without extra build tools, so Station runs a small
// PowerShell helper (media/hyperwave-media.ps1) and talks to it over its input and output.

//go:embed media/hyperwave-media.ps1
var mediaHelper []byte

type WinMedia struct {
	a *App

	mu      sync.Mutex // one helper call at a time
	cmd     *exec.Cmd
	in      io.WriteCloser
	lines   chan []byte
	fatal   string
	lastErr string
	nextTry time.Time

	artFor   string
	artURL   string
	artTries int

	smu      sync.Mutex
	sessions []WinSession
}

type WinSession struct {
	App     string `json:"app"`
	Name    string `json:"name"`
	Playing bool   `json:"playing"`
}

type winCur struct {
	App         string `json:"app"`
	Title       string `json:"title"`
	Artist      string `json:"artist"`
	Album       string `json:"album"`
	AlbumArtist string `json:"albumArtist"`
	Status      int    `json:"status"` // 4 playing, 5 paused
	Pos         int64  `json:"pos"`
	Start       int64  `json:"start"`
	End         int64  `json:"end"`
	Updated     int64  `json:"updated"`
	CanPlay     bool   `json:"canPlay"`
	CanPause    bool   `json:"canPause"`
	CanNext     bool   `json:"canNext"`
	CanPrev     bool   `json:"canPrev"`
	CanShuffle  bool   `json:"canShuffle"`
	CanRepeat   bool   `json:"canRepeat"`
	Shuffle     bool   `json:"shuffle"`
	Repeat      int    `json:"repeat"`
	HasArt      bool   `json:"hasArt"`
}

type winResp struct {
	OK       bool            `json:"ok"`
	Ready    bool            `json:"ready"`
	Fatal    bool            `json:"fatal"`
	Error    string          `json:"error"`
	Sessions json.RawMessage `json:"sessions"`
	Cur      *winCur         `json:"cur"`
	Art      string          `json:"art"`
	Type     string          `json:"type"`
}

func (w *WinMedia) ID() string   { return "windows" }
func (w *WinMedia) Name() string { return "Windows media" }
func (w *WinMedia) Ready() bool  { return isWindows() || os.Getenv("HWS_SMTC_CMD") != "" }
func (w *WinMedia) Caps() Caps {
	return Caps{Play: true, Pause: true, Next: true, Prev: true, Progress: true}
}

// Sessions lists the players Windows knows about right now (for the dashboard's player picker).
func (w *WinMedia) Sessions() []WinSession {
	w.smu.Lock()
	defer w.smu.Unlock()
	return append([]WinSession{}, w.sessions...)
}

func (w *WinMedia) Status() string {
	if !w.mu.TryLock() {
		return "working"
	}
	defer w.mu.Unlock()
	switch {
	case !w.Ready():
		return "Windows media only works on Windows"
	case w.fatal != "":
		return w.fatal
	case w.cmd != nil:
		return "connected"
	case w.lastErr != "":
		return w.lastErr
	}
	return "off"
}

func psPath() string {
	if root := os.Getenv("SystemRoot"); root != "" {
		p := filepath.Join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return "powershell.exe"
}

// helperPath writes the helper script next to the settings file, so it's easy to look at.
func (w *WinMedia) helperPath() (string, error) {
	p := filepath.Join(filepath.Dir(w.a.st.path), "hyperwave-media.ps1")
	if old, err := os.ReadFile(p); err == nil && bytes.Equal(old, mediaHelper) {
		return p, nil
	}
	if err := os.WriteFile(p, mediaHelper, 0644); err != nil {
		p = filepath.Join(os.TempDir(), "hyperwave-media.ps1")
		if err := os.WriteFile(p, mediaHelper, 0644); err != nil {
			return "", err
		}
	}
	return p, nil
}

// start runs the helper if it isn't running. Call with w.mu held.
func (w *WinMedia) start() error {
	if w.cmd != nil {
		return nil
	}
	if w.fatal != "" && time.Now().Before(w.nextTry) {
		return errors.New(w.fatal)
	}
	if time.Now().Before(w.nextTry) {
		return errors.New("starting Windows media")
	}
	var c *exec.Cmd
	if t := os.Getenv("HWS_SMTC_CMD"); t != "" {
		f := strings.Fields(t)
		c = exec.Command(f[0], f[1:]...)
	} else {
		if !isWindows() {
			return errors.New("Windows media only works on Windows")
		}
		path, err := w.helperPath()
		if err != nil {
			return fmt.Errorf("couldn't save the media helper: %v", err)
		}
		c = exec.Command(psPath(), "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", path)
	}
	hideWindow(c)
	in, err := c.StdinPipe()
	if err != nil {
		return err
	}
	out, err := c.StdoutPipe()
	if err != nil {
		return err
	}
	var stderr bytes.Buffer
	c.Stderr = &stderr
	if err := c.Start(); err != nil {
		w.nextTry = time.Now().Add(30 * time.Second)
		w.lastErr = "couldn't start PowerShell: " + err.Error()
		return errors.New(w.lastErr)
	}
	lines := make(chan []byte, 4)
	go func() {
		r := bufio.NewReaderSize(out, 1<<16)
		for {
			b, err := r.ReadBytes('\n')
			if len(bytes.TrimSpace(b)) > 0 {
				lines <- bytes.TrimPrefix(bytes.TrimSpace(b), []byte("\xef\xbb\xbf"))
			}
			if err != nil {
				close(lines)
				return
			}
		}
	}()
	go c.Wait()
	w.cmd, w.in, w.lines = c, in, lines
	// first line says it's ready (PowerShell can take a few seconds the first time)
	select {
	case b, ok := <-lines:
		var r winResp
		if ok {
			json.Unmarshal(b, &r)
		}
		if !ok || !r.Ready {
			msg := r.Error
			if msg == "" {
				msg = strings.TrimSpace(stderr.String())
			}
			if msg == "" {
				msg = "the media helper stopped"
			}
			if l := strings.ToLower(msg); strings.Contains(l, "disabled on this system") || strings.Contains(l, "execution polic") || strings.Contains(l, "not digitally signed") {
				msg = "Windows blocked Hyperwave's media helper (a PowerShell script policy on this PC). Ask whoever manages this PC to allow PowerShell scripts, or pick another music source"
				r.Fatal = true
			}
			w.stopLocked()
			if r.Fatal {
				w.fatal = msg
				w.nextTry = time.Now().Add(2 * time.Minute)
			} else {
				w.lastErr = msg
				w.nextTry = time.Now().Add(10 * time.Second)
			}
			return errors.New(msg)
		}
	case <-time.After(25 * time.Second):
		w.stopLocked()
		w.lastErr = "Windows media didn't start in time"
		w.nextTry = time.Now().Add(10 * time.Second)
		return errors.New(w.lastErr)
	}
	w.fatal, w.lastErr = "", ""
	return nil
}

func (w *WinMedia) stopLocked() {
	if w.cmd != nil {
		if w.in != nil {
			w.in.Close()
		}
		if w.cmd.Process != nil {
			w.cmd.Process.Kill()
		}
	}
	w.cmd, w.in = nil, nil
}

// Close stops the helper (when you switch to another music source).
func (w *WinMedia) Close() {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.stopLocked()
}

func (w *WinMedia) call(cmd string, timeout time.Duration) (*winResp, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if err := w.start(); err != nil {
		return nil, err
	}
	for { // drop anything left over from a call that timed out
		select {
		case <-w.lines:
			continue
		default:
		}
		break
	}
	if _, err := io.WriteString(w.in, cmd+"\n"); err != nil {
		w.stopLocked()
		w.nextTry = time.Now().Add(2 * time.Second)
		return nil, errors.New("lost the media helper, restarting it")
	}
	select {
	case b, ok := <-w.lines:
		if !ok {
			w.stopLocked()
			w.nextTry = time.Now().Add(2 * time.Second)
			return nil, errors.New("the media helper stopped, restarting it")
		}
		var r winResp
		if err := json.Unmarshal(b, &r); err != nil {
			return nil, fmt.Errorf("the media helper said something odd: %.80s", b)
		}
		if !r.OK && r.Error != "" && r.Error != "nothing playing" {
			return &r, errors.New(r.Error)
		}
		return &r, nil
	case <-time.After(timeout):
		w.stopLocked()
		w.nextTry = time.Now().Add(2 * time.Second)
		return nil, errors.New("Windows media didn't answer in time")
	}
}

func (w *WinMedia) pref() string {
	p := strings.TrimSpace(w.a.st.Get().WinMediaApp)
	if p == "" {
		return "-"
	}
	return base64.StdEncoding.EncodeToString([]byte(p))
}

func (w *WinMedia) Poll() (*Snapshot, error) {
	r, err := w.call("state "+w.pref(), 8*time.Second)
	if err != nil {
		return nil, err
	}
	w.saveSessions(r.Sessions)
	c := r.Cur
	if c == nil || (c.Title == "" && c.Artist == "") || c.Status == 0 {
		w.artFor = ""
		return nil, nil
	}
	artist := c.Artist
	if artist == "" {
		artist = c.AlbumArtist
	}
	title := c.Title
	if artist == "" {
		// browsers often give "Artist - Song" as the title with no artist
		title, artist = splitVideoTitle(c.Title, "")
	}
	dur := c.End - c.Start
	if dur < 0 {
		dur = 0
	}
	pos := c.Pos - c.Start
	playing := c.Status == 4
	if playing && c.Updated > 0 && dur > 0 {
		if gap := time.Now().UnixMilli() - c.Updated; gap > 0 && gap < 6*3600*1000 {
			pos += gap
		}
	}
	if pos < 0 || dur == 0 {
		pos = 0
	}
	if pos > dur {
		pos = dur
	}
	t := &TrackView{URI: "win:" + normSong(title) + "|" + normSong(artist), Title: title, Artist: artist, Album: c.Album, Duration: int(dur)}
	// cover art: fetch when the song changes, and once more a moment later because some
	// players update the picture just after the title
	key := c.App + "|" + c.Title + "|" + c.Artist
	if key != w.artFor {
		w.artFor, w.artURL, w.artTries = key, "", 0
	}
	if c.HasArt && w.artTries < 2 {
		w.artTries++
		if ar, err := w.call("art "+w.pref(), 8*time.Second); err == nil && ar.Art != "" {
			if b, err := base64.StdEncoding.DecodeString(ar.Art); err == nil {
				w.artURL = arts.put(b, ar.Type)
			}
		}
	}
	t.Art = w.artURL
	repeat := map[int]string{0: "off", 1: "track", 2: "context"}[c.Repeat]
	caps := Caps{Play: c.CanPlay || c.CanPause, Pause: c.CanPlay || c.CanPause, Next: c.CanNext, Prev: c.CanPrev,
		Shuffle: c.CanShuffle, Repeat: c.CanRepeat, Progress: dur > 0}
	return &Snapshot{Playing: playing, Track: t, Progress: int(pos), Device: appName(c.App), Volume: -1,
		Shuffle: c.Shuffle, Repeat: repeat, Caps: &caps}, nil
}

func (w *WinMedia) saveSessions(raw json.RawMessage) {
	var list []WinSession
	if json.Unmarshal(raw, &list) != nil {
		var one WinSession
		if json.Unmarshal(raw, &one) == nil && one.App != "" {
			list = []WinSession{one}
		}
	}
	seen := map[string]bool{}
	out := []WinSession{}
	for _, s := range list {
		if s.App == "" || seen[s.App] {
			continue
		}
		seen[s.App] = true
		s.Name = appName(s.App)
		out = append(out, s)
	}
	w.smu.Lock()
	w.sessions = out
	w.smu.Unlock()
}

func (w *WinMedia) Control(cmd, arg string) error {
	v := ""
	switch cmd {
	case "play", "pause", "next", "prev", "toggle":
	case "shuffle":
		v = "0"
		if arg == "on" {
			v = "1"
		}
	case "repeat":
		v = map[string]string{"off": "0", "track": "1", "context": "2"}[arg]
		if v == "" {
			v = "0"
		}
	default:
		return ErrUnsupported
	}
	r, err := w.call("ctl "+w.pref()+" "+cmd+" "+v, 8*time.Second)
	if err != nil {
		return err
	}
	if r.Error == "nothing playing" {
		return errors.New("nothing is playing in Windows right now")
	}
	if !r.OK {
		return fmt.Errorf("%s didn't take that button (it may not support it)", playerName(w.a.State(), w))
	}
	return nil
}

func (w *WinMedia) Find(input string) (*TrackView, error)           { return catalogFind(input) }
func (w *WinMedia) Search(q string, limit int) ([]TrackView, error) { return nil, ErrUnsupported }
func (w *WinMedia) Enqueue(t *TrackView) error                      { return ErrUnsupported }
func (w *WinMedia) PlayNow(t *TrackView) error                      { return ErrUnsupported }
func (w *WinMedia) UpNext() ([]TrackView, error)                    { return nil, ErrUnsupported }
