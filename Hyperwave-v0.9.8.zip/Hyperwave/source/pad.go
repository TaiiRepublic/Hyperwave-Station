package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"
)

// My Deck: buttons the streamer designs themselves. Each button runs one or more steps in order,
// e.g. switch to the BRB scene, mute the mic, then post "be right back" in chat.

type PadStep struct {
	A string `json:"a"`           // action, same names as DeckDo, plus "wait"
	V string `json:"v,omitempty"` // value: scene, audio source, message, or seconds for wait
	P string `json:"p,omitempty"` // platform for chat messages
}

type PadButton struct {
	ID      string    `json:"id"`
	Label   string    `json:"label"`
	Icon    string    `json:"icon,omitempty"`
	Color   string    `json:"color,omitempty"`
	Confirm bool      `json:"confirm,omitempty"` // press and hold to run
	Steps   []PadStep `json:"steps"`
}

var padActions = map[string]bool{"scene": true, "clip": true, "replay": true, "twitchclip": true, "record": true,
	"stream-start": true, "stream-stop": true, "mute": true, "music-toggle": true, "music-skip": true, "music-prev": true,
	"requests": true, "say": true, "wait": true}

func newPadID() string {
	b := make([]byte, 5)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func defaultPad() []PadButton {
	return []PadButton{
		{ID: newPadID(), Label: "Clip that!", Icon: "🎬", Color: "#D7263D", Steps: []PadStep{{A: "clip"}}},
		{ID: newPadID(), Label: "Be right back", Icon: "☕", Color: "#F2A541", Steps: []PadStep{{A: "say", V: "Be right back, don't go anywhere!", P: "all"}}},
		{ID: newPadID(), Label: "Hydrate!", Icon: "💧", Color: "#3FC1C9", Steps: []PadStep{{A: "say", V: "Hydration check! Everyone grab a drink 💧", P: "all"}}},
		{ID: newPadID(), Label: "Play / pause", Icon: "⏯", Color: "#3FC98B", Steps: []PadStep{{A: "music-toggle"}}},
		{ID: newPadID(), Label: "Skip song", Icon: "⏭", Color: "#3FC98B", Steps: []PadStep{{A: "music-skip"}}},
		{ID: newPadID(), Label: "Record", Icon: "⏺", Color: "#8B5CF6", Steps: []PadStep{{A: "record"}}},
	}
}

func (a *App) padButtons() []PadButton {
	c := a.st.Get()
	if c.PadButtons == nil {
		d := defaultPad()
		a.st.Update(func(c *Config) {
			if c.PadButtons == nil {
				c.PadButtons = d
			}
		})
		return a.st.Get().PadButtons
	}
	return c.PadButtons
}

func cleanPad(in []PadButton) ([]PadButton, error) {
	if len(in) > 60 {
		return nil, errors.New("that's more than 60 buttons")
	}
	seen := map[string]bool{}
	out := make([]PadButton, 0, len(in))
	for i, b := range in {
		b.Label = strings.TrimSpace(b.Label)
		if len([]rune(b.Label)) > 40 {
			b.Label = string([]rune(b.Label)[:40])
		}
		if len([]rune(b.Icon)) > 4 {
			b.Icon = string([]rune(b.Icon)[:4])
		}
		if b.Color != "" && (len(b.Color) != 7 || b.Color[0] != '#') {
			b.Color = ""
		}
		if b.ID == "" || seen[b.ID] || len(b.ID) > 20 {
			b.ID = newPadID()
		}
		seen[b.ID] = true
		if len(b.Steps) == 0 {
			return nil, fmt.Errorf("button %d (%s) has nothing for it to do", i+1, b.Label)
		}
		if len(b.Steps) > 10 {
			return nil, fmt.Errorf("button %q has more than 10 steps", b.Label)
		}
		if b.Label == "" && b.Icon == "" {
			b.Label = "Button"
		}
		for j := range b.Steps {
			s := &b.Steps[j]
			s.A = strings.TrimSpace(s.A)
			if !padActions[s.A] {
				return nil, fmt.Errorf("button %q: step %d isn't something the deck can do", b.Label, j+1)
			}
			s.V = strings.TrimSpace(s.V)
			if len([]rune(s.V)) > 480 {
				return nil, fmt.Errorf("button %q: step %d's text is too long", b.Label, j+1)
			}
			if (s.A == "scene" || s.A == "mute" || s.A == "say") && s.V == "" {
				return nil, fmt.Errorf("button %q: step %d needs a %s", b.Label, j+1, map[string]string{"scene": "scene", "mute": "audio source", "say": "message"}[s.A])
			}
			if s.A == "wait" {
				f, err := strconv.ParseFloat(s.V, 64)
				if err != nil || f <= 0 || f > 10 {
					return nil, fmt.Errorf("button %q: waits can be 0.1 to 10 seconds", b.Label)
				}
			}
		}
		out = append(out, b)
	}
	return out, nil
}

// PadPress runs a My Deck button's steps in order.
func (a *App) PadPress(id string) (string, error) {
	var btn *PadButton
	for _, b := range a.padButtons() {
		if b.ID == id {
			bb := b
			btn = &bb
			break
		}
	}
	if btn == nil {
		return "", errors.New("that button doesn't exist any more. Copy its link again")
	}
	var done []string
	waited := 0.0
	for i, s := range btn.Steps {
		if s.A == "wait" {
			f, _ := strconv.ParseFloat(s.V, 64)
			if waited+f > 20 {
				f = 20 - waited
			}
			if f > 0 {
				time.Sleep(time.Duration(f * float64(time.Second)))
				waited += f
			}
			continue
		}
		msg, err := a.DeckDo(s.A, s.V, s.P)
		if err != nil {
			if len(btn.Steps) == 1 {
				return "", err
			}
			return "", fmt.Errorf("step %d stopped: %v", i+1, err)
		}
		done = append(done, msg)
	}
	name := btn.Label
	if name == "" {
		name = btn.Icon
	}
	if len(done) == 1 {
		return done[0], nil
	}
	return name + ": done", nil
}

func (a *App) padRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/deck/pad", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			b, _ := io.ReadAll(io.LimitReader(r.Body, 256<<10))
			var in []PadButton
			if err := json.Unmarshal(b, &in); err != nil {
				jsonOut(w, 400, map[string]any{"ok": false, "error": "couldn't read the buttons"})
				return
			}
			clean, err := cleanPad(in)
			if err != nil {
				jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
				return
			}
			a.st.Update(func(c *Config) { c.PadButtons = clean })
		}
		jsonOut(w, 200, map[string]any{"ok": true, "buttons": a.padButtons()})
	}))
}
