package main

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"math/rand"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

// The TAii logo drawn in text. Windows Terminal gets the fine Braille-dot version; the older
// Windows console (and anything else that might lack Braille glyphs) gets solid blocks.
const logoDots = `
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣾⣿⣿⣶⡀⠀⠀⠀⠀⣠⣾⣿⣿⣶⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⣿⣿⣿⣿⣿⡗
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⠿⠿⠛⠀⠀⠀⠀⠀⠘⠻⠿⠿⠟⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⠻⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⠏⠀⢻⣿⣿⣿⣷⡀⠀⠀⠀⠀⢀⡄⠀⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⡏⠀⠀⠀⢻⣿⣿⣿⣷⡀⠀⢀⣴⠟⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣼⣿⣿⣿⣿⣧⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣿⣿⡟⠀⠀⠀⠀⠀⢿⣿⡿⠟⣃⣴⡿⠋⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⡾⠿⠟⠛⠛⠛⠛⠿⢿⣏⢶⣶⠶⠶⣦⣀⠀⢺⣿⠻⢶⣝⢿⡟⠀⠀⠀⠀⠀⠀⣈⣡⣴⣾⡿⢋⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠉⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⡄⠀⠙⢷⣄⡈⠙⠷⣦⣹⣦⠀⠙⢷⣄⢠⣤⣤⣶⣾⣿⣿⡿⠟⣩⣤⣭⣥⣄⣀⣀⣀⡀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢳⣶⣖⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⡇⠀⠀⠀⠙⠻⣦⡀⠈⠙⠻⣷⣄⠀⠙⢷⣬⡻⠿⠛⠋⢁⣀⣀⣿⣶⣶⣾⣿⣿⣻⣟⠷⠖⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢶⠄⠀⠀⠘⠙⠻⣦⡀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠈⠻⣦⡀⠀⠀⠙⠻⣦⣀⣌⣿⣦⣠⣴⠟⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠻⢶⣤⡸⠿⣫⡶⠶⣦⣤⣄⣀⡀⠸⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣤⣄⣀⣀⣀⠀⠈⠙⢦⠀⠀⢾⡷⠀⢸⣿⣿⣿⣿⡇⠀⠀⣄⠀⠀⣰⣿⣮⡻⣦⡀⠀⢀⣠⡿⠿⠿⠿⣿⣷⡶⢶⣶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠾⠿⢿⣯⣤⣄⣠⣿⠉⠉⠛⠛⠶⢶⣭⡻
⠀⠀⠀⠀⢀⣠⠴⠖⠛⠋⠭⠭⠭⠭⢭⣭⣍⣛⠻⢿⣶⣦⣄⡀⠀⠀⠀⠘⠿⠿⠿⠿⠇⠀⠈⠛⠁⠰⠿⠿⢟⣭⣬⣿⣾⣿⣥⣤⣤⣴⣿⣋⠁⠀⣾⣧⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣀⣀⡉⠉⠙⠛⠳⠶⣦⣤⣾⠉⠻⣦⣀
⠀⠀⡠⠚⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡀⠈⠉⠛⢶⣤⣉⠛⠿⣿⣶⣦⣤⣤⣤⣄⣠⣤⣤⣤⣴⣶⣶⣿⡏⣾⠁⠀⣼⠃⠀⠀⠀⣼⠏⠉⠛⠿⢿⣶⣿⣿⣶⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠛⠛⠻⠶⠶⣶⣤⣬⣝⣻⣶⣬⣙⣷⣄⡀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠈⠙⠿⣶⣤⣈⡉⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡙⠶⣴⣿⣀⣀⠀⢠⡿⠀⠀⠀⠀⠀⠈⠉⣻⠏⠉⠙⠛⢻⣶⣶⣤⣤⣤⣤⣤⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠙⠛⠛⢿⡏⠙⢻⣦⡀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣆⣀⣀⣀⡉⠛⠿⠿⣷⣶⣶⣶⣶⣾⣿⣿⣿⣿⣿⠿⠿⠟⠊⢻⣏⠙⠛⢻⡟⣻⣿⠿⠛⠛⢛⣿⣿⠷⠶⠶⢦⣾⣿⣏⣀⡀⠀⠀⣿⣹⡷⠶⠶⠶⠶⠶⠶⠶⠶⠶⢶⣄⣀⣀⣈⣷⠀⢸⣿⡇
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢉⣉⠍⠀⠀⠀⢀⣰⣀⠀⠀⠀⠙⣛⣿⠿⠛⠋⢀⣠⣴⠾⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠉⠛⠛⠛⠛⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠻⣿⣍⣀⣸⡏⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⢿⡟⠉⠀⠀⠀⠀⠀⠈⠙⠁⠀⣀⣴⠾⠋⢁⣠⣴⠾⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⠛⠛⠛⠛⠉`

const logoBlocks = `
                                                              ▄████▄    ▄███▄
                   ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄        ▄▄▄▄             ▀████▀    █████
                   ██████████████████       ██████              ▀▀       ▀▀▀
                   ▀▀▀▀▀▀▀████▀▀▀▀▀▀▀      ████████            ▄▄▄▄     ▄▄▄▄▄
                          ████            ▄███▀▀████           ████     █████
                          ████           ▄███▀  ▀████   ▄▄     ████     █████
                         ▄████▄         ▄███▀    ▀███▀▄█▀      ████     █████
                     ▄█▀▀▀▀▀▀█▀▄▄▄▄▄  █▀▄▀██      ▀▄▄█▀        ████     █████
                          ███▄  ▀▄▄▀▀▄█▄ ▀█▄ ▄▄▄███▀▀▄▄▄▄      ████     █████
               ██         ████    ▀█▄  ▀█▄ ▀▀▄▀▀▀ ▄▄██▄▄████▀  ████     █████
                 ▀▄       ████      ▀█▄   ▀█▄▄█▄▄▀          ▀▀▄▀█▄▀▀▄▄▄▄▀████
        ▄▄▄▄▄▄▄▄▄▄     ▀  ████   ▄ ▄██▄▀▄ ▄▄▀▀▀██▀▀█▀▀▀▀▀▀▀▀▀▀▀▀▀ ▄▄█▄  ▀▀██
                ▄█▀▀█▄▄▄  ▀▀▀▀     ▄█ █▀██▀▀▀███▄▄▄███▀▀▀▀▀▀▀▀▀▀█▄▄▄▄▄ ▀▀▀█▄▀█▄
                  ▀▀▄▄▀▀▀████████████▀▄ █    █   ▀▀▀██▀▄▄▄▄           ▀▀▀▀▀▀████▄▄
                     ▀▀█▄▄▄▄▄██████████▀██▀▄██▄▄▄▄▄▄█▄▄▄▄██▀▀▀▀▀█▄▄▄▄▄▄▄▄▄▄▄   █  █▄
                 ▀▀▀       ▀▀▀▀▀▀▀▀▀     ▀▄▄█▀▀  ▄▄██▄▄████▀▀█▄██▀         ▀▀▀██ ▄█
                            ▄       ▀▀  ▄▄▀  ▄█▀▀                              ▀▀▀
                                       ▀▀▀▀▀▀`

var bridgeQuips = []string{
	"Hyperspace core spooled up. Ready when you are.",
	"All decks report ready: music, chat and requests standing by.",
	"Sensors are green. Go make some noise.",
	"Fleet comms online. Don't forget to hydrate, pilot.",
	"Navigation locked. Next stop: a great stream.",
	"The playlist is loaded and the chat is listening. Fly safe.",
	"Resource collectors are out. Let the good vibes roll in.",
	"Bridge to stream: you are cleared for launch.",
}

type aboutInfo struct {
	Name, Twitch, Kick, Tip, TipLabel string
}

// readWebFile prefers a file in the web folder next to the exe, like the dashboard does.
func readWebFile(name string) []byte {
	if b, err := os.ReadFile(filepath.Join(exeDir(), "web", name)); err == nil {
		return b
	}
	b, _ := fs.ReadFile(webFS, "web/"+name)
	return b
}

func shortURL(u string) string {
	u = strings.TrimPrefix(strings.TrimPrefix(u, "https://"), "http://")
	return strings.TrimSuffix(strings.TrimPrefix(u, "www."), "/")
}

func printBanner(c Config, settingsPath string) {
	// Colour only where it's known to work: Windows Terminal, or non-Windows terminals.
	wt := os.Getenv("WT_SESSION") != ""
	color := wt || runtime.GOOS != "windows"
	paint := func(code, s string) string {
		if !color {
			return s
		}
		return "\x1b[" + code + "m" + s + "\x1b[0m"
	}
	logo := logoBlocks
	if wt || runtime.GOOS != "windows" {
		logo = logoDots
	}
	for _, l := range strings.Split(strings.Trim(logo, "\n"), "\n") {
		fmt.Println("  " + paint("97", l))
	}
	fmt.Println()
	for _, l := range []string{
		"  ╦ ╦╦ ╦╔═╗╔═╗╦═╗╦ ╦╔═╗╦  ╦╔═╗   ╔═╗╔╦╗╔═╗╔╦╗╦╔═╗╔╗╔",
		"  ╠═╣╚╦╝╠═╝║╣ ╠╦╝║║║╠═╣╚╗╔╝║╣    ╚═╗ ║ ╠═╣ ║ ║║ ║║║║",
	} {
		fmt.Println(paint("96", l))
	}
	fmt.Println(paint("96", "  ╩ ╩ ╩ ╩  ╚═╝╩╚═╚╩╝╩ ╩ ╚╝ ╚═╝   ╚═╝ ╩ ╩ ╩ ╩ ╩╚═╝╝╚╝") + "  v" + Version)
	fmt.Println(paint("90", "  chat + music for your stream"))
	fmt.Println()
	fmt.Printf("  Dashboard ........ %s\n", paint("96", fmt.Sprintf("http://127.0.0.1:%d", c.Port)))
	fmt.Printf("  Hyperwave Chat ... %s\n", paint("96", fmt.Sprintf("http://127.0.0.1:%d/chat", c.Port)))
	fmt.Printf("  Hyperwave Deck ... %s\n", paint("96", fmt.Sprintf("http://127.0.0.1:%d/deck", c.Port)))
	fmt.Printf("  Now Playing ...... %s\n", paint("96", fmt.Sprintf("http://127.0.0.1:%d/overlay", c.Port)))
	fmt.Printf("  DJ deck (local) .. %s\n", paint("96", fmt.Sprintf("http://127.0.0.1:%d/dj", c.Port)))
	fmt.Printf("  Settings file .... %s\n", settingsPath)

	var ab aboutInfo
	json.Unmarshal(readWebFile("about.json"), &ab)
	name := ab.Name
	if name == "" {
		name = "TaiiRepublic"
	}
	fmt.Println()
	fmt.Println(paint("33", "  ── Transmission from the bridge ─────────────────────────────────"))
	fmt.Println("  Hey, I'm Taii. Hyperwave started as the tools I wanted for my own")
	fmt.Println("  stream on " + name + ", and now the whole fleet gets them. Free for")
	fmt.Println("  every streamer, no strings attached.")
	fmt.Println()
	if ab.Twitch != "" {
		fmt.Println("  Twitch ........... " + paint("96", shortURL(ab.Twitch)))
	}
	if ab.Kick != "" {
		fmt.Println("  Kick ............. " + paint("96", shortURL(ab.Kick)))
	}
	if ab.Tip != "" {
		fmt.Println("  Buy me a coffee .. " + paint("96", ab.Tip))
	}
	fmt.Println("  Found a bug? ..... Send feedback from the About section of the dashboard.")
	fmt.Println()
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	fmt.Println("  " + paint("1;33", "o7") + "  " + bridgeQuips[r.Intn(len(bridgeQuips))])
	fmt.Println("  " + paint("1;96", "New in v"+Version) + "  See What's new on the dashboard.")
	fmt.Println()
	fmt.Println(paint("90", "  Keep this window open while you stream. Close it to quit."))
	fmt.Println()
}
