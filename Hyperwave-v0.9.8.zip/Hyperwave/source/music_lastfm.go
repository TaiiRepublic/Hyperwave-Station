package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"strings"
	"sync"
	"time"
)

// LastFM shows what you're scrobbling to Last.fm. It works with anything that scrobbles (phone,
// console, Plex, vinyl apps, Spotify on another device), but it can only read, not control, and
// Last.fm only knows the song, not where in it you are.

var lastfmAPI = envOr("HWS_LASTFM", "https://ws.audioscrobbler.com/2.0/")

type LastFM struct {
	a *App

	mu     sync.Mutex
	last   time.Time
	snap   *Snapshot
	err    error
	status string
}

func (l *LastFM) ID() string   { return "lastfm" }
func (l *LastFM) Name() string { return "Last.fm" }
func (l *LastFM) Ready() bool {
	c := l.a.st.Get()
	return strings.TrimSpace(c.LastfmUser) != "" && strings.TrimSpace(c.LastfmKey) != ""
}
func (l *LastFM) Caps() Caps { return Caps{} }

func (l *LastFM) Status() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.status
}

type lfmText struct {
	Text string `json:"#text"`
}

// Last.fm sends a list when there are several tracks and a single object when there's one.
type lfmTracks []lfmTrack

func (t *lfmTracks) UnmarshalJSON(b []byte) error {
	var list []lfmTrack
	if json.Unmarshal(b, &list) == nil {
		*t = list
		return nil
	}
	var one lfmTrack
	if err := json.Unmarshal(b, &one); err != nil {
		return err
	}
	*t = []lfmTrack{one}
	return nil
}

type lfmTrack struct {
	Name   string  `json:"name"`
	URL    string  `json:"url"`
	Artist lfmText `json:"artist"`
	Album  lfmText `json:"album"`
	Image  []struct {
		Size string `json:"size"`
		Text string `json:"#text"`
	} `json:"image"`
	Attr *struct {
		NowPlaying string `json:"nowplaying"`
	} `json:"@attr"`
}

func (l *LastFM) Poll() (*Snapshot, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	// Last.fm asks apps not to hammer it; every 5 seconds is plenty for a song change
	if time.Since(l.last) < 5*time.Second {
		return l.snap, l.err
	}
	l.last = time.Now()
	c := l.a.st.Get()
	q := url.Values{"method": {"user.getrecenttracks"}, "user": {strings.TrimSpace(c.LastfmUser)}, "api_key": {strings.TrimSpace(c.LastfmKey)},
		"format": {"json"}, "limit": {"1"}}
	var r struct {
		Error   int    `json:"error"`
		Message string `json:"message"`
		Recent  struct {
			Track lfmTracks `json:"track"`
		} `json:"recenttracks"`
	}
	res, err := lookupHTTP.Get(lastfmAPI + "?" + q.Encode())
	if err == nil {
		err = json.NewDecoder(res.Body).Decode(&r)
		res.Body.Close()
		if err != nil {
			err = fmt.Errorf("Last.fm answered %d", res.StatusCode)
		}
	}
	if err == nil && r.Error != 0 {
		switch r.Error {
		case 10, 26:
			err = errors.New("Last.fm didn't accept the API key. Check it on the dashboard")
		case 6:
			err = errors.New("Last.fm can't find that username")
		case 17:
			err = errors.New("that Last.fm profile hides its listening. Turn off \"Hide recent listening\" in Last.fm privacy settings")
		default:
			err = fmt.Errorf("Last.fm said: %s", r.Message)
		}
	}
	if err != nil {
		l.err, l.status = err, err.Error()
		return l.snap, err
	}
	l.err, l.snap, l.status = nil, nil, "connected"
	for _, t := range r.Recent.Track {
		if t.Attr == nil || t.Attr.NowPlaying != "true" {
			continue
		}
		art := ""
		for _, im := range t.Image {
			if im.Text != "" && !strings.Contains(im.Text, "2a96cbd8b46e442fc41c2b86b821562f") { // Last.fm's blank star picture
				art = im.Text
			}
		}
		l.snap = &Snapshot{Playing: true, Volume: -1, Device: "Last.fm", Track: &TrackView{
			URI: "lfm:" + normSong(t.Name) + "|" + normSong(t.Artist.Text), Title: t.Name, Artist: t.Artist.Text,
			Album: t.Album.Text, Art: art, Link: t.URL}}
		break
	}
	return l.snap, nil
}

func (l *LastFM) Control(cmd, arg string) error                   { return ErrUnsupported }
func (l *LastFM) Find(input string) (*TrackView, error)           { return catalogFind(input) }
func (l *LastFM) Search(q string, limit int) ([]TrackView, error) { return nil, ErrUnsupported }
func (l *LastFM) Enqueue(t *TrackView) error                      { return ErrUnsupported }
func (l *LastFM) PlayNow(t *TrackView) error                      { return ErrUnsupported }
func (l *LastFM) UpNext() ([]TrackView, error)                    { return nil, ErrUnsupported }
