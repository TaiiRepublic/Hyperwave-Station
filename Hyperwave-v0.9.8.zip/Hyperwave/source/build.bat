@echo off
REM Requires Go 1.22+ from https://go.dev/dl/
go build -trimpath -ldflags "-s -w" -o ..\HyperwaveStation.exe .
echo Built HyperwaveStation.exe
pause
