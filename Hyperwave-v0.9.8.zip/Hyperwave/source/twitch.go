package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

// Twitch login for clips and chat replies, using Twitch's "device code" sign-in: the streamer
// opens twitch.tv/activate, types a short code, and approves. No passwords or secrets touch the app.
// Each streamer makes their own free Twitch app (Public client) and pastes its Client ID.

var (
	twitchID  = envOr("HWS_TWITCH_ID", "https://id.twitch.tv")
	twitchAPI = envOr("HWS_TWITCH_API", "https://api.twitch.tv/helix")
)

const twitchScopes = "clips:edit user:write:chat"

type Twitch struct {
	st   *Store
	http *http.Client

	mu      sync.Mutex
	access  string
	exp     time.Time
	login   *twitchLogin
	LastErr string
}

type twitchLogin struct {
	Code    string    `json:"code"`
	URL     string    `json:"url"`
	Expires time.Time `json:"expires"`
	State   string    `json:"state"` // waiting | done | expired | error
	Error   string    `json:"error,omitempty"`
	device  string
	gen     int
}

func NewTwitch(st *Store) *Twitch {
	return &Twitch{st: st, http: &http.Client{Timeout: 12 * time.Second}}
}

func (t *Twitch) Connected() bool {
	c := t.st.Get()
	return c.TwitchRefresh != "" && c.TwitchAppID != ""
}

func (t *Twitch) Status() map[string]any {
	c := t.st.Get()
	t.mu.Lock()
	defer t.mu.Unlock()
	out := map[string]any{"connected": c.TwitchRefresh != "" && c.TwitchAppID != "", "login": c.TwitchLogin, "hasApp": c.TwitchAppID != "", "lastError": t.LastErr}
	if t.login != nil {
		l := *t.login
		if l.State == "waiting" && time.Now().After(l.Expires) {
			l.State = "expired"
		}
		out["signin"] = l
	}
	return out
}

type twTok struct {
	Access  string `json:"access_token"`
	Refresh string `json:"refresh_token"`
	Expires int    `json:"expires_in"`
	Message string `json:"message"`
	Status  int    `json:"status"`
}

func (t *Twitch) post(path string, form url.Values) (*twTok, int, error) {
	res, err := t.http.PostForm(twitchID+path, form)
	if err != nil {
		return nil, 0, err
	}
	defer res.Body.Close()
	b, _ := io.ReadAll(res.Body)
	var tk twTok
	json.Unmarshal(b, &tk)
	return &tk, res.StatusCode, nil
}

// StartLogin begins a device-code sign-in and polls for approval in the background.
func (t *Twitch) StartLogin() (*twitchLogin, error) {
	c := t.st.Get()
	if c.TwitchAppID == "" {
		return nil, errors.New("paste your Twitch app's Client ID first")
	}
	res, err := t.http.PostForm(twitchID+"/oauth2/device", url.Values{"client_id": {c.TwitchAppID}, "scopes": {twitchScopes}})
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	b, _ := io.ReadAll(res.Body)
	var d struct {
		Device   string `json:"device_code"`
		User     string `json:"user_code"`
		URI      string `json:"verification_uri"`
		Expires  int    `json:"expires_in"`
		Interval int    `json:"interval"`
		Message  string `json:"message"`
	}
	json.Unmarshal(b, &d)
	if res.StatusCode != 200 || d.Device == "" {
		msg := d.Message
		if msg == "" {
			msg = strings.TrimSpace(string(b))
		}
		if strings.Contains(strings.ToLower(msg), "client") {
			msg += ". Check the Client ID, and that the Twitch app's Client Type is Public"
		}
		return nil, fmt.Errorf("Twitch said: %s", msg)
	}
	if d.Interval < 1 {
		d.Interval = 5
	}
	t.mu.Lock()
	gen := 1
	if t.login != nil {
		gen = t.login.gen + 1
	}
	l := &twitchLogin{Code: d.User, URL: d.URI, Expires: time.Now().Add(time.Duration(d.Expires) * time.Second), State: "waiting", device: d.Device, gen: gen}
	t.login = l
	t.mu.Unlock()
	go t.poll(l, c.TwitchAppID, time.Duration(d.Interval)*time.Second)
	cp := *l
	return &cp, nil
}

func (t *Twitch) poll(l *twitchLogin, client string, every time.Duration) {
	for time.Now().Before(l.Expires) {
		time.Sleep(every)
		t.mu.Lock()
		current := t.login == l
		t.mu.Unlock()
		if !current {
			return
		}
		tk, code, err := t.post("/oauth2/token", url.Values{"client_id": {client}, "scopes": {twitchScopes}, "device_code": {l.device},
			"grant_type": {"urn:ietf:params:oauth:grant-type:device_code"}})
		if err != nil {
			continue
		}
		if code == 200 && tk.Access != "" {
			t.mu.Lock()
			t.access, t.exp = tk.Access, time.Now().Add(time.Duration(tk.Expires-60)*time.Second)
			t.LastErr = ""
			t.mu.Unlock()
			t.st.Update(func(c *Config) { c.TwitchRefresh = tk.Refresh })
			if err := t.loadUser(); err != nil {
				t.setLogin(l, "error", err.Error())
				return
			}
			t.setLogin(l, "done", "")
			log.Println("[twitch] signed in as " + t.st.Get().TwitchLogin)
			return
		}
		m := strings.ToLower(tk.Message)
		switch {
		case strings.Contains(m, "pending"):
		case strings.Contains(m, "slow_down"):
			every += 2 * time.Second
		case strings.Contains(m, "denied"):
			t.setLogin(l, "error", "Sign-in was cancelled on Twitch.")
			return
		default:
			if code >= 400 && !strings.Contains(m, "pending") {
				t.setLogin(l, "error", "Twitch said: "+tk.Message)
				return
			}
		}
	}
	t.setLogin(l, "expired", "")
}

func (t *Twitch) setLogin(l *twitchLogin, state, msg string) {
	t.mu.Lock()
	if t.login == l {
		l.State, l.Error = state, msg
	}
	t.mu.Unlock()
}

func (t *Twitch) Logout() {
	t.mu.Lock()
	t.access, t.login = "", nil
	t.mu.Unlock()
	t.st.Update(func(c *Config) { c.TwitchRefresh, c.TwitchUserID, c.TwitchLogin = "", "", "" })
}

func (t *Twitch) token() (string, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.access != "" && time.Now().Before(t.exp) {
		return t.access, nil
	}
	c := t.st.Get()
	if c.TwitchRefresh == "" || c.TwitchAppID == "" {
		return "", errors.New("Twitch isn't signed in. Sign in under OBS & Deck → Twitch on the dashboard")
	}
	tk, code, err := t.post("/oauth2/token", url.Values{"client_id": {c.TwitchAppID}, "grant_type": {"refresh_token"}, "refresh_token": {c.TwitchRefresh}})
	if err != nil {
		return "", err
	}
	if code != 200 || tk.Access == "" {
		t.LastErr = "Twitch ended this sign-in (" + tk.Message + "). Sign in again."
		if code == 400 || code == 401 {
			t.st.Update(func(c *Config) { c.TwitchRefresh = "" })
		}
		return "", errors.New(t.LastErr)
	}
	t.access, t.exp = tk.Access, time.Now().Add(time.Duration(tk.Expires-60)*time.Second)
	if tk.Refresh != "" && tk.Refresh != c.TwitchRefresh {
		t.st.Update(func(c *Config) { c.TwitchRefresh = tk.Refresh })
	}
	t.LastErr = ""
	return t.access, nil
}

func (t *Twitch) helix(method, path string, body any) (int, []byte, error) {
	for attempt := 0; attempt < 2; attempt++ {
		tok, err := t.token()
		if err != nil {
			return 0, nil, err
		}
		var rdr io.Reader
		if body != nil {
			b, _ := json.Marshal(body)
			rdr = bytes.NewReader(b)
		}
		req, _ := http.NewRequest(method, twitchAPI+path, rdr)
		req.Header.Set("Authorization", "Bearer "+tok)
		req.Header.Set("Client-Id", t.st.Get().TwitchAppID)
		if body != nil {
			req.Header.Set("Content-Type", "application/json")
		}
		res, err := t.http.Do(req)
		if err != nil {
			return 0, nil, err
		}
		b, _ := io.ReadAll(res.Body)
		res.Body.Close()
		if res.StatusCode == 401 && attempt == 0 {
			t.mu.Lock()
			t.access = ""
			t.mu.Unlock()
			continue
		}
		return res.StatusCode, b, nil
	}
	return 401, nil, errors.New("Twitch rejected the sign-in. Sign in again on the dashboard")
}

func helixMsg(b []byte) string {
	var e struct {
		Message string `json:"message"`
	}
	json.Unmarshal(b, &e)
	return e.Message
}

func (t *Twitch) loadUser() error {
	code, b, err := t.helix("GET", "/users", nil)
	if err != nil {
		return err
	}
	var r struct {
		Data []struct {
			ID    string `json:"id"`
			Login string `json:"login"`
			Name  string `json:"display_name"`
		} `json:"data"`
	}
	json.Unmarshal(b, &r)
	if code != 200 || len(r.Data) == 0 {
		return fmt.Errorf("couldn't read your Twitch account (%d %s)", code, helixMsg(b))
	}
	u := r.Data[0]
	name := u.Name
	if name == "" {
		name = u.Login
	}
	t.st.Update(func(c *Config) { c.TwitchUserID, c.TwitchLogin = u.ID, name })
	return nil
}

func (t *Twitch) userID() (string, error) {
	if id := t.st.Get().TwitchUserID; id != "" {
		return id, nil
	}
	if err := t.loadUser(); err != nil {
		return "", err
	}
	return t.st.Get().TwitchUserID, nil
}

// CreateClip makes a Twitch clip of the live stream and returns its link.
func (t *Twitch) CreateClip() (string, error) {
	id, err := t.userID()
	if err != nil {
		return "", err
	}
	code, b, err := t.helix("POST", "/clips?broadcaster_id="+url.QueryEscape(id), nil)
	if err != nil {
		return "", err
	}
	var r struct {
		Data []struct {
			ID string `json:"id"`
		} `json:"data"`
	}
	json.Unmarshal(b, &r)
	if code != 202 && code != 200 || len(r.Data) == 0 {
		msg := helixMsg(b)
		if code == 404 || strings.Contains(strings.ToLower(msg), "offline") || strings.Contains(strings.ToLower(msg), "not live") {
			return "", errors.New("Twitch clips only work while you're live")
		}
		if code == 403 {
			return "", errors.New("Twitch didn't allow the clip. Sign in again so Hyperwave gets clip permission")
		}
		return "", fmt.Errorf("Twitch couldn't make the clip (%d %s)", code, msg)
	}
	return "https://clips.twitch.tv/" + r.Data[0].ID, nil
}

// SendChat posts a message in your own Twitch chat as you.
func (t *Twitch) SendChat(msg string) error {
	id, err := t.userID()
	if err != nil {
		return err
	}
	code, b, err := t.helix("POST", "/chat/messages", map[string]string{"broadcaster_id": id, "sender_id": id, "message": msg})
	if err != nil {
		return err
	}
	var r struct {
		Data []struct {
			Sent bool `json:"is_sent"`
			Drop *struct {
				Message string `json:"message"`
			} `json:"drop_reason"`
		} `json:"data"`
	}
	json.Unmarshal(b, &r)
	if code != 200 || len(r.Data) == 0 {
		return fmt.Errorf("Twitch didn't send it (%d %s)", code, helixMsg(b))
	}
	if !r.Data[0].Sent {
		why := "it was blocked"
		if r.Data[0].Drop != nil && r.Data[0].Drop.Message != "" {
			why = r.Data[0].Drop.Message
		}
		return errors.New("Twitch didn't post it: " + why)
	}
	return nil
}
