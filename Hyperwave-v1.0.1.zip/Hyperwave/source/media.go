package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------------- your pictures and sounds for My Deck ----------------
//
// Uploaded button pictures (PNG, JPG, GIF incl. animated, WebP) and sound files (MP3, WAV, OGG,
// M4A, FLAC) are kept in a "hyperwave-media" folder next to the settings file.

type MediaItem struct {
	File string `json:"file"` // name on disk, e.g. 3fa9c2d81b.gif
	Kind string `json:"kind"` // image | sound
	Name string `json:"name"` // the name it was uploaded with
	Size int64  `json:"size"`
	At   int64  `json:"at"`
}

type Media struct {
	a      *App
	mu     sync.Mutex
	items  []MediaItem
	loaded bool
}

var mediaFileRe = regexp.MustCompile(`^[0-9a-f]{12}\.(png|jpg|gif|webp|mp3|wav|ogg|m4a|flac)$`)

const (
	maxImageBytes = 8 << 20
	maxSoundBytes = 15 << 20
)

func (m *Media) dir() string { return filepath.Join(filepath.Dir(m.a.st.path), "hyperwave-media") }

func (m *Media) load() {
	if m.loaded {
		return
	}
	m.loaded = true
	b, err := os.ReadFile(filepath.Join(m.dir(), "media.json"))
	if err == nil {
		json.Unmarshal(b, &m.items)
	}
	// keep only entries whose file is still there
	out := m.items[:0]
	for _, it := range m.items {
		if _, err := os.Stat(filepath.Join(m.dir(), it.File)); err == nil {
			out = append(out, it)
		}
	}
	m.items = out
}

func (m *Media) save() {
	os.MkdirAll(m.dir(), 0755)
	b, _ := json.MarshalIndent(m.items, "", " ")
	os.WriteFile(filepath.Join(m.dir(), "media.json"), b, 0644)
}

// sniff works out what a file really is from its first bytes.
func sniffMedia(b []byte) (kind, ext string) {
	if len(b) < 12 {
		return "", ""
	}
	switch {
	case bytes.HasPrefix(b, []byte("\x89PNG")):
		return "image", "png"
	case bytes.HasPrefix(b, []byte{0xFF, 0xD8, 0xFF}):
		return "image", "jpg"
	case bytes.HasPrefix(b, []byte("GIF8")):
		return "image", "gif"
	case bytes.HasPrefix(b, []byte("RIFF")) && string(b[8:12]) == "WEBP":
		return "image", "webp"
	case bytes.HasPrefix(b, []byte("RIFF")) && string(b[8:12]) == "WAVE":
		return "sound", "wav"
	case bytes.HasPrefix(b, []byte("ID3")), b[0] == 0xFF && b[1]&0xE0 == 0xE0:
		return "sound", "mp3"
	case bytes.HasPrefix(b, []byte("OggS")):
		return "sound", "ogg"
	case bytes.HasPrefix(b, []byte("fLaC")):
		return "sound", "flac"
	case string(b[4:8]) == "ftyp":
		return "sound", "m4a"
	}
	return "", ""
}

func mediaType(file string) string {
	switch filepath.Ext(file) {
	case ".png":
		return "image/png"
	case ".jpg":
		return "image/jpeg"
	case ".gif":
		return "image/gif"
	case ".webp":
		return "image/webp"
	case ".mp3":
		return "audio/mpeg"
	case ".wav":
		return "audio/wav"
	case ".ogg":
		return "audio/ogg"
	case ".m4a":
		return "audio/mp4"
	case ".flac":
		return "audio/flac"
	}
	return "application/octet-stream"
}

// Add saves an uploaded file after checking it really is a picture or a sound.
func (m *Media) Add(want, name string, body io.Reader) (MediaItem, error) {
	limit := int64(maxImageBytes)
	if want == "sound" {
		limit = maxSoundBytes
	}
	b, err := io.ReadAll(io.LimitReader(body, limit+1))
	if err != nil {
		return MediaItem{}, err
	}
	if int64(len(b)) > limit {
		return MediaItem{}, fmt.Errorf("that file is too big (the most is %d MB)", limit>>20)
	}
	kind, ext := sniffMedia(b)
	if kind == "" || kind != want {
		if want == "image" {
			return MediaItem{}, errors.New("that isn't a picture Hyperwave can use. Use a PNG, JPG, GIF or WebP file")
		}
		return MediaItem{}, errors.New("that isn't a sound file Hyperwave can use. Use an MP3, WAV, OGG, M4A or FLAC file")
	}
	r := make([]byte, 6)
	rand.Read(r)
	it := MediaItem{File: hex.EncodeToString(r) + "." + ext, Kind: kind, Size: int64(len(b)), At: time.Now().Unix()}
	name = strings.TrimSpace(filepath.Base(strings.ReplaceAll(name, "\\", "/")))
	name = strings.TrimSuffix(name, filepath.Ext(name))
	if name == "" || name == "." {
		name = kind
	}
	if len([]rune(name)) > 60 {
		name = string([]rune(name)[:60])
	}
	it.Name = name
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	if err := os.MkdirAll(m.dir(), 0755); err != nil {
		return MediaItem{}, err
	}
	if err := os.WriteFile(filepath.Join(m.dir(), it.File), b, 0644); err != nil {
		return MediaItem{}, fmt.Errorf("couldn't save the file: %v", err)
	}
	m.items = append(m.items, it)
	m.save()
	return it, nil
}

func (m *Media) List(kind string) []MediaItem {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	out := []MediaItem{}
	for _, it := range m.items {
		if kind == "" || it.Kind == kind {
			out = append(out, it)
		}
	}
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name) })
	return out
}

func (m *Media) Find(file string) (MediaItem, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	for _, it := range m.items {
		if it.File == file {
			return it, true
		}
	}
	return MediaItem{}, false
}

func (m *Media) Rename(file, name string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	name = strings.TrimSpace(name)
	if name == "" {
		return errors.New("type a name")
	}
	for i := range m.items {
		if m.items[i].File == file {
			m.items[i].Name = name
			m.save()
			return nil
		}
	}
	return errors.New("that file is gone")
}

func (m *Media) Delete(file string) error {
	if !mediaFileRe.MatchString(file) {
		return errors.New("that file is gone")
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	for i, it := range m.items {
		if it.File == file {
			m.items = append(m.items[:i], m.items[i+1:]...)
			os.Remove(filepath.Join(m.dir(), file))
			m.save()
			return nil
		}
	}
	return errors.New("that file is gone")
}

func (m *Media) Serve(w http.ResponseWriter, r *http.Request, file, kind string) {
	it, ok := m.Find(file)
	if !ok || !mediaFileRe.MatchString(file) || (kind != "" && it.Kind != kind) {
		http.NotFound(w, r)
		return
	}
	f, err := os.Open(filepath.Join(m.dir(), file))
	if err != nil {
		http.NotFound(w, r)
		return
	}
	defer f.Close()
	w.Header().Set("Content-Type", mediaType(file))
	w.Header().Set("Cache-Control", "private, max-age=31536000, immutable")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	st, _ := f.Stat()
	http.ServeContent(w, r, file, st.ModTime(), f)
}

func (a *App) mediaRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/deck/media", wrap(func(w http.ResponseWriter, r *http.Request) {
		// read from the address only: the body is the file itself
		qs := r.URL.Query()
		kind := qs.Get("kind")
		if kind != "image" && kind != "sound" {
			kind = ""
		}
		if r.Method == "POST" {
			if kind == "" {
				jsonOut(w, 400, map[string]any{"ok": false, "error": "picture or sound?"})
				return
			}
			it, err := a.media.Add(kind, qs.Get("name"), r.Body)
			if err != nil {
				jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
				return
			}
			jsonOut(w, 200, map[string]any{"ok": true, "item": it})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "items": a.media.List(kind)})
	}))
	m.HandleFunc("/api/deck/media/edit", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		var err error
		if r.FormValue("delete") == "1" {
			if a.mediaInUse(r.FormValue("file")) {
				err = errors.New("a button still uses it. Change that button first")
			} else {
				err = a.media.Delete(r.FormValue("file"))
			}
		} else {
			err = a.media.Rename(r.FormValue("file"), r.FormValue("name"))
		}
		if err != nil {
			jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "items": a.media.List(r.FormValue("kind"))})
	}))
	m.HandleFunc("/api/deck/media/file/", wrap(func(w http.ResponseWriter, r *http.Request) {
		a.media.Serve(w, r, strings.TrimPrefix(r.URL.Path, "/api/deck/media/file/"), "")
	}))
}

func (a *App) mediaInUse(file string) bool {
	for _, b := range a.padButtons() {
		if b.Image == file {
			return true
		}
		for _, s := range b.Steps {
			if s.A == "sound" && s.V == file {
				return true
			}
		}
	}
	return false
}

// ---------------- sound player (a browser source in OBS) ----------------
//
// Sounds play through a small invisible page, /sounds, that sits in OBS as a browser source,
// so they go out on stream (and to your headphones through OBS monitoring). Hyperwave can add
// it to every scene for you.

type SoundEvent struct {
	ID   int    `json:"id"`
	Kind string `json:"kind"` // play | stop
	File string `json:"file,omitempty"`
	Vol  int    `json:"vol,omitempty"`
}

type Sounds struct {
	mu       sync.Mutex
	seq      int
	events   []SoundEvent
	wake     chan struct{}
	lastSeen time.Time
}

func (s *Sounds) push(e SoundEvent) {
	s.mu.Lock()
	s.seq++
	e.ID = s.seq
	s.events = append(s.events, e)
	if len(s.events) > 30 {
		s.events = s.events[len(s.events)-30:]
	}
	if s.wake != nil {
		close(s.wake)
		s.wake = nil
	}
	s.mu.Unlock()
}

// PlayerOnline is true when the sound player page has checked in recently.
func (s *Sounds) PlayerOnline() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return time.Since(s.lastSeen) < 40*time.Second
}

func (s *Sounds) wait(after int, max time.Duration) []SoundEvent {
	deadline := time.After(max)
	for {
		s.mu.Lock()
		s.lastSeen = time.Now()
		if after > s.seq { // Station restarted since the page last looked
			after = 0
		}
		var out []SoundEvent
		for _, e := range s.events {
			if e.ID > after {
				out = append(out, e)
			}
		}
		if len(out) > 0 || after < 0 {
			s.mu.Unlock()
			return out
		}
		if s.wake == nil {
			s.wake = make(chan struct{})
		}
		ch := s.wake
		s.mu.Unlock()
		select {
		case <-ch:
		case <-deadline:
			s.mu.Lock()
			s.lastSeen = time.Now()
			s.mu.Unlock()
			return nil
		}
	}
}

func (a *App) PlaySound(file, vol string) (string, error) {
	it, ok := a.media.Find(file)
	if !ok || it.Kind != "sound" {
		return "", errors.New("that sound file is gone. Pick it again in the button editor")
	}
	v, _ := strconv.Atoi(vol)
	if v <= 0 || v > 100 {
		v = 100
	}
	a.sounds.push(SoundEvent{Kind: "play", File: file, Vol: v})
	if !a.sounds.PlayerOnline() {
		return "", errors.New("the sound player isn't in OBS yet. Add it on the dashboard under OBS & Deck → Sounds")
	}
	return "🔊 " + it.Name, nil
}

func (a *App) StopSounds() (string, error) {
	a.sounds.push(SoundEvent{Kind: "stop"})
	return "🔇 Sounds stopped", nil
}

func (a *App) soundRoutes(m *http.ServeMux, open, g func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/sounds", open(func(w http.ResponseWriter, r *http.Request) { serveWeb(w, r, "sounds.html") }))
	m.HandleFunc("/api/sounds/wait", open(func(w http.ResponseWriter, r *http.Request) {
		after, err := strconv.Atoi(r.FormValue("after"))
		if err != nil {
			// first look: start from now
			a.sounds.mu.Lock()
			a.sounds.lastSeen = time.Now()
			seq := a.sounds.seq
			a.sounds.mu.Unlock()
			jsonOut(w, 200, map[string]any{"last": seq, "events": []SoundEvent{}})
			return
		}
		ev := a.sounds.wait(after, 25*time.Second)
		last := after
		for _, e := range ev {
			if e.ID > last {
				last = e.ID
			}
		}
		if ev == nil {
			ev = []SoundEvent{}
		}
		jsonOut(w, 200, map[string]any{"last": last, "events": ev})
	}))
	m.HandleFunc("/api/sounds/file/", open(func(w http.ResponseWriter, r *http.Request) {
		a.media.Serve(w, r, strings.TrimPrefix(r.URL.Path, "/api/sounds/file/"), "sound")
	}))
	m.HandleFunc("/api/sounds/status", g(func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, 200, map[string]any{"player": a.sounds.PlayerOnline(), "obs": a.obs.State().Connected})
	}))
	m.HandleFunc("/api/sounds/obs-setup", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		msg, err := a.obs.SetupSoundPlayer(fmt.Sprintf("http://127.0.0.1:%d/sounds", a.st.Get().Port))
		if err != nil {
			jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		log.Println("[sounds] " + msg)
		jsonOut(w, 200, map[string]any{"ok": true, "message": msg})
	}))
	m.HandleFunc("/api/sounds/test", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		a.sounds.push(SoundEvent{Kind: "test", Vol: 60})
		jsonOut(w, 200, map[string]any{"ok": true, "player": a.sounds.PlayerOnline()})
	}))
}

const soundPlayerName = "Hyperwave Sounds"

// SetupSoundPlayer adds the sound player browser source to every scene in OBS.
func (o *OBS) SetupSoundPlayer(url string) (string, error) {
	if !o.State().Connected {
		return "", errors.New("connect Hyperwave to OBS first (OBS & Deck → OBS)")
	}
	o.refreshScenes()
	scenes := o.State().Scenes
	if len(scenes) == 0 {
		return "", errors.New("OBS has no scenes yet")
	}
	raw, err := o.Request("GetInputList", nil)
	if err != nil {
		return "", err
	}
	var il struct {
		Inputs []struct {
			Name string `json:"inputName"`
		} `json:"inputs"`
	}
	json.Unmarshal(raw, &il)
	exists := false
	for _, in := range il.Inputs {
		if in.Name == soundPlayerName {
			exists = true
		}
	}
	added := 0
	if !exists {
		_, err := o.Request("CreateInput", map[string]any{"sceneName": scenes[0], "inputName": soundPlayerName, "inputKind": "browser_source",
			"inputSettings":    map[string]any{"url": url, "width": 320, "height": 120, "reroute_audio": true, "shutdown": false, "restart_when_active": false},
			"sceneItemEnabled": true})
		if err != nil {
			return "", fmt.Errorf("OBS couldn't add the sound player: %v", err)
		}
		added++
	} else {
		o.Request("SetInputSettings", map[string]any{"inputName": soundPlayerName, "inputSettings": map[string]any{"url": url, "reroute_audio": true, "shutdown": false}})
	}
	for i, sc := range scenes {
		if i == 0 && !exists {
			continue
		}
		if _, err := o.Request("GetSceneItemId", map[string]any{"sceneName": sc, "sourceName": soundPlayerName}); err == nil {
			continue
		}
		if _, err := o.Request("CreateSceneItem", map[string]any{"sceneName": sc, "sourceName": soundPlayerName, "sceneItemEnabled": true}); err == nil {
			added++
		}
	}
	// play to the stream and to your headphones
	o.Request("SetInputAudioMonitorType", map[string]any{"inputName": soundPlayerName, "monitorType": "OBS_MONITORING_TYPE_MONITOR_AND_OUTPUT"})
	if added == 0 {
		return "The sound player is already in all your scenes.", nil
	}
	return fmt.Sprintf("Added the sound player to %d scene%s.", added, map[bool]string{true: "", false: "s"}[added == 1]), nil
}

// ToggleSource shows or hides a source, in the current scene if it's there, otherwise in the
// first scene that has it.
func (o *OBS) ToggleSource(name string) (string, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return "", errors.New("which source?")
	}
	st := o.State()
	scenes := append([]string{st.Current}, st.Scenes...)
	for _, sc := range scenes {
		if sc == "" {
			continue
		}
		raw, err := o.Request("GetSceneItemId", map[string]any{"sceneName": sc, "sourceName": name})
		if err != nil {
			if e, ok := err.(*obsErr); ok && e.Code == 600 {
				continue
			}
			return "", err
		}
		var id struct {
			ID int `json:"sceneItemId"`
		}
		json.Unmarshal(raw, &id)
		raw, err = o.Request("GetSceneItemEnabled", map[string]any{"sceneName": sc, "sceneItemId": id.ID})
		if err != nil {
			return "", err
		}
		var en struct {
			On bool `json:"sceneItemEnabled"`
		}
		json.Unmarshal(raw, &en)
		if _, err := o.Request("SetSceneItemEnabled", map[string]any{"sceneName": sc, "sceneItemId": id.ID, "sceneItemEnabled": !en.On}); err != nil {
			return "", err
		}
		if en.On {
			return "Hid " + name, nil
		}
		return "Showing " + name, nil
	}
	return "", fmt.Errorf("OBS has no source called %q in your scenes", name)
}
