// ============================================================================
//  Hyperwave Station v1.0.3  ->  Streamer.bot   (one action for every platform)
//
//  Put this in ONE action ("Hyperwave - Spotify") as an Execute C# Code
//  sub-action, click Compile (if it fails, click "Add refs" and Compile
//  again), then add triggers:
//     Twitch  > Channel Reward > Reward Redemption   (your song request reward)
//     Kick    > Channel Reward > Reward Redemption   (your song request reward)
//     Core    > Commands > Command Triggered          (!sr, !song, !skip ... )
//     TikTok: fired by TikFinity (see the setup guide)
//
//  What it does is decided by the command that fired it:
//     reward redemption / !sr / !songrequest   -> song request
//     !song / !np                              -> say what's playing
//     !skip !prev !pause !play !vol !shuffle !repeat !playlist !playnow
//     !sron !sroff                             -> DJ commands (give these
//                                                 commands Moderator-only
//                                                 permission in Streamer.bot)
//
//  Optional arguments you can set with a "Set Argument" sub-action BEFORE this:
//     hwPlatform  twitch | kick | youtube | tiktok   (force where the reply goes)
//     hwMode      sr | song | cmd                    (force what it does)
//     hwCmd       skip, pause, vol ...               (force which DJ command)
//     hwInput     the song text (TikFinity: map the comment here)
//     hwUser      the viewer name (TikFinity: map the nickname here)
//     hwQuiet     true  -> don't post a chat reply
//
//  After it runs you can branch on  hwResult  (added, notFound, closed,
//  tooLong, limit, explicit, duplicate, blocked, noDevice, empty, error, ok)
//  e.g. If hwResult Equals added -> take your own points currency.
// ============================================================================
using System;
using System.IO;
using System.Net;
using System.Text;

public class CPHInline
{
    // Only change this if you changed the port in Hyperwave Station.
    private const string STATION = "http://127.0.0.1:7575";

    public bool Execute()
    {
        string platform = DetectPlatform();
        string user = FirstArg(new string[] { "hwUser", "user", "userName", "nickname", "uniqueId", "username" }, "someone");
        string input = FirstArg(new string[] { "hwInput", "rawInput", "comment", "message" }, "");
        string command = FirstArg(new string[] { "command" }, "").Trim().ToLower();
        if (command.StartsWith("!")) command = command.Substring(1);

        // TikFinity hands over the whole comment ("!sr song") — strip the command word
        string trimmed = input.Trim();
        if (trimmed.StartsWith("!"))
        {
            int sp = trimmed.IndexOf(' ');
            string first = (sp > 0 ? trimmed.Substring(1, sp - 1) : trimmed.Substring(1)).ToLower();
            if (command == "") command = first;
            input = sp > 0 ? trimmed.Substring(sp + 1) : "";
        }

        string mode = FirstArg(new string[] { "hwMode" }, "").ToLower();
        string djCmd = FirstArg(new string[] { "hwCmd" }, "").ToLower();
        if (mode == "")
        {
            if (djCmd != "") mode = "cmd";
            else if (command == "song" || command == "np" || command == "nowplaying" || command == "currentsong") mode = "song";
            else if (IsDjCommand(command)) { mode = "cmd"; djCmd = command; }
            else mode = "sr";
        }

        string url;
        if (mode == "song")
        {
            url = STATION + "/api/song";
        }
        else if (mode == "cmd")
        {
            if (djCmd == "") djCmd = command;
            url = STATION + "/api/cmd?format=text&c=" + Esc(djCmd) + "&arg=" + Esc(input.Trim()) + "&user=" + Esc(user);
        }
        else
        {
            url = STATION + "/api/sr?platform=" + Esc(platform) + "&user=" + Esc(user) + "&q=" + Esc(input.Trim());
        }

        string body;
        string result = "error";
        string reply;
        try
        {
            body = Fetch(url);
        }
        catch (Exception ex)
        {
            CPH.LogWarn("[Hyperwave] Station not reachable: " + ex.Message);
            reply = "@" + user + " the music system is offline right now.";
            CPH.SetArgument("hwResult", "offline");
            Refund(false);
            Say(platform, reply);
            return true;
        }

        if (mode == "sr")
        {
            // JSON reply: {"ok":true,"reply":"...","code":"added",...}
            result = JsonString(body, "code");
            reply = JsonString(body, "reply");
            Refund(result == "added");
        }
        else
        {
            reply = body;
            result = body.StartsWith("\u26A0", StringComparison.Ordinal) ? "error" : "ok";
        }

        CPH.SetArgument("hwResult", result);
        CPH.SetArgument("hwReply", reply);
        CPH.LogInfo("[Hyperwave] " + platform + " " + user + " " + mode + " -> " + reply);
        Say(platform, reply);
        return true;
    }

    // ---------------------------------------------------------------- helpers

    private bool IsDjCommand(string c)
    {
        string[] dj = { "skip", "next", "prev", "previous", "back", "pause", "stop", "play", "resume", "vol", "volume",
                        "shuffle", "repeat", "playlist", "pl", "album", "playnow", "pn", "sron", "sroff", "requests" };
        for (int i = 0; i < dj.Length; i++) if (dj[i] == c) return true;
        return false;
    }

    private string DetectPlatform()
    {
        string forced = FirstArg(new string[] { "hwPlatform" }, "").ToLower();
        if (forced != "") return forced;
        string[] keys = { "userType", "eventSource", "commandSource", "platform", "__source" };
        for (int i = 0; i < keys.Length; i++)
        {
            object v;
            if (args.TryGetValue(keys[i], out v) && v != null)
            {
                string s = v.ToString().ToLower();
                if (s.Contains("kick")) return "kick";
                if (s.Contains("youtube")) return "youtube";
                if (s.Contains("tiktok")) return "tiktok";
                if (s.Contains("twitch")) return "twitch";
            }
        }
        if (args.ContainsKey("nickname") || args.ContainsKey("uniqueId")) return "tiktok";
        return "twitch";
    }

    private void Say(string platform, string msg)
    {
        if (string.IsNullOrEmpty(msg)) return;
        if (FirstArg(new string[] { "hwQuiet" }, "").ToLower() == "true") return;
        try
        {
            if (platform == "kick") CPH.SendKickMessage(msg);
            else if (platform == "youtube") CPH.SendYouTubeMessageToLatestMonitored(msg);
            else if (platform == "tiktok") { /* TikTok has no bot chat; the overlay pop-up shows it instead */ }
            else CPH.SendMessage(msg);
        }
        catch (Exception ex) { CPH.LogWarn("[Hyperwave] couldn't send reply: " + ex.Message); }
    }

    // Twitch only: refund points when a request fails, mark it done when it works.
    // This only works on rewards Streamer.bot created itself (Twitch rule); otherwise it is skipped quietly.
    private void Refund(bool ok)
    {
        string rewardId = FirstArg(new string[] { "rewardId" }, "");
        string redemptionId = FirstArg(new string[] { "redemptionId" }, "");
        if (rewardId == "" || redemptionId == "") return;
        if (DetectPlatform() != "twitch") return;
        try
        {
            if (ok) CPH.TwitchRedemptionFulfill(rewardId, redemptionId);
            else CPH.TwitchRedemptionCancel(rewardId, redemptionId);
        }
        catch (Exception) { }
    }

    private string FirstArg(string[] names, string fallback)
    {
        for (int i = 0; i < names.Length; i++)
        {
            object v;
            if (args.TryGetValue(names[i], out v) && v != null)
            {
                string s = v.ToString();
                if (s.Trim() != "") return s;
            }
        }
        return fallback;
    }

    private static string Esc(string s)
    {
        return Uri.EscapeDataString(s ?? "");
    }

    private static string Fetch(string url)
    {
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
        req.Method = "GET";
        req.Timeout = 10000;
        req.ReadWriteTimeout = 10000;
        req.Proxy = null;
        using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
        using (StreamReader rd = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
        {
            return rd.ReadToEnd();
        }
    }

    // Minimal JSON string reader (no extra assemblies needed on any Streamer.bot build).
    private static string JsonString(string json, string key)
    {
        string needle = "\"" + key + "\":";
        int i = json.IndexOf(needle);
        if (i < 0) return "";
        i += needle.Length;
        while (i < json.Length && json[i] == ' ') i++;
        if (i >= json.Length || json[i] != '"') return "";
        i++;
        StringBuilder sb = new StringBuilder();
        while (i < json.Length)
        {
            char c = json[i];
            if (c == '"') break;
            if (c == '\\' && i + 1 < json.Length)
            {
                char n = json[i + 1];
                if (n == 'u' && i + 5 < json.Length)
                {
                    sb.Append((char)Convert.ToInt32(json.Substring(i + 2, 4), 16));
                    i += 6;
                    continue;
                }
                if (n == 'n') sb.Append('\n');
                else if (n == 't') sb.Append('\t');
                else sb.Append(n);
                i += 2;
                continue;
            }
            sb.Append(c);
            i++;
        }
        return sb.ToString();
    }
}
