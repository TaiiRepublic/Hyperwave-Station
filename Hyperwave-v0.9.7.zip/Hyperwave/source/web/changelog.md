# What's new in Hyperwave

## 0.9.7
- **New: My Deck**, your own stream deck that works without an Elgato. Design big buttons with a name, icon and color, and make one button do several things in order (switch scene, mute, post in chat, clip, music and more, with waits in between). Optional press-and-hold for risky buttons. Reorder and resize them. Your buttons sync across your PC, phone and tablet. Every button can also go on an Elgato Stream Deck key.
- **Phone sign-in is easier:** the dashboard shows a QR code and a Copy link button that open the deck already signed in.
- **Pick your own deck passkey**, or generate a random one.
- **What's new** on the dashboard lists every update from 0.9.7 on, and a banner tells you when you've just updated.
- **Fixed:** the deck page could lock you out within seconds on a phone. Its background checks were being counted as wrong passkeys.
- The Twitch app instructions now say `https://localhost` for the redirect URL (Twitch rejects an empty extra box).
- Clearer message when a music button is pressed before Spotify is connected.


