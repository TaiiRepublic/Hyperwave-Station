package main

import (
	"errors"
	"fmt"
	"log"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Requester struct {
	User     string `json:"user"`
	Platform string `json:"platform"`
}

type Req struct {
	ID       int       `json:"id"`
	URI      string    `json:"uri"`
	Title    string    `json:"title"`
	Artist   string    `json:"artist"`
	Art      string    `json:"art"`
	User     string    `json:"user"`
	Platform string    `json:"platform"`
	At       time.Time `json:"at"`
	Played   bool      `json:"played"`
}

type Event struct {
	ID   int    `json:"id"`
	Kind string `json:"kind"` // request | dj
	Text string `json:"text"`
	User string `json:"user"`
	Art  string `json:"art,omitempty"`
	At   int64  `json:"at"`
}

type NowState struct {
	Connected   bool       `json:"connected"`
	Playing     bool       `json:"playing"`
	Track       *TrackView `json:"track"`
	Progress    int        `json:"progress"`
	At          int64      `json:"at"` // unix ms when progress was sampled
	Device      string     `json:"device"`
	Volume      int        `json:"volume"`
	Shuffle     bool       `json:"shuffle"`
	Repeat      string     `json:"repeat"`
	Context     string     `json:"context"`
	RequestedBy *Requester `json:"requestedBy"`
	Events      []Event    `json:"events"`
	Error       string     `json:"error,omitempty"`
}

type App struct {
	st   *Store
	sp   *Spotify
	tun  *Tunnel
	chat *ChatHub
	obs  *OBS
	sb   *SB
	tw   *Twitch
	tik  *TikFinity
	lan  *DeckLAN
	feed *Feed

	mu       sync.Mutex
	now      NowState
	reqs     []*Req
	reqSeq   int
	events   []Event
	evSeq    int
	lastUser map[string]time.Time
	lastPoll time.Time
	wake     chan struct{}

	qMu    sync.Mutex
	qCache []TrackView
	qAt    time.Time
}

func NewApp(st *Store) *App {
	a := &App{st: st, sp: NewSpotify(st), lastUser: map[string]time.Time{}, wake: make(chan struct{}, 1), feed: &Feed{}, tw: NewTwitch(st)}
	a.obs = &OBS{a: a}
	a.sb = &SB{a: a}
	a.tik = &TikFinity{a: a}
	a.lan = &DeckLAN{a: a}
	return a
}

func (a *App) poke() {
	select {
	case a.wake <- struct{}{}:
	default:
	}
}

// Poller keeps the now-playing state fresh (every 2s while playing, 5s when idle).
func (a *App) Poller() {
	for {
		wait := a.pollOnce()
		select {
		case <-time.After(wait):
		case <-a.wake:
			time.Sleep(350 * time.Millisecond) // let Spotify catch up after a command
		}
	}
}

func (a *App) pollOnce() time.Duration {
	if !a.sp.Connected() {
		a.mu.Lock()
		a.now = NowState{Connected: false, Events: a.now.Events}
		a.mu.Unlock()
		return 3 * time.Second
	}
	p, err := a.sp.Player()
	a.mu.Lock()
	defer a.mu.Unlock()
	a.lastPoll = time.Now()
	ns := NowState{Connected: true, At: time.Now().UnixMilli(), Events: a.now.Events}
	if err != nil {
		ns = a.now
		ns.Error = err.Error()
		// A failed check (network hiccup, rate limit, Spotify refusing a request) doesn't
		// mean you're logged out. Only a missing or ended login does. Before this, the
		// first failed check after logging in left this at "not connected" while the
		// dashboard's login check said "connected", so the page flipped between the two.
		ns.Connected = a.sp.Connected() && !errors.Is(err, ErrNoAuth)
		a.now = ns
		return 6 * time.Second
	}
	if p != nil {
		ns.Playing = p.Playing
		ns.Track = p.Item.View()
		ns.Progress = p.Progress
		ns.Device = p.Device.Name
		if p.Device.Volume != nil {
			ns.Volume = *p.Device.Volume
		}
		ns.Shuffle = p.Shuffle
		ns.Repeat = p.Repeat
		if p.Context != nil {
			ns.Context = p.Context.URI
		}
	}
	if ns.Track != nil {
		// attribute the playing track to the oldest unplayed request for it
		for _, r := range a.reqs {
			if r.URI == ns.Track.URI && !r.Played {
				r.Played = true
				ns.RequestedBy = &Requester{r.User, r.Platform}
				break
			}
		}
		if ns.RequestedBy == nil && a.now.Track != nil && a.now.Track.URI == ns.Track.URI {
			ns.RequestedBy = a.now.RequestedBy
		}
	}
	a.now = ns
	if ns.Playing {
		return 2 * time.Second
	}
	return 5 * time.Second
}

func (a *App) State() NowState {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.now
	s.Events = append([]Event(nil), a.events...)
	return s
}

func (a *App) addEvent(kind, text, user, art string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.evSeq++
	a.events = append(a.events, Event{a.evSeq, kind, text, user, art, time.Now().UnixMilli()})
	if len(a.events) > 20 {
		a.events = a.events[len(a.events)-20:]
	}
}

func (a *App) Requests() []Req {
	a.mu.Lock()
	defer a.mu.Unlock()
	out := make([]Req, 0, len(a.reqs))
	for i := len(a.reqs) - 1; i >= 0; i-- {
		out = append(out, *a.reqs[i])
	}
	return out
}

func fill(tpl string, kv map[string]string) string {
	for k, v := range kv {
		tpl = strings.ReplaceAll(tpl, "{"+k+"}", v)
	}
	return tpl
}

func fmtMin(f float64) string {
	return strconv.FormatFloat(f, 'f', -1, 64)
}

// ---------------- song requests ----------------

type SRResult struct {
	OK    bool       `json:"ok"`
	Reply string     `json:"reply"`
	Code  string     `json:"code"`
	Track *TrackView `json:"track,omitempty"`
	Pos   int        `json:"position,omitempty"`
}

// Request runs every request rule, queues the song and returns the chat reply.
// bypass=true is for DJs/mods (skips limits but still needs a device).
func (a *App) Request(input, user, platform string, bypass bool) SRResult {
	c := a.st.Get()
	t := c.T
	if user == "" {
		user = "someone"
	}
	user = strings.TrimPrefix(user, "@")
	kv := map[string]string{"user": user, "max": "", "title": "", "artist": "", "pos": ""}
	rep := func(code, tpl string) SRResult { return SRResult{Code: code, Reply: fill(tpl, kv)} }

	input = strings.TrimSpace(input)
	if !c.RequestsOpen && !bypass {
		return rep("closed", t.Closed)
	}
	if input == "" {
		return rep("empty", t.Empty)
	}
	if !a.sp.Connected() {
		return SRResult{Code: "auth", Reply: "@" + user + " the song queue isn't connected to Spotify yet."}
	}
	if !bypass && c.UserCooldownSec > 0 {
		a.mu.Lock()
		last := a.lastUser[strings.ToLower(user)]
		a.mu.Unlock()
		if left := time.Until(last.Add(time.Duration(c.UserCooldownSec) * time.Second)); left > 0 {
			return SRResult{Code: "cooldown", Reply: fmt.Sprintf("@%s slow down — you can request again in %ds.", user, int(left.Seconds())+1)}
		}
	}

	var tr *Track
	var err error
	if kind, id := ParseLink(input); kind != "" {
		if kind != "track" {
			return SRResult{Code: "notTrack", Reply: "@" + user + " that's a Spotify " + kind + " link — song requests need a track link."}
		}
		tr, err = a.sp.GetTrack(id)
	} else {
		tr, err = a.searchOne(input)
	}
	if err != nil || tr == nil {
		if err != nil {
			log.Println("request search:", err)
		}
		return rep("notFound", t.NotFound)
	}
	kv["title"], kv["artist"] = tr.Name, tr.ArtistNames()

	if !bypass {
		low := strings.ToLower(tr.Name + " " + tr.ArtistNames() + " " + tr.ID)
		for _, w := range c.Blocklist {
			w = strings.ToLower(strings.TrimSpace(w))
			if w != "" && strings.Contains(low, w) {
				return rep("blocked", t.Blocked)
			}
		}
		if c.BlockExplicit && tr.Explicit {
			return rep("explicit", t.Explicit)
		}
		if c.MaxMinutes > 0 && float64(tr.Duration) > c.MaxMinutes*60000 {
			kv["max"] = fmtMin(c.MaxMinutes)
			return rep("tooLong", t.TooLong)
		}
		a.mu.Lock()
		pending := 0
		dup := false
		for _, r := range a.reqs {
			if strings.EqualFold(r.User, user) && !r.Played && time.Since(r.At) < 90*time.Minute {
				pending++
			}
			if r.URI == tr.URI && c.NoDupMinutes > 0 && time.Since(r.At) < time.Duration(c.NoDupMinutes)*time.Minute {
				dup = true
			}
		}
		a.mu.Unlock()
		if dup {
			return rep("duplicate", t.Duplicate)
		}
		if c.MaxPerUser > 0 && pending >= c.MaxPerUser {
			kv["max"] = strconv.Itoa(c.MaxPerUser)
			return rep("limit", t.Limit)
		}
	}

	if _, _, err := a.sp.Do("POST", "/me/player/queue", url.Values{"uri": {tr.URI}}, nil); err != nil {
		if errors.Is(err, ErrNoDevice) {
			return rep("noDevice", t.NoDevice)
		}
		var ae *APIError
		if errors.As(err, &ae) && ae.Status == 403 {
			return SRResult{Code: "forbidden", Reply: "@" + user + " Spotify refused the queue (Premium required on the streamer's account)."}
		}
		log.Println("queue add:", err)
		return SRResult{Code: "error", Reply: "@" + user + " Spotify didn't accept that one, try again in a moment."}
	}

	a.mu.Lock()
	a.reqSeq++
	pos := 1
	for _, r := range a.reqs {
		if !r.Played && time.Since(r.At) < 90*time.Minute {
			pos++
		}
	}
	a.reqs = append(a.reqs, &Req{a.reqSeq, tr.URI, tr.Name, tr.ArtistNames(), tr.Art(), user, platform, time.Now(), false})
	if len(a.reqs) > 200 {
		a.reqs = a.reqs[len(a.reqs)-200:]
	}
	a.lastUser[strings.ToLower(user)] = time.Now()
	a.mu.Unlock()
	a.qMu.Lock()
	a.qAt = time.Time{}
	a.qMu.Unlock()

	kv["pos"] = strconv.Itoa(pos)
	a.addEvent("request", tr.Name+" — "+tr.ArtistNames(), user, tr.Art())
	log.Printf("[request] %s (%s) -> %s by %s", user, platform, tr.Name, tr.ArtistNames())
	res := rep("added", t.Added)
	res.OK = true
	res.Track = tr.View()
	res.Pos = pos
	return res
}

func (a *App) searchOne(input string) (*Track, error) {
	filtered, plain := BuildQuery(input)
	try := func(q string) (*Track, error) {
		r, err := a.sp.Search(q, "track", 5)
		if err != nil || len(r.Tracks) == 0 {
			return nil, err
		}
		v := r.Tracks[0]
		return &Track{ID: v.ID, URI: v.URI, Name: v.Title, Duration: v.Duration, Explicit: v.Explicit,
			Artists: []Artist{{v.Artist}}, Album: struct {
				Name   string  `json:"name"`
				Images []Image `json:"images"`
			}{v.Album, []Image{{URL: v.Art, W: 300}}}}, nil
	}
	if filtered != "" {
		if t, err := try(filtered); t != nil || err != nil {
			return t, err
		}
	}
	return try(plain)
}

func (a *App) NowPlayingText() string {
	s := a.State()
	c := a.st.Get()
	if s.Track == nil {
		return c.T.Nothing
	}
	req := ""
	if s.RequestedBy != nil {
		req = " (requested by @" + s.RequestedBy.User + ")"
	}
	link := ""
	if s.Track.ID != "" {
		link = " https://open.spotify.com/track/" + s.Track.ID
	}
	out := fill(c.T.NowPlay, map[string]string{"title": s.Track.Title, "artist": s.Track.Artist, "req": req})
	if strings.Contains(c.T.NowPlay, "{link}") {
		return strings.ReplaceAll(out, "{link}", link)
	}
	return out
}

// ---------------- DJ / mod commands ----------------

// Command runs a DJ action and returns a chat-friendly reply.
func (a *App) Command(cmd, arg, user string) (string, error) {
	cmd = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(cmd, "!")))
	arg = strings.TrimSpace(arg)
	sp := a.sp
	defer a.poke()
	who := ""
	if user != "" {
		who = " by @" + strings.TrimPrefix(user, "@")
	}
	djEvent := func(text string) { a.addEvent("dj", text, user, "") }
	wrap := func(err error) error {
		if errors.Is(err, ErrNoDevice) {
			return errors.New("no active Spotify device — start playing something on the streaming PC first")
		}
		return err
	}
	switch cmd {
	case "skip", "next":
		if _, _, err := sp.Do("POST", "/me/player/next", nil, nil); err != nil {
			return "", wrap(err)
		}
		djEvent("Skipped" + who)
		return "⏭ Skipped" + who, nil
	case "prev", "previous", "back":
		if _, _, err := sp.Do("POST", "/me/player/previous", nil, nil); err != nil {
			return "", wrap(err)
		}
		djEvent("Went back" + who)
		return "⏮ Back one track", nil
	case "pause", "stop":
		if _, _, err := sp.Do("PUT", "/me/player/pause", nil, nil); err != nil {
			return "", wrap(err)
		}
		djEvent("Music paused" + who)
		return "⏸ Music paused" + who, nil
	case "play", "resume", "start":
		if arg != "" {
			return a.PlayNow(arg, user)
		}
		if _, _, err := sp.Do("PUT", "/me/player/play", nil, nil); err != nil {
			return "", wrap(err)
		}
		djEvent("Music resumed" + who)
		return "▶ Music resumed" + who, nil
	case "toggle":
		s := a.State()
		if s.Playing {
			return a.Command("pause", "", user)
		}
		return a.Command("play", "", user)
	case "vol", "volume":
		s := a.State()
		v := s.Volume
		switch {
		case arg == "":
			return fmt.Sprintf("🔊 Volume is %d%%", v), nil
		case arg == "up" || arg == "+":
			v += 10
		case arg == "down" || arg == "-":
			v -= 10
		case strings.HasPrefix(arg, "+") || strings.HasPrefix(arg, "-"):
			d, _ := strconv.Atoi(arg)
			v += d
		default:
			n, err := strconv.Atoi(strings.TrimSuffix(arg, "%"))
			if err != nil {
				return "", errors.New("volume must be 0-100, up or down")
			}
			v = n
		}
		if v < 0 {
			v = 0
		}
		if v > 100 {
			v = 100
		}
		if _, _, err := sp.Do("PUT", "/me/player/volume", url.Values{"volume_percent": {strconv.Itoa(v)}}, nil); err != nil {
			return "", wrap(err)
		}
		a.mu.Lock()
		a.now.Volume = v
		a.mu.Unlock()
		return fmt.Sprintf("🔊 Volume %d%%", v), nil
	case "shuffle":
		on := !a.State().Shuffle
		if arg != "" {
			on = arg == "on" || arg == "true" || arg == "1"
		}
		if _, _, err := sp.Do("PUT", "/me/player/shuffle", url.Values{"state": {strconv.FormatBool(on)}}, nil); err != nil {
			return "", wrap(err)
		}
		if on {
			return "🔀 Shuffle on", nil
		}
		return "🔀 Shuffle off", nil
	case "repeat":
		m := map[string]string{"off": "off", "track": "track", "song": "track", "one": "track", "context": "context", "all": "context", "on": "context", "playlist": "context"}
		st, ok := m[strings.ToLower(arg)]
		if !ok {
			cur := a.State().Repeat
			st = map[string]string{"off": "context", "context": "track", "track": "off"}[cur]
			if st == "" {
				st = "context"
			}
		}
		if _, _, err := sp.Do("PUT", "/me/player/repeat", url.Values{"state": {st}}, nil); err != nil {
			return "", wrap(err)
		}
		return "🔁 Repeat " + st, nil
	case "playlist", "pl", "album":
		if arg == "" {
			return "", errors.New("add a playlist link or name")
		}
		return a.PlayContext(arg, user)
	case "playnow", "pn":
		return a.PlayNow(arg, user)
	case "queue", "sr", "add":
		r := a.Request(arg, user, "dj", true)
		if !r.OK {
			return "", errors.New(r.Reply)
		}
		return r.Reply, nil
	case "requests", "sron", "sroff":
		open := !a.st.Get().RequestsOpen
		if cmd == "sron" || arg == "on" || arg == "open" {
			open = true
		}
		if cmd == "sroff" || arg == "off" || arg == "close" || arg == "closed" {
			open = false
		}
		a.st.Update(func(c *Config) { c.RequestsOpen = open })
		if open {
			djEvent("Song requests are OPEN")
			return "✅ Song requests are open!", nil
		}
		djEvent("Song requests are closed")
		return "⛔ Song requests are closed.", nil
	case "np", "song", "nowplaying":
		return a.NowPlayingText(), nil
	}
	return "", fmt.Errorf("unknown command %q", cmd)
}

// PlayContext starts a playlist/album/artist from a link, URI or by matching one of the streamer's playlist names.
func (a *App) PlayContext(arg, user string) (string, error) {
	var uri, label string
	if kind, id := ParseLink(arg); kind != "" {
		if kind == "track" || kind == "episode" {
			return a.PlayNow(arg, user)
		}
		uri, label = "spotify:"+kind+":"+id, kind
	} else {
		pls, err := a.sp.MyPlaylists()
		if err != nil {
			return "", err
		}
		want := strings.ToLower(arg)
		for _, p := range pls {
			if strings.ToLower(p.Name) == want {
				uri, label = p.URI, p.Name
				break
			}
		}
		if uri == "" {
			for _, p := range pls {
				if strings.Contains(strings.ToLower(p.Name), want) {
					uri, label = p.URI, p.Name
					break
				}
			}
		}
		if uri == "" {
			return "", fmt.Errorf("no playlist called %q in the streamer's library", arg)
		}
	}
	if _, _, err := a.sp.Do("PUT", "/me/player/play", nil, map[string]any{"context_uri": uri}); err != nil {
		if errors.Is(err, ErrNoDevice) {
			return "", errors.New("no active Spotify device on the streaming PC")
		}
		return "", err
	}
	a.poke()
	a.addEvent("dj", "Now playing "+label, user, "")
	return "💿 Now playing " + label, nil
}

func (a *App) PlayNow(arg, user string) (string, error) {
	var tr *Track
	var err error
	if kind, id := ParseLink(arg); kind == "track" {
		tr, err = a.sp.GetTrack(id)
	} else if kind != "" {
		return a.PlayContext(arg, user)
	} else if strings.HasPrefix(arg, "spotify:track:") {
		tr, err = a.sp.GetTrack(strings.TrimPrefix(arg, "spotify:track:"))
	} else {
		tr, err = a.searchOne(arg)
	}
	if err != nil || tr == nil {
		return "", errors.New("couldn't find that track")
	}
	if _, _, err := a.sp.Do("PUT", "/me/player/play", nil, map[string]any{"uris": []string{tr.URI}}); err != nil {
		if errors.Is(err, ErrNoDevice) {
			return "", errors.New("no active Spotify device on the streaming PC")
		}
		return "", err
	}
	a.poke()
	a.addEvent("dj", "Playing "+tr.Name+" — "+tr.ArtistNames(), user, tr.Art())
	return "▶ Playing " + tr.Name + " by " + tr.ArtistNames(), nil
}

func (a *App) UpNext() ([]TrackView, error) {
	a.qMu.Lock()
	defer a.qMu.Unlock()
	if time.Since(a.qAt) < 4*time.Second {
		return a.qCache, nil
	}
	_, q, err := a.sp.Queue()
	if err != nil {
		return a.qCache, err
	}
	out := []TrackView{}
	for i := range q {
		if v := q[i].View(); v != nil {
			out = append(out, *v)
		}
	}
	a.qCache, a.qAt = out, time.Now()
	return out, nil
}
