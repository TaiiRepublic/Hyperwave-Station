package main

import (
	"bytes"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	apiBase      = envOr("HWS_SPOTIFY_API", "https://api.spotify.com/v1")
	accountsBase = envOr("HWS_SPOTIFY_ACCOUNTS", "https://accounts.spotify.com")
	scopes       = "user-read-currently-playing user-read-playback-state user-modify-playback-state playlist-read-private playlist-read-collaborative"
)

func envOr(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

var ErrNoAuth = errors.New("spotify not connected")
var ErrNoDevice = errors.New("no active spotify device")

type APIError struct {
	Status int
	Msg    string
}

func (e *APIError) Error() string { return fmt.Sprintf("spotify %d: %s", e.Status, e.Msg) }

type Spotify struct {
	store    *Store
	mu       sync.Mutex
	access   string
	exp      time.Time
	verifier string
	state    string
	backoff  time.Time
	http     *http.Client
	LastErr  string
}

func NewSpotify(st *Store) *Spotify {
	return &Spotify{store: st, http: &http.Client{Timeout: 12 * time.Second}}
}

func b64(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }

func (s *Spotify) RedirectURI() string {
	return fmt.Sprintf("http://127.0.0.1:%d/callback", s.store.Get().Port)
}

func (s *Spotify) LoginURL() string {
	v := make([]byte, 48)
	rand.Read(v)
	st := make([]byte, 12)
	rand.Read(st)
	s.mu.Lock()
	s.verifier = b64(v)
	s.state = b64(st)
	sum := sha256.Sum256([]byte(s.verifier))
	state := s.state
	s.mu.Unlock()
	q := url.Values{}
	q.Set("client_id", s.store.Get().ClientID)
	q.Set("response_type", "code")
	q.Set("redirect_uri", s.RedirectURI())
	q.Set("scope", scopes)
	q.Set("state", state)
	q.Set("code_challenge_method", "S256")
	q.Set("code_challenge", b64(sum[:]))
	return accountsBase + "/authorize?" + q.Encode()
}

type tokenResp struct {
	Access  string `json:"access_token"`
	Refresh string `json:"refresh_token"`
	Expires int    `json:"expires_in"`
	Err     string `json:"error"`
	ErrDesc string `json:"error_description"`
}

func (s *Spotify) tokenCall(form url.Values) (*tokenResp, error) {
	req, _ := http.NewRequest("POST", accountsBase+"/api/token", strings.NewReader(form.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	res, err := s.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	var t tokenResp
	b, _ := io.ReadAll(res.Body)
	json.Unmarshal(b, &t)
	if res.StatusCode != 200 || t.Access == "" {
		if t.ErrDesc == "" {
			t.ErrDesc = strings.TrimSpace(string(b))
		}
		return nil, fmt.Errorf("token error %d: %s %s", res.StatusCode, t.Err, t.ErrDesc)
	}
	return &t, nil
}

func (s *Spotify) Exchange(code, state string) error {
	s.mu.Lock()
	ver, want := s.verifier, s.state
	s.mu.Unlock()
	if want == "" || state != want {
		return errors.New("login expired or state mismatch — click Connect Spotify again")
	}
	f := url.Values{}
	f.Set("grant_type", "authorization_code")
	f.Set("code", code)
	f.Set("redirect_uri", s.RedirectURI())
	f.Set("client_id", s.store.Get().ClientID)
	f.Set("code_verifier", ver)
	t, err := s.tokenCall(f)
	if err != nil {
		return err
	}
	s.mu.Lock()
	s.access = t.Access
	s.exp = time.Now().Add(time.Duration(t.Expires-60) * time.Second)
	s.mu.Unlock()
	s.store.Update(func(c *Config) { c.RefreshToken = t.Refresh })
	return nil
}

func (s *Spotify) Connected() bool { return s.store.Get().RefreshToken != "" }

func (s *Spotify) Disconnect() {
	s.mu.Lock()
	s.access = ""
	s.mu.Unlock()
	s.store.Update(func(c *Config) { c.RefreshToken = "" })
}

func (s *Spotify) token() (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.access != "" && time.Now().Before(s.exp) {
		return s.access, nil
	}
	c := s.store.Get()
	if c.RefreshToken == "" || c.ClientID == "" {
		return "", ErrNoAuth
	}
	f := url.Values{}
	f.Set("grant_type", "refresh_token")
	f.Set("refresh_token", c.RefreshToken)
	f.Set("client_id", c.ClientID)
	t, err := s.tokenCall(f)
	if err != nil {
		s.LastErr = err.Error()
		if strings.Contains(err.Error(), "invalid_grant") {
			s.LastErr = "Spotify ended this login (" + err.Error() + "). Click Connect Spotify to log in again."
			s.store.Update(func(c *Config) { c.RefreshToken = "" })
		}
		return "", err
	}
	s.access = t.Access
	s.exp = time.Now().Add(time.Duration(t.Expires-60) * time.Second)
	if t.Refresh != "" && t.Refresh != c.RefreshToken {
		// Save the renewed token right away (not in the background): the old one stops
		// working as soon as Spotify issues this one.
		s.store.Update(func(c *Config) { c.RefreshToken = t.Refresh })
	}
	s.LastErr = ""
	return s.access, nil
}

// Do calls the Web API. A 204 returns (204, nil, nil).
func (s *Spotify) Do(method, path string, q url.Values, body any) (int, []byte, error) {
	if time.Now().Before(s.backoff) {
		return 0, nil, &APIError{429, "rate limited, waiting"}
	}
	for attempt := 0; attempt < 2; attempt++ {
		tok, err := s.token()
		if err != nil {
			return 0, nil, err
		}
		u := apiBase + path
		if len(q) > 0 {
			u += "?" + q.Encode()
		}
		var rdr io.Reader
		if body != nil {
			bb, _ := json.Marshal(body)
			rdr = bytes.NewReader(bb)
		}
		req, _ := http.NewRequest(method, u, rdr)
		req.Header.Set("Authorization", "Bearer "+tok)
		if body != nil {
			req.Header.Set("Content-Type", "application/json")
		} else if method != "GET" {
			req.ContentLength = 0
		}
		res, err := s.http.Do(req)
		if err != nil {
			return 0, nil, err
		}
		b, _ := io.ReadAll(res.Body)
		res.Body.Close()
		switch {
		case res.StatusCode == 401 && attempt == 0:
			s.mu.Lock()
			s.access = ""
			s.mu.Unlock()
			continue
		case res.StatusCode == 429:
			sec, _ := strconv.Atoi(res.Header.Get("Retry-After"))
			if sec <= 0 {
				sec = 5
			}
			s.backoff = time.Now().Add(time.Duration(sec) * time.Second)
			return 429, b, &APIError{429, "rate limited"}
		case res.StatusCode >= 400:
			var e struct {
				Error struct {
					Message string `json:"message"`
					Reason  string `json:"reason"`
				} `json:"error"`
			}
			json.Unmarshal(b, &e)
			msg := e.Error.Message
			if e.Error.Reason == "NO_ACTIVE_DEVICE" || (res.StatusCode == 404 && strings.Contains(strings.ToLower(msg), "device")) {
				return res.StatusCode, b, ErrNoDevice
			}
			if msg == "" {
				msg = http.StatusText(res.StatusCode)
			}
			return res.StatusCode, b, &APIError{res.StatusCode, msg}
		}
		return res.StatusCode, b, nil
	}
	return 0, nil, ErrNoAuth
}

// ---------- types ----------

type Image struct {
	URL string `json:"url"`
	W   int    `json:"width"`
}
type Artist struct {
	Name string `json:"name"`
}
type Track struct {
	ID       string   `json:"id"`
	URI      string   `json:"uri"`
	Name     string   `json:"name"`
	Duration int      `json:"duration_ms"`
	Explicit bool     `json:"explicit"`
	Type     string   `json:"type"`
	Artists  []Artist `json:"artists"`
	Album    struct {
		Name   string  `json:"name"`
		Images []Image `json:"images"`
	} `json:"album"`
	Images []Image `json:"images"` // episodes
	Show   struct {
		Name string `json:"name"`
	} `json:"show"`
}

func (t *Track) ArtistNames() string {
	if t.Type == "episode" {
		return t.Show.Name
	}
	n := make([]string, 0, len(t.Artists))
	for _, a := range t.Artists {
		n = append(n, a.Name)
	}
	return strings.Join(n, ", ")
}

func pickImage(imgs []Image, want int) string {
	best := ""
	bestDiff := 1 << 30
	for _, im := range imgs {
		d := im.W - want
		if d < 0 {
			d = -d * 2
		}
		if im.W == 0 {
			d = 500
		}
		if d < bestDiff {
			best, bestDiff = im.URL, d
		}
	}
	return best
}

func (t *Track) Art() string {
	if len(t.Album.Images) > 0 {
		return pickImage(t.Album.Images, 300)
	}
	return pickImage(t.Images, 300)
}

type TrackView struct {
	ID       string `json:"id"`
	URI      string `json:"uri"`
	Title    string `json:"title"`
	Artist   string `json:"artist"`
	Album    string `json:"album"`
	Art      string `json:"art"`
	Duration int    `json:"duration"`
	Explicit bool   `json:"explicit"`
}

func (t *Track) View() *TrackView {
	if t == nil || t.URI == "" {
		return nil
	}
	return &TrackView{t.ID, t.URI, t.Name, t.ArtistNames(), t.Album.Name, t.Art(), t.Duration, t.Explicit}
}

type Player struct {
	Device struct {
		ID     string `json:"id"`
		Name   string `json:"name"`
		Type   string `json:"type"`
		Volume *int   `json:"volume_percent"`
	} `json:"device"`
	Shuffle  bool   `json:"shuffle_state"`
	Repeat   string `json:"repeat_state"`
	Progress int    `json:"progress_ms"`
	Playing  bool   `json:"is_playing"`
	Item     *Track `json:"item"`
	Context  *struct {
		URI string `json:"uri"`
	} `json:"context"`
}

func (s *Spotify) Player() (*Player, error) {
	code, b, err := s.Do("GET", "/me/player", url.Values{"additional_types": {"track,episode"}}, nil)
	if err != nil {
		return nil, err
	}
	if code == 204 || len(b) == 0 {
		return nil, nil
	}
	var p Player
	if err := json.Unmarshal(b, &p); err != nil {
		return nil, err
	}
	return &p, nil
}

func (s *Spotify) Queue() (*Track, []Track, error) {
	_, b, err := s.Do("GET", "/me/player/queue", nil, nil)
	if err != nil {
		return nil, nil, err
	}
	var q struct {
		Cur   *Track  `json:"currently_playing"`
		Queue []Track `json:"queue"`
	}
	json.Unmarshal(b, &q)
	return q.Cur, q.Queue, nil
}

func (s *Spotify) GetTrack(id string) (*Track, error) {
	_, b, err := s.Do("GET", "/tracks/"+url.PathEscape(id), nil, nil)
	if err != nil {
		return nil, err
	}
	var t Track
	json.Unmarshal(b, &t)
	if t.URI == "" {
		return nil, errors.New("track not found")
	}
	return &t, nil
}

type SearchResult struct {
	Tracks    []TrackView `json:"tracks"`
	Playlists []ListView  `json:"playlists"`
	Albums    []ListView  `json:"albums"`
}

type ListView struct {
	URI   string `json:"uri"`
	Name  string `json:"name"`
	Sub   string `json:"sub"`
	Art   string `json:"art"`
	Count int    `json:"count"`
}

// Search. Development-mode apps cap limit at 10.
func (s *Spotify) Search(q, types string, limit int) (*SearchResult, error) {
	if limit <= 0 || limit > 10 {
		limit = 10
	}
	_, b, err := s.Do("GET", "/search", url.Values{"q": {q}, "type": {types}, "limit": {strconv.Itoa(limit)}}, nil)
	if err != nil {
		return nil, err
	}
	var r struct {
		Tracks struct {
			Items []*Track `json:"items"`
		} `json:"tracks"`
		Playlists struct {
			Items []*rawList `json:"items"`
		} `json:"playlists"`
		Albums struct {
			Items []*rawList `json:"items"`
		} `json:"albums"`
	}
	json.Unmarshal(b, &r)
	out := &SearchResult{Tracks: []TrackView{}, Playlists: []ListView{}, Albums: []ListView{}}
	for _, t := range r.Tracks.Items {
		if v := t.View(); v != nil {
			out.Tracks = append(out.Tracks, *v)
		}
	}
	for _, p := range r.Playlists.Items {
		if p != nil && p.URI != "" {
			out.Playlists = append(out.Playlists, p.View())
		}
	}
	for _, p := range r.Albums.Items {
		if p != nil && p.URI != "" {
			out.Albums = append(out.Albums, p.View())
		}
	}
	return out, nil
}

// rawList covers playlists (pre- and post-Feb-2026 field names) and albums.
type rawList struct {
	URI     string   `json:"uri"`
	Name    string   `json:"name"`
	Images  []Image  `json:"images"`
	Artists []Artist `json:"artists"`
	Owner   struct {
		Name string `json:"display_name"`
	} `json:"owner"`
	Tracks *struct {
		Total int `json:"total"`
	} `json:"tracks"`
	Items *struct {
		Total int `json:"total"`
	} `json:"items"`
	TotalTracks int `json:"total_tracks"`
}

func (p *rawList) View() ListView {
	v := ListView{URI: p.URI, Name: p.Name, Art: pickImage(p.Images, 160), Count: p.TotalTracks}
	if p.Items != nil {
		v.Count = p.Items.Total
	} else if p.Tracks != nil {
		v.Count = p.Tracks.Total
	}
	if len(p.Artists) > 0 {
		v.Sub = p.Artists[0].Name
	} else {
		v.Sub = p.Owner.Name
	}
	return v
}

func (s *Spotify) MyPlaylists() ([]ListView, error) {
	out := []ListView{}
	for off := 0; off < 200; off += 50 {
		_, b, err := s.Do("GET", "/me/playlists", url.Values{"limit": {"50"}, "offset": {strconv.Itoa(off)}}, nil)
		if err != nil {
			return out, err
		}
		var r struct {
			Items []*rawList `json:"items"`
			Next  *string    `json:"next"`
		}
		json.Unmarshal(b, &r)
		for _, p := range r.Items {
			if p != nil && p.URI != "" {
				out = append(out, p.View())
			}
		}
		if r.Next == nil || len(r.Items) < 50 {
			break
		}
	}
	return out, nil
}

type Device struct {
	ID     string `json:"id"`
	Name   string `json:"name"`
	Type   string `json:"type"`
	Active bool   `json:"is_active"`
}

func (s *Spotify) Devices() ([]Device, error) {
	_, b, err := s.Do("GET", "/me/player/devices", nil, nil)
	if err != nil {
		return nil, err
	}
	var r struct {
		Devices []Device `json:"devices"`
	}
	json.Unmarshal(b, &r)
	return r.Devices, nil
}

// ---------- link parsing ----------

var linkRe = regexp.MustCompile(`(?i)(?:open\.spotify\.com/(?:intl-[a-z-]+/)?|spotify:)(track|playlist|album|artist|episode)[/:]([A-Za-z0-9]{10,40})`)

// ParseLink returns ("track", id) etc, or "" if the text isn't a Spotify link/URI.
func ParseLink(s string) (kind, id string) {
	m := linkRe.FindStringSubmatch(s)
	if m == nil {
		return "", ""
	}
	return strings.ToLower(m[1]), m[2]
}

// BuildQuery turns "song - artist" / "song by artist" into Spotify field filters.
func BuildQuery(in string) (filtered, plain string) {
	plain = strings.TrimSpace(in)
	clean := strings.NewReplacer(`"`, "").Replace(plain)
	low := strings.ToLower(clean)
	for _, sep := range []string{" - ", " – ", " — ", " by "} {
		if i := strings.LastIndex(low, sep); i > 0 {
			t := strings.TrimSpace(clean[:i])
			a := strings.TrimSpace(clean[i+len(sep):])
			if t != "" && a != "" {
				return fmt.Sprintf(`track:"%s" artist:"%s"`, t, a), plain
			}
		}
	}
	return "", plain
}
