package main

import (
	"context"
	"crypto/subtle"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	qrcode "github.com/skip2/go-qrcode"
)

// ---------------- what the deck can do ----------------

// twitchVia says how Twitch replies and clips are sent: "station", "streamerbot" or "".
func (a *App) twitchVia() string {
	c := a.st.Get()
	switch c.ReplyVia {
	case "station":
		return "station"
	case "streamerbot":
		return "streamerbot"
	}
	if a.tw.Connected() {
		return "station"
	}
	if c.SBEnabled {
		return "streamerbot"
	}
	return ""
}

// Say posts a chat message. platform is twitch, kick, youtube or all.
func (a *App) Say(platform, msg string) (string, error) {
	msg = strings.TrimSpace(msg)
	if msg == "" {
		return "", errors.New("type a message first")
	}
	if len([]rune(msg)) > 480 {
		return "", errors.New("that message is too long (480 characters max)")
	}
	c := a.st.Get()
	targets := []string{platform}
	if platform == "" || platform == "all" {
		targets = nil
		if c.DeckTwitch || c.ListenTwitch {
			targets = append(targets, "twitch")
		}
		if (c.DeckKick || c.ListenKick) && c.SBEnabled {
			targets = append(targets, "kick")
		}
		if c.DeckYouTube && c.SBEnabled {
			targets = append(targets, "youtube")
		}
		if len(targets) == 0 {
			targets = []string{"twitch"}
		}
	}
	var sent, failed []string
	for _, p := range targets {
		var err error
		switch p {
		case "twitch":
			switch a.twitchVia() {
			case "station":
				err = a.tw.SendChat(msg)
			case "streamerbot":
				err = a.sb.SendMessage("twitch", msg)
			default:
				err = errors.New("sign in to Twitch or turn on Streamer.bot under OBS & Deck first")
			}
		case "kick", "youtube":
			err = a.sb.SendMessage(p, msg)
		case "tiktok":
			err = errors.New("TikTok doesn't allow apps to post in chat")
		default:
			err = errors.New("unknown platform " + p)
		}
		if err != nil {
			failed = append(failed, strings.Title(p)+": "+err.Error())
			continue
		}
		sent = append(sent, p)
		name := c.TwitchLogin
		if name == "" {
			name = "You"
		}
		a.feed.Add(FeedMsg{Platform: p, User: name, Parts: []FeedPart{{Text: msg}}, Self: true, Owner: true}, "")
	}
	if len(sent) == 0 {
		return "", errors.New(strings.Join(failed, " · "))
	}
	out := "Sent to " + strings.Join(sent, ", ")
	if len(failed) > 0 {
		out += " (not sent to " + strings.Join(failed, " · ") + ")"
	}
	return out, nil
}

// TwitchClip makes a Twitch clip through the Station sign-in or a Streamer.bot action.
func (a *App) TwitchClip() (string, error) {
	switch a.twitchVia() {
	case "station":
		link, err := a.tw.CreateClip()
		if err != nil {
			return "", err
		}
		a.feed.Add(FeedMsg{Platform: "twitch", User: "Hyperwave", Parts: []FeedPart{{Text: "🎬 Twitch clip made: " + link}}, Self: true}, "")
		return "Twitch clip made: " + link, nil
	case "streamerbot":
		name := a.st.Get().SBClipAction
		if strings.TrimSpace(name) == "" {
			name = "Hyperwave - Twitch Clip"
		}
		if err := a.sb.RunAction(name, map[string]any{"source": "Hyperwave Deck"}); err != nil {
			return "", err
		}
		return "Asked Streamer.bot to make a Twitch clip", nil
	}
	return "", errors.New("to make Twitch clips, sign in to Twitch or turn on Streamer.bot under OBS & Deck")
}

// Clip does whatever the Clip button is set to: save the OBS replay, make a Twitch clip, or both.
func (a *App) Clip() (string, error) {
	c := a.st.Get()
	var ok, bad []string
	if c.ClipReplay || !c.ClipTwitch {
		if m, err := a.obs.SaveReplay(); err != nil {
			bad = append(bad, "Replay: "+err.Error())
		} else {
			ok = append(ok, m)
		}
	}
	if c.ClipTwitch {
		if m, err := a.TwitchClip(); err != nil {
			bad = append(bad, "Twitch: "+err.Error())
		} else {
			ok = append(ok, m)
		}
	}
	if len(ok) == 0 {
		return "", errors.New(strings.Join(bad, " · "))
	}
	out := strings.Join(ok, " · ")
	if len(bad) > 0 {
		out += " (" + strings.Join(bad, " · ") + ")"
	}
	return out, nil
}

// DeckDo runs one deck action. Used by the deck page and by Stream Deck buttons.
func (a *App) DeckDo(action, value, platform string) (string, error) {
	switch strings.ToLower(strings.TrimSpace(action)) {
	case "scene":
		if err := a.obs.SetScene(value); err != nil {
			return "", err
		}
		return "Scene: " + value, nil
	case "clip":
		return a.Clip()
	case "replay":
		return a.obs.SaveReplay()
	case "twitchclip":
		return a.TwitchClip()
	case "record":
		return a.obs.ToggleRecord()
	case "stream-start":
		return a.obs.SetStream(true)
	case "stream-stop":
		return a.obs.SetStream(false)
	case "mute":
		return a.obs.ToggleMute(value)
	case "music-toggle", "music-skip", "music-prev", "requests":
		msg, err := a.deckMusic(action)
		if errors.Is(err, ErrNoAuth) {
			return "", errors.New("Spotify isn't connected. Connect it on the dashboard under Connect Spotify")
		}
		return msg, err
	case "say":
		return a.Say(platform, value)
	case "press":
		return a.PadPress(value)
	}
	return "", fmt.Errorf("unknown action %q", action)
}

func (a *App) deckMusic(action string) (string, error) {
	switch action {
	case "music-toggle":
		cmd := "play"
		if a.State().Playing {
			cmd = "pause"
		}
		return a.Command(cmd, "", "")
	case "music-skip":
		return a.Command("skip", "", "")
	case "music-prev":
		return a.Command("prev", "", "")
	case "requests":
		cmd := "sron"
		if a.st.Get().RequestsOpen {
			cmd = "sroff"
		}
		return a.Command(cmd, "", "")
	}
	return "", fmt.Errorf("unknown action %q", action)
}

func (a *App) deckState() map[string]any {
	c := a.st.Get()
	now := a.State()
	out := map[string]any{
		"obs":          a.obs.State(),
		"music":        map[string]any{"connected": now.Connected, "playing": now.Playing, "track": now.Track, "requestedBy": now.RequestedBy},
		"requestsOpen": c.RequestsOpen,
		"twitch":       map[string]any{"via": a.twitchVia(), "login": c.TwitchLogin},
		"sb":           map[string]any{"enabled": c.SBEnabled, "status": a.sb.Status()},
		"tiktok":       a.tik.Status(),
		"chat":         a.chat.Status(),
		"quick":        c.QuickMsgs,
		"clip":         map[string]any{"replay": c.ClipReplay || !c.ClipTwitch, "twitch": c.ClipTwitch},
		"platforms":    a.replyPlatforms(c),
		"version":      Version,
		"port":         c.Port,
	}
	return out
}

func (a *App) replyPlatforms(c Config) []string {
	var p []string
	if a.twitchVia() != "" {
		p = append(p, "twitch")
	}
	if c.SBEnabled {
		p = append(p, "kick", "youtube")
	}
	return p
}

// ---------------- HTTP ----------------

// deckRoutes are shared by the local server and the Wi-Fi deck server.
func (a *App) deckRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	a.padRoutes(m, wrap)
	m.HandleFunc("/api/deck/state", wrap(func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, 200, a.deckState())
	}))
	m.HandleFunc("/api/deck/chat", wrap(func(w http.ResponseWriter, r *http.Request) {
		after, _ := strconv.Atoi(r.FormValue("after"))
		jsonOut(w, 200, map[string]any{"msgs": a.feed.After(after), "last": a.feed.Last()})
	}))
	m.HandleFunc("/api/deck/do", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		msg, err := a.DeckDo(r.FormValue("a"), r.FormValue("v"), r.FormValue("p"))
		if err != nil {
			jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "message": msg})
	}))
}

// streamDeckRun handles GET /api/deck/run?a=…&v=…&k=… for Elgato Stream Deck's
// Website action with "GET request in background" ticked.
func (a *App) streamDeckRun(w http.ResponseWriter, r *http.Request) {
	want := a.st.Get().DeckKey
	k := r.FormValue("k")
	if k == "" || subtle.ConstantTimeCompare([]byte(k), []byte(want)) != 1 {
		textOut(w, "Wrong or missing deck key. Copy the button link again from the dashboard (OBS & Deck → Stream Deck).")
		return
	}
	msg, err := a.DeckDo(r.FormValue("a"), r.FormValue("v"), r.FormValue("p"))
	if err != nil {
		log.Println("[stream deck] " + err.Error())
		textOut(w, "Error: "+err.Error())
		return
	}
	textOut(w, msg)
}

// deckQR draws a QR code for the phone link (with the passkey), so a phone camera can open the deck.
func (a *App) deckQR(w http.ResponseWriter, r *http.Request) {
	c := a.st.Get()
	ips := lanIPs()
	i, _ := strconv.Atoi(r.FormValue("i"))
	if !c.DeckLAN || i < 0 || i >= len(ips) {
		http.NotFound(w, r)
		return
	}
	link := fmt.Sprintf("http://%s:%d/#key=%s", ips[i], c.DeckPort, url.QueryEscape(c.DeckKey))
	png, err := qrcode.Encode(link, qrcode.Medium, 320)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	w.Header().Set("Content-Type", "image/png")
	w.Header().Set("Cache-Control", "no-store")
	w.Write(png)
}

// ---------------- Wi-Fi deck server (optional) ----------------

type DeckLAN struct {
	a   *App
	mu  sync.Mutex
	srv *http.Server
	err string
}

func (d *DeckLAN) Status() map[string]any {
	d.mu.Lock()
	defer d.mu.Unlock()
	c := d.a.st.Get()
	out := map[string]any{"on": d.srv != nil, "error": d.err}
	if d.srv != nil {
		var urls, keyed []string
		for _, ip := range lanIPs() {
			u := fmt.Sprintf("http://%s:%d/", ip, c.DeckPort)
			urls = append(urls, u)
			keyed = append(keyed, u+"#key="+url.QueryEscape(c.DeckKey))
		}
		out["urls"] = urls
		out["urlsWithKey"] = keyed
	}
	return out
}

func (d *DeckLAN) Restart() {
	d.mu.Lock()
	old := d.srv
	d.srv, d.err = nil, ""
	d.mu.Unlock()
	if old != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		old.Shutdown(ctx)
		cancel()
	}
	c := d.a.st.Get()
	if !c.DeckLAN {
		return
	}
	ln, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", c.DeckPort))
	if err != nil {
		d.mu.Lock()
		d.err = fmt.Sprintf("port %d is busy: %v", c.DeckPort, err)
		d.mu.Unlock()
		return
	}
	srv := &http.Server{Handler: d.a.LANMux(), ReadHeaderTimeout: 10 * time.Second}
	d.mu.Lock()
	d.srv = srv
	d.mu.Unlock()
	log.Printf("[deck] phones and tablets on your Wi-Fi can open the deck on port %d", c.DeckPort)
	go srv.Serve(ln)
}

func lanIPs() []string {
	if v := os.Getenv("HWS_LAN_IP"); v != "" { // for testing only
		return strings.Split(v, ",")
	}
	var out []string
	ifs, _ := net.Interfaces()
	for _, in := range ifs {
		if in.Flags&net.FlagUp == 0 || in.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := in.Addrs()
		for _, ad := range addrs {
			ipn, ok := ad.(*net.IPNet)
			if !ok || ipn.IP.To4() == nil || !ipn.IP.IsPrivate() {
				continue
			}
			out = append(out, ipn.IP.String())
		}
	}
	// home routers usually hand out 192.168.x.x; list those first
	sort.SliceStable(out, func(i, j int) bool {
		return strings.HasPrefix(out[i], "192.168.") && !strings.HasPrefix(out[j], "192.168.")
	})
	return out
}

// LANMux serves only the deck, and every API call needs the deck passkey.
func (a *App) LANMux() http.Handler {
	lim := &limiter{fail: map[string][]time.Time{}}
	var badMu sync.Mutex
	lastBad := map[string]string{} // the last wrong passkey each device tried
	m := http.NewServeMux()
	sec := func(w http.ResponseWriter) {
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Content-Type-Options", "nosniff")
	}
	m.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		sec(w)
		if r.URL.Path == "/" || r.URL.Path == "/deck" {
			serveWeb(w, r, "deck.html")
			return
		}
		http.NotFound(w, r)
	})
	auth := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			sec(w)
			ip := clientIP(r)
			if lim.blocked(ip) {
				jsonOut(w, 429, map[string]string{"error": "Too many wrong passkeys. Wait 10 minutes and try again."})
				return
			}
			// Same-network only: refuse anything that came through a proxy or tunnel.
			if pip := net.ParseIP(ip); pip == nil || !(pip.IsPrivate() || pip.IsLoopback()) || r.Header.Get("X-Forwarded-For") != "" {
				jsonOut(w, 403, map[string]string{"error": "The deck only works from your own network."})
				return
			}
			key := r.Header.Get("X-Deck-Key")
			want := a.st.Get().DeckKey
			if key == "" {
				// Opening the page before typing a passkey isn't a wrong guess.
				jsonOut(w, 401, map[string]string{"error": "passkey needed"})
				return
			}
			if subtle.ConstantTimeCompare([]byte(key), []byte(want)) != 1 {
				// Only count each different wrong passkey once, so the page re-sending the
				// same one in the background can't lock you out.
				badMu.Lock()
				if lastBad[ip] != key {
					lastBad[ip] = key
					lim.add(ip)
				}
				badMu.Unlock()
				jsonOut(w, 401, map[string]string{"error": "wrong passkey"})
				return
			}
			badMu.Lock()
			if _, had := lastBad[ip]; had {
				delete(lastBad, ip)
				lim.clear(ip)
			}
			badMu.Unlock()
			h(w, r)
		}
	}
	a.deckRoutes(m, auth)
	return m
}
