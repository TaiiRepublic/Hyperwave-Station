# Hyperwave — changelog

## 0.9.7
- **New: My Deck**, your own stream deck that works without an Elgato. Design big buttons with a name, icon and color, and make one button do several things in order (switch scene, mute, post in chat, clip, music and more, with waits in between). Optional press-and-hold for risky buttons. Reorder and resize them. Your buttons sync across your PC, phone and tablet. Every button can also go on an Elgato Stream Deck key.
- **Phone sign-in is easier:** the dashboard shows a QR code and a Copy link button that open the deck already signed in.
- **Pick your own deck passkey**, or generate a random one.
- **What's new** on the dashboard lists every update from 0.9.7 on, and a banner tells you when you've just updated.
- **Fixed:** the deck page could lock you out within seconds on a phone. Its background checks were being counted as wrong passkeys.
- The Twitch app instructions now say `https://localhost` for the redirect URL (Twitch rejects an empty extra box).
- Clearer message when a music button is pressed before Spotify is connected.


## 0.9.6
- **New: Hyperwave Deck**, a control panel for your stream at `http://127.0.0.1:7575/deck`. It works on your PC, a second monitor, or a phone or tablet on your Wi-Fi.
  - **OBS:** switch scenes, start and stop recording, go live and end the stream (press and hold), and mute or unmute your audio sources. The scene list follows OBS automatically.
  - **Clips:** one Clip button saves OBS's replay buffer to your PC and can also make a Twitch clip. Station can keep the replay buffer running for you.
  - **Chat:** Twitch, Kick, YouTube and TikTok chat in one feed, with emotes and name colors. Reply to one platform or all of them, with quick-reply buttons.
  - **Music:** play/pause, skip, back, and open or close song requests, with the current song and album art.
- **Two ways to reply and clip on Twitch:** sign in to Twitch inside Station (no Streamer.bot needed), or send through Streamer.bot (also covers Kick and YouTube). Automatic picks whichever is set up.
- **Phones and tablets on your Wi-Fi** can open the deck with a passkey. It refuses connections from outside your home network, and locks out repeated wrong guesses.
- **Elgato Stream Deck support:** build a link for any deck button on the dashboard and paste it into Stream Deck's Website action with "GET request in background".
- New **OBS & Deck** section on the dashboard with step-by-step setup, and a Deck link in the console.


## 0.9.5
- **One download for the whole package.** Hyperwave Chat is now built into HyperwaveStation.exe at `http://127.0.0.1:7575/chat`, with its own **Hyperwave Chat** section on the dashboard. No more copying `chat.html` into the `web` folder.
- **Music in your chat.** Hyperwave Chat can show each new song ("Now playing" with album art and who requested it), every song request, and optionally DJ actions. Turn it on under Connect → Hyperwave Station. It's on automatically when the chat is opened from the app.
- The chat designer fills in your Twitch and Kick channel names from the dashboard the first time you open it, and links back to the dashboard.
- **Easier chat settings:** tabs (Connect, Style, Motion, Position, Filters), a settings search, a Show all options switch, one-click style cards, undo and redo, per-setting reset, a connection check that confirms real chat is arriving, and a warning when your OBS link is out of date.
- **Chat placement and motion:** drag and resize the chat anywhere on a full-screen canvas at 720p to 4K, ultrawide or vertical; 20 entrance and 8 exit animations; Matrix rain, float up, scrolling and pop-up modes; bubbles, palettes and profile pictures.
- Dashboard: "Standalone chat" is renamed **Commands without a bot** so it isn't confused with Hyperwave Chat.
- Version numbers for the app and chat are now shared (0.9.5).
- **New Hyperwave app icon** (the TaiiRepublic glow ring with a hyperwave breaking through it) on the .exe, taskbar and every page: dashboard, chat designer, DJ deck and overlay designer, including browser tabs.
- **TaiiRepublic is now named in the app itself:** right-click HyperwaveStation.exe → Properties → Details shows Company TaiiRepublic, product Hyperwave, version 0.9.5 and the copyright.
- **Official TaiiRepublic logo:** the animated spinning logo in the dashboard's About section (it holds still for people who turn off animations in Windows), plus a Made by TaiiRepublic credit in the dashboard sidebar and the chat designer.
- **New console welcome screen:** the TAii logo drawn in text, a note from Taii with Twitch, Kick and tip links (taken from the dashboard's About settings), a random message from the bridge each launch, and the Hyperwave Chat link alongside the others.
- **Fixed: the Spotify status flipping between "Connected" and "Connect Spotify".** If the app's check with Spotify failed even once (a network hiccup, a rate limit, or Spotify refusing a request), the dashboard kept switching between the two every few seconds. It now stays on Connected and the top bar explains what Spotify is saying, with a fix for the common cases.
- When logged in, the button now says **Log in again** instead of "Reconnect Spotify", which read like a status.
- Renewed Spotify logins are saved immediately, and saving dashboard settings can no longer put back an outdated login.
- If the app can't write its settings file, the dashboard now says so (otherwise you'd have to log in again after every restart).

## 0.9.1
- The overlay designer preview opens at **Actual size** again, showing the overlay as big as it appears on stream. Switch to **Whole screen** (top of the preview) to see where it sits on your stream. Dragging works in both, and your choice is remembered.

## 0.9.0
- **Drag to place**: the overlay designer now shows your whole stream screen. Drag the overlay anywhere, with snapping to edges and centre, step buttons for fine adjustment (1–50 px), arrow-key nudging, exact X/Y, and quick snap spots. Works at 720p, 1080p, 1440p, 4K and vertical canvases, and scales correctly to the OBS source size.
- Cards placed in the bottom half stay pinned by their bottom edge, so they grow upward when a "requested by" line appears.
- **Visualizer**: show a visualizer instead of (or over) the album art. Styles: Bars, Mirror, Wave, Radial, LED meter, Orb. Colour, bar count and speed options.
- **New layout: Player**, a desktop media-player window with a title bar, display screen and buttons.
- **6 new starting looks**: Retro desktop player, Synthwave, Arcade, Pastel pop, Sci-fi HUD, Monochrome.
- Older overlay links will move to the new drag placement. Re-copy your OBS link after placing it.

## 0.8.2
- First tester build: Now Playing overlay, song requests (Twitch, Kick, YouTube, TikTok), Remote DJ with passkey and fixed link, About section with feedback and tip links.
