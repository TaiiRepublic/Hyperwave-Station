# Hyperwave Chat

Every platform's chat in one OBS overlay. Part of the Hyperwave package with Hyperwave Station (now playing overlay, song requests, remote DJ and stream deck). Free for any streamer to use. Made by [TaiiRepublic](https://twitch.tv/taiirepublic).

**Open the app:** https://YOUR-GITHUB-NAME.github.io/hyperwave-chat/

## What it does
- Twitch with nothing to install, plus Kick, YouTube (through Streamer.bot) and TikTok (through TikFinity)
- Six ways to show chat: classic list, Matrix rain, float up, scroll left to right, scroll right to left, and pop-up scatter
- Optional digital rain background behind your chat
- 20 entrance animations and 8 exit animations
- Drag the chat anywhere on screen and resize it, at 1080p, 720p, 1440p, 4K, ultrawide or vertical resolutions
- Boxes, pills, speech bubbles and sci-fi panels, colored by chatter, platform, or your own palette
- Profile pictures with initials as a fallback
- Twitch, 7TV, BetterTTV, FrankerFaceZ and Kick emotes, badges and emoji
- 24 fonts, outlines, glow, filters, highlights and eleven one-click starting styles, all with a live preview
- Shows each new song and every song request in chat, with album art, when Hyperwave Station is running
- Tabbed settings with search, undo and redo, per-setting reset, and a connection check that confirms real chat is arriving

## Setup
1. Open the app link above and follow "How to set this up" in the left panel.
2. Pick a style, click **Copy link**, and paste it into an OBS **Browser** source.

Your settings are stored only in your own overlay link and browser. Nothing is sent to a server.
