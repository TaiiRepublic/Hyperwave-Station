package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"
)

// Categories changes what you're streaming (Just Chatting, a game...) on Twitch and Kick at
// once. Each platform has its own category list, so a search looks in both and lines the
// results up by name.

type CatRef struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	Art  string `json:"art,omitempty"`
}

type CatHit struct {
	Name   string  `json:"name"`
	Art    string  `json:"art,omitempty"`
	Twitch *CatRef `json:"twitch,omitempty"`
	Kick   *CatRef `json:"kick,omitempty"`
}

type Categories struct {
	a *App

	mu   sync.Mutex
	cur  map[string]any
	curT time.Time
	busy bool
}

func catKey(name string) string { return strings.ReplaceAll(normSong(name), " ", "") }

func (c *Categories) platforms() (tw, kk bool) {
	return c.a.tw.Connected(), c.a.kick.Connected()
}

// Search looks on every signed-in platform and merges the results by name.
func (c *Categories) Search(q string) ([]CatHit, map[string]string) {
	q = strings.TrimSpace(q)
	errs := map[string]string{}
	if q == "" {
		return []CatHit{}, errs
	}
	tw, kk := c.platforms()
	var twRes, kkRes []CatRef
	var wg sync.WaitGroup
	var emu sync.Mutex
	setErr := func(k, v string) { emu.Lock(); errs[k] = v; emu.Unlock() }
	if tw {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r, err := c.a.tw.SearchCategories(q)
			if err != nil {
				setErr("twitch", err.Error())
			}
			twRes = r
		}()
	}
	if kk {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r, err := c.a.kick.SearchCategories(q)
			if err != nil {
				setErr("kick", err.Error())
			}
			kkRes = r
		}()
	}
	wg.Wait()
	byKey := map[string]*CatHit{}
	out := []*CatHit{}
	for i := range twRes {
		t := twRes[i]
		k := catKey(t.Name)
		if byKey[k] != nil {
			continue
		}
		h := &CatHit{Name: t.Name, Art: t.Art, Twitch: &t}
		byKey[k] = h
		out = append(out, h)
	}
	for i := range kkRes {
		t := kkRes[i]
		k := catKey(t.Name)
		if h := byKey[k]; h != nil {
			if h.Kick == nil {
				h.Kick = &t
			}
			continue
		}
		h := &CatHit{Name: t.Name, Art: t.Art, Kick: &t}
		byKey[k] = h
		out = append(out, h)
	}
	// If a Twitch result has no Kick match in Kick's results (or the other way round), the
	// platform probably calls it the same thing but didn't rank it; look up the top few by name.
	if tw && kk {
		var wg2 sync.WaitGroup
		for i, h := range out {
			if i >= 4 {
				break
			}
			if h.Kick == nil {
				wg2.Add(1)
				go func(h *CatHit) {
					defer wg2.Done()
					if r, err := c.a.kick.SearchCategories(h.Name); err == nil {
						for j := range r {
							if catKey(r[j].Name) == catKey(h.Name) {
								h.Kick = &r[j]
								return
							}
						}
					}
				}(h)
			} else if h.Twitch == nil {
				wg2.Add(1)
				go func(h *CatHit) {
					defer wg2.Done()
					if r, err := c.a.tw.SearchCategories(h.Name); err == nil {
						for j := range r {
							if catKey(r[j].Name) == catKey(h.Name) {
								h.Twitch = &r[j]
								h.Art = r[j].Art
								return
							}
						}
					}
				}(h)
			}
		}
		wg2.Wait()
	}
	res := make([]CatHit, 0, len(out))
	for _, h := range out {
		res = append(res, *h)
	}
	return res, errs
}

func (c *Categories) forget() {
	c.mu.Lock()
	c.curT = time.Time{}
	c.mu.Unlock()
}

// Current is the category on each signed-in platform. Without refresh it answers at once from
// what it last saw (looking again in the background every 30 seconds), so the deck never waits.
func (c *Categories) Current(refresh bool) map[string]any {
	if refresh {
		return c.fetch()
	}
	c.mu.Lock()
	out, stale := c.cur, time.Since(c.curT) > 30*time.Second
	if stale && !c.busy {
		c.busy = true
		go func() {
			c.fetch()
			c.mu.Lock()
			c.busy = false
			c.mu.Unlock()
		}()
	}
	c.mu.Unlock()
	tw, kk := c.platforms()
	if out == nil {
		return map[string]any{"twitchOn": tw, "kickOn": kk, "recent": c.a.st.Get().RecentCats}
	}
	cp := map[string]any{}
	for k, v := range out {
		cp[k] = v
	}
	cp["twitchOn"], cp["kickOn"], cp["recent"] = tw, kk, c.a.st.Get().RecentCats
	return cp
}

func (c *Categories) fetch() map[string]any {
	tw, kk := c.platforms()
	out := map[string]any{"twitch": nil, "kick": nil, "twitchOn": tw, "kickOn": kk}
	var wg sync.WaitGroup
	var mu sync.Mutex
	if tw {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if r, err := c.a.tw.CurrentCategory(); err == nil {
				mu.Lock()
				out["twitch"] = r
				mu.Unlock()
			}
		}()
	}
	if kk {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if r, err := c.a.kick.CurrentCategory(); err == nil {
				mu.Lock()
				out["kick"] = r
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	out["recent"] = c.a.st.Get().RecentCats
	c.mu.Lock()
	c.cur, c.curT = out, time.Now()
	c.mu.Unlock()
	return out
}

// Set changes the category on every platform the pick has (and that's signed in).
func (c *Categories) Set(h CatHit) (string, error) {
	tw, kk := c.platforms()
	if !tw && !kk {
		return "", errors.New("sign in to Twitch or Kick first (dashboard → OBS & Deck)")
	}
	var done, failed []string
	var wg sync.WaitGroup
	var mu sync.Mutex
	add := func(ok bool, s string) {
		mu.Lock()
		if ok {
			done = append(done, s)
		} else {
			failed = append(failed, s)
		}
		mu.Unlock()
	}
	if tw {
		if h.Twitch != nil && h.Twitch.ID != "" {
			wg.Add(1)
			go func() {
				defer wg.Done()
				if err := c.a.tw.SetCategory(h.Twitch.ID); err != nil {
					add(false, "Twitch: "+err.Error())
				} else {
					add(true, "Twitch")
				}
			}()
		} else {
			add(false, "Twitch doesn't have "+h.Name)
		}
	}
	if kk {
		if h.Kick != nil && h.Kick.ID != "" {
			wg.Add(1)
			go func() {
				defer wg.Done()
				if err := c.a.kick.SetCategory(h.Kick.ID); err != nil {
					add(false, "Kick: "+err.Error())
				} else {
					add(true, "Kick")
				}
			}()
		} else {
			add(false, "Kick doesn't have "+h.Name)
		}
	}
	wg.Wait()
	c.forget()
	if len(done) > 0 {
		c.a.st.Update(func(cf *Config) {
			list := []CatHit{h}
			for _, r := range cf.RecentCats {
				if catKey(r.Name) != catKey(h.Name) && len(list) < 12 {
					list = append(list, r)
				}
			}
			cf.RecentCats = list
		})
	}
	switch {
	case len(done) == 0:
		return "", errors.New(strings.Join(failed, ". "))
	case len(failed) > 0:
		return fmt.Sprintf("🎮 %s on %s. Not changed: %s", h.Name, strings.Join(done, " and "), strings.Join(failed, ". ")), nil
	}
	return fmt.Sprintf("🎮 Now in %s on %s", h.Name, strings.Join(done, " and ")), nil
}

// SetByName is for deck buttons: find the category with exactly this name on each platform.
func (c *Categories) SetByName(name string) (string, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return "", errors.New("which category?")
	}
	for _, r := range c.a.st.Get().RecentCats { // already known: no search needed
		if catKey(r.Name) == catKey(name) && (r.Twitch != nil || r.Kick != nil) {
			tw, kk := c.platforms()
			if (!tw || r.Twitch != nil) && (!kk || r.Kick != nil) {
				return c.Set(r)
			}
		}
	}
	hits, errs := c.Search(name)
	for _, h := range hits {
		if catKey(h.Name) == catKey(name) {
			return c.Set(h)
		}
	}
	if len(errs) > 0 {
		var e []string
		for _, v := range errs {
			e = append(e, v)
		}
		return "", errors.New(strings.Join(e, ". "))
	}
	return "", fmt.Errorf("no category called %q on Twitch or Kick", name)
}

func (a *App) categoryDeckRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/deck/category", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			var h CatHit
			b, _ := io.ReadAll(io.LimitReader(r.Body, 64<<10))
			if json.Unmarshal(b, &h) != nil || strings.TrimSpace(h.Name) == "" {
				jsonOut(w, 400, map[string]any{"ok": false, "error": "pick a category"})
				return
			}
			msg, err := a.cat.Set(h)
			if err != nil {
				jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error(), "current": a.cat.Current(true)})
				return
			}
			jsonOut(w, 200, map[string]any{"ok": true, "message": msg, "current": a.cat.Current(true)})
			return
		}
		jsonOut(w, 200, a.cat.Current(r.FormValue("refresh") == "1"))
	}))
	m.HandleFunc("/api/deck/category/search", wrap(func(w http.ResponseWriter, r *http.Request) {
		hits, errs := a.cat.Search(r.FormValue("q"))
		tw, kk := a.cat.platforms()
		jsonOut(w, 200, map[string]any{"results": hits, "errors": errs, "twitchOn": tw, "kickOn": kk})
	}))
}
