//go:build !hwsdev

package main

// devEnv: normal builds ignore the HWS_* test settings, so Hyperwave always talks to the real services.
func devEnv(string) string { return "" }
