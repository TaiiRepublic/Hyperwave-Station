package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"
)

// Since October 2026 Kick's web client asks Kick which chat server and key to use
// ("negotiates") instead of using one fixed Pusher key. Station does the same, and keeps
// the old fixed key only as a last resort.

var (
	kickWeb       = envOr("HWS_KICK_WEB", "https://web.kick.com")
	kickSite      = envOr("HWS_KICK_SITE", "https://kick.com")
	pusherKeyRe   = regexp.MustCompile(`^[A-Za-z0-9]+$`)
	pusherClustRe = regexp.MustCompile(`^[A-Za-z0-9-]+$`)
)

const pusherQuery = "protocol=7&client=js&version=8.4.0&flash=false"

type kickPusherInfo struct {
	Key     string `json:"key"`
	Cluster string `json:"cluster"`
	From    string `json:"from"` // "kick" when Kick told us, "fallback" for the old fixed key
	at      time.Time
}

func (k kickPusherInfo) URL() string {
	return "wss://ws-" + k.Cluster + ".pusher.com/app/" + k.Key + "?" + pusherQuery
}

var kickRT struct {
	mu       sync.Mutex
	info     kickPusherInfo
	clientID string
	lastErr  string
}

func kickClientID() string {
	if kickRT.clientID == "" {
		b := make([]byte, 16)
		rand.Read(b)
		b[6] = b[6]&0x0f | 0x40
		b[8] = b[8]&0x3f | 0x80
		h := hex.EncodeToString(b)
		kickRT.clientID = h[0:8] + "-" + h[8:12] + "-" + h[12:16] + "-" + h[16:20] + "-" + h[20:]
	}
	return kickRT.clientID
}

func kickBrowserHeaders(req *http.Request) {
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Origin", "https://kick.com")
	req.Header.Set("Referer", "https://kick.com/")
}

// kickLookup finds a channel's chatroom ID and channel ID from its name.
func kickLookup(slug string) (chatroomID, channelID string, err error) {
	req, _ := http.NewRequest("GET", kickSite+"/api/v2/channels/"+url.PathEscape(slug), nil)
	kickBrowserHeaders(req)
	res, err := (&http.Client{Timeout: 10 * time.Second}).Do(req)
	if err != nil {
		return "", "", err
	}
	defer res.Body.Close()
	var r struct {
		ID       int64 `json:"id"`
		Chatroom struct {
			ID int64 `json:"id"`
		} `json:"chatroom"`
	}
	b, _ := io.ReadAll(io.LimitReader(res.Body, 2<<20))
	json.Unmarshal(b, &r)
	if r.Chatroom.ID == 0 {
		return "", "", fmt.Errorf("Kick blocked the lookup (%d) — paste your chatroom ID in the dashboard", res.StatusCode)
	}
	ch := ""
	if r.ID != 0 {
		ch = fmt.Sprint(r.ID)
	}
	return fmt.Sprint(r.Chatroom.ID), ch, nil
}

// kickNegotiate asks Kick which Pusher key and cluster to use.
func kickNegotiate(channelID string) (kickPusherInfo, error) {
	body, _ := json.Marshal(map[string]any{
		"client":       map[string]string{"id": kickClientID(), "type": "web"},
		"capabilities": map[string]any{"accepted_providers": []map[string]string{{"provider": "pusher"}}},
	})
	urls := []string{}
	if channelID != "" {
		urls = append(urls, kickWeb+"/api/v1/realtime/channels/"+url.PathEscape(channelID)+"/chat/connection")
	}
	urls = append(urls, kickWeb+"/api/v1/realtime/connection")
	var lastErr error
	for _, u := range urls {
		req, _ := http.NewRequest("POST", u, bytes.NewReader(body))
		kickBrowserHeaders(req)
		req.Header.Set("Content-Type", "application/json")
		res, err := (&http.Client{Timeout: 10 * time.Second}).Do(req)
		if err != nil {
			lastErr = err
			continue
		}
		b, _ := io.ReadAll(io.LimitReader(res.Body, 1<<20))
		res.Body.Close()
		if res.StatusCode/100 != 2 {
			lastErr = fmt.Errorf("Kick answered %d when asked for its chat server", res.StatusCode)
			continue
		}
		var r struct {
			Data struct {
				Connections []struct {
					Provider    string `json:"provider"`
					Credentials struct {
						AppKey  string `json:"app_key"`
						Cluster string `json:"cluster"`
					} `json:"credentials"`
				} `json:"connections"`
			} `json:"data"`
		}
		if json.Unmarshal(b, &r) != nil {
			lastErr = fmt.Errorf("Kick's chat server answer wasn't readable")
			continue
		}
		for _, c := range r.Data.Connections {
			if c.Provider == "pusher" && pusherKeyRe.MatchString(c.Credentials.AppKey) {
				cl := c.Credentials.Cluster
				if !pusherClustRe.MatchString(cl) {
					cl = "us2"
				}
				return kickPusherInfo{Key: c.Credentials.AppKey, Cluster: cl, From: "kick", at: time.Now()}, nil
			}
		}
		lastErr = fmt.Errorf("Kick didn't offer a chat server Hyperwave can use")
	}
	return kickPusherInfo{}, lastErr
}

// kickPusher returns where to connect for Kick chat: Kick's current answer (asked again
// every 30 minutes, or right away after Kick refused the key), else the old fixed key.
func kickPusherFor(channelID string, refresh bool) kickPusherInfo {
	kickRT.mu.Lock()
	cur := kickRT.info
	kickRT.mu.Unlock()
	if !refresh && cur.From == "kick" && time.Since(cur.at) < 30*time.Minute {
		return cur
	}
	info, err := kickNegotiate(channelID)
	kickRT.mu.Lock()
	defer kickRT.mu.Unlock()
	if err == nil {
		kickRT.info, kickRT.lastErr = info, ""
		return info
	}
	kickRT.lastErr = err.Error()
	if cur.From == "kick" { // keep Kick's last answer rather than going back to the old key
		return cur
	}
	return kickPusherInfo{Key: "32cbd69e4b950bf97679", Cluster: "us2", From: "fallback", at: time.Now()}
}

// kickPusherNow is what the chat overlay asks Station for (no secrets: it's the same
// public key every Kick viewer's browser gets).
func kickPusherNow() map[string]any {
	kickRT.mu.Lock()
	defer kickRT.mu.Unlock()
	if kickRT.info.Key == "" {
		return map[string]any{"ok": false, "error": kickRT.lastErr}
	}
	return map[string]any{"ok": true, "key": kickRT.info.Key, "cluster": kickRT.info.Cluster, "from": kickRT.info.From}
}

func (k kickPusherInfo) dialURL() string {
	if dev := devEnv("HWS_KICK_PUSHER_HOST"); dev != "" { // test builds: a stand-in chat server
		return dev + "/app/" + k.Key + "?" + pusherQuery
	}
	return k.URL()
}

var _ = strings.TrimSpace
