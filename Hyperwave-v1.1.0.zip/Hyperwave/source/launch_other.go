//go:build !windows

package main

import (
	"errors"
	"log"
)

// Opening programs is a Windows feature.

func startProgram(path, args, dir string) error {
	if devEnv("HWS_FAKE_LAUNCH") != "" {
		log.Printf("[test] would start %q args=%q dir=%q", path, args, dir)
		return nil
	}
	return errors.New("opening programs only works on Windows")
}

func openURL(u string) error {
	if devEnv("HWS_FAKE_LAUNCH") != "" {
		log.Printf("[test] would open %q", u)
		return nil
	}
	return errors.New("opening programs only works on Windows")
}

func programIcon(path string) ([]byte, error) { return nil, errors.New("windows only") }
