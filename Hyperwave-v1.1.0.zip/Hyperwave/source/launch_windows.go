//go:build windows

package main

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
)

// startProgram opens a program the way double-clicking it would.
func startProgram(path, args, dir string) error {
	ext := strings.ToLower(filepath.Ext(path))
	var c *exec.Cmd
	if ext == ".exe" || ext == ".com" {
		c = exec.Command(path)
		// pass the shortcut's arguments exactly as written
		c.SysProcAttr = &syscall.SysProcAttr{CmdLine: `"` + path + `"` + map[bool]string{true: " " + args, false: ""}[args != ""]}
	} else {
		// documents, .bat files, folders…: let Windows pick the program
		c = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", path)
	}
	if dir != "" {
		if st, err := os.Stat(dir); err == nil && st.IsDir() {
			c.Dir = dir
		}
	}
	if err := c.Start(); err != nil {
		return err
	}
	go c.Wait()
	return nil
}

// openURL opens a game link (steam://…) or web link with the program Windows uses for it.
// rundll32 is used instead of cmd /c start, so nothing in the link is read as a command.
func openURL(u string) error {
	c := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", u)
	if err := c.Start(); err != nil {
		return err
	}
	go c.Wait()
	return nil
}

// programIcon gets a program's icon as a PNG, using Windows' own icon lookup.
func programIcon(path string) ([]byte, error) {
	if _, err := os.Stat(path); err != nil {
		return nil, err
	}
	out, err := os.CreateTemp("", "hws-icon-*.png")
	if err != nil {
		return nil, err
	}
	out.Close()
	defer os.Remove(out.Name())
	esc := func(s string) string { return strings.ReplaceAll(s, "'", "''") }
	script := "Add-Type -AssemblyName System.Drawing; $i=[System.Drawing.Icon]::ExtractAssociatedIcon('" + esc(path) + "'); " +
		"if($i){$i.ToBitmap().Save('" + esc(out.Name()) + "',[System.Drawing.Imaging.ImageFormat]::Png)}"
	c := exec.Command(psPath(), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script)
	hideWindow(c)
	if err := c.Run(); err != nil {
		return nil, err
	}
	b, err := os.ReadFile(out.Name())
	if err != nil || len(b) == 0 {
		return nil, errors.New("no icon")
	}
	return b, nil
}
