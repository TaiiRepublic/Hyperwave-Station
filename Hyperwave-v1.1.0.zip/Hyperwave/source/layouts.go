package main

import (
	"bytes"
	"encoding/json"
	"io"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

// Scene layouts: the chat and music overlays can load a saved look for each OBS scene.
// Files live in overlays\layouts\chat and overlays\layouts\music next to the app, so the
// overlays can also read them when OBS loads them straight from disk without Station.

var layoutKinds = map[string]bool{"chat": true, "music": true}

// overlayPages are copied into the overlays folder so OBS can load them as local files.
var overlayPages = map[string]string{"chat.html": "web/chat.html", "nowplaying.html": "web/nowplaying.html"}

const overlaysReadme = "Hyperwave overlays you can load in OBS straight from this folder.\r\n" +
	"Hyperwave Station doesn't need to be running for them to show.\r\n\r\n" +
	"chat.html        - the chat overlay\r\n" +
	"nowplaying.html  - the music overlay\r\n" +
	"layouts\\chat     - chat layouts (default.json, plus one per OBS scene)\r\n" +
	"layouts\\music    - music overlay layouts\r\n\r\n" +
	"Hyperwave Station refreshes chat.html and nowplaying.html when it starts, so\r\n" +
	"don't edit them here. See SETUP-GUIDE.md, section \"Scene layouts\".\r\n"

func (a *App) overlaysDir() string { return filepath.Join(filepath.Dir(a.st.path), "overlays") }

func (a *App) layoutDir(kind string) string {
	return filepath.Join(a.overlaysDir(), "layouts", kind)
}

// layoutFile turns a layout or scene name into a safe file name. The overlay pages use the same rule.
var badFileChars = regexp.MustCompile(`[\\/:*?"<>|\x00-\x1f]`)

func layoutFile(name string) string {
	n := badFileChars.ReplaceAllString(name, "_")
	n = strings.Trim(n, " .")
	if r := []rune(n); len(r) > 80 {
		n = string(r[:80])
	}
	if n == "" {
		n = "_"
	}
	return n + ".json"
}

// SyncOverlays writes the overlay pages and layout folders next to the app.
func (a *App) SyncOverlays() {
	dir := a.overlaysDir()
	for _, k := range []string{"chat", "music"} {
		if err := os.MkdirAll(a.layoutDir(k), 0755); err != nil {
			log.Printf("[overlays] can't create %s: %v", dir, err)
			return
		}
	}
	for name, src := range overlayPages {
		b, err := fs.ReadFile(webFS, src)
		if err != nil {
			continue
		}
		p := filepath.Join(dir, name)
		if cur, err := os.ReadFile(p); err == nil && bytes.Equal(cur, b) {
			continue
		}
		if err := os.WriteFile(p, b, 0644); err != nil {
			log.Printf("[overlays] can't update %s: %v", p, err)
		}
	}
	rp := filepath.Join(dir, "README.txt")
	if cur, err := os.ReadFile(rp); err != nil || string(cur) != overlaysReadme {
		os.WriteFile(rp, []byte(overlaysReadme), 0644)
	}
}

type layoutDoc struct {
	Hyperwave string          `json:"hyperwave"`
	Name      string          `json:"name"`
	Settings  json.RawMessage `json:"settings"`
}

func (a *App) listLayouts(kind string) []string {
	ents, err := os.ReadDir(a.layoutDir(kind))
	if err != nil {
		return []string{}
	}
	out := []string{}
	for _, e := range ents {
		if e.IsDir() || !strings.EqualFold(filepath.Ext(e.Name()), ".json") {
			continue
		}
		name := strings.TrimSuffix(e.Name(), filepath.Ext(e.Name()))
		if b, err := os.ReadFile(filepath.Join(a.layoutDir(kind), e.Name())); err == nil {
			var d layoutDoc
			if json.Unmarshal(b, &d) == nil && d.Name != "" && layoutFile(d.Name) == e.Name() {
				name = d.Name
			}
		}
		out = append(out, name)
	}
	sort.Slice(out, func(i, j int) bool {
		if (out[i] == "default") != (out[j] == "default") {
			return out[i] == "default"
		}
		return strings.ToLower(out[i]) < strings.ToLower(out[j])
	})
	return out
}

// layoutRoutes: saving and deleting only from Station's own pages; reading is open so
// overlays (from Station or from OBS) can load them.
func (a *App) layoutRoutes(m *http.ServeMux, g func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/layouts", g(func(w http.ResponseWriter, r *http.Request) {
		st := a.obs.State()
		scenes := append([]string{}, st.Scenes...)
		jsonOut(w, 200, map[string]any{
			"chat": a.listLayouts("chat"), "music": a.listLayouts("music"),
			"scenes": scenes, "folder": filepath.Join(a.overlaysDir(), "layouts"),
		})
	}))
	m.HandleFunc("/api/layouts/", g(func(w http.ResponseWriter, r *http.Request) {
		kind, name, ok := strings.Cut(strings.TrimPrefix(r.URL.Path, "/api/layouts/"), "/")
		if !ok || !layoutKinds[kind] || strings.TrimSpace(name) == "" {
			http.Error(w, "bad layout", 400)
			return
		}
		p := filepath.Join(a.layoutDir(kind), layoutFile(name))
		switch r.Method {
		case "GET":
			b, err := os.ReadFile(p)
			if err != nil {
				http.NotFound(w, r)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			w.Write(b)
		case "POST":
			b, err := io.ReadAll(io.LimitReader(r.Body, 256<<10+1))
			if err != nil || len(b) > 256<<10 {
				http.Error(w, "layout too big", 400)
				return
			}
			var d layoutDoc
			var set map[string]any
			if json.Unmarshal(b, &d) != nil || json.Unmarshal(d.Settings, &set) != nil || set == nil {
				http.Error(w, "that isn't a Hyperwave layout", 400)
				return
			}
			d.Hyperwave, d.Name = kind+"-layout", strings.TrimSpace(name)
			out, _ := json.MarshalIndent(d, "", "  ")
			if err := os.MkdirAll(filepath.Dir(p), 0755); err == nil {
				err = os.WriteFile(p, out, 0644)
			}
			if err != nil {
				jsonOut(w, 200, map[string]any{"ok": false, "error": "couldn't save: " + err.Error()})
				return
			}
			log.Printf("[layouts] saved %s layout %q", kind, d.Name)
			jsonOut(w, 200, map[string]any{"ok": true, "file": p})
		case "DELETE":
			if err := os.Remove(p); err != nil && !os.IsNotExist(err) {
				jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
				return
			}
			jsonOut(w, 200, map[string]any{"ok": true})
		default:
			http.Error(w, "method", 405)
		}
	}))
	// /layouts/chat/<file>.json: what the overlays fetch (relative to /chat and /overlay).
	// Same-site only: a starting layout holds passwords and keys, so other websites can't read it.
	m.HandleFunc("/layouts/", g(func(w http.ResponseWriter, r *http.Request) {
		kind, file, ok := strings.Cut(strings.TrimPrefix(r.URL.Path, "/layouts/"), "/")
		if !ok || !layoutKinds[kind] || !strings.HasSuffix(file, ".json") {
			http.NotFound(w, r)
			return
		}
		name := strings.TrimSuffix(file, ".json")
		b, err := os.ReadFile(filepath.Join(a.layoutDir(kind), layoutFile(name)))
		if err != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		w.Write(b)
	}))
}
