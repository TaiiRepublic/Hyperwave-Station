package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

// My Deck: buttons the streamer designs themselves. Each button runs one or more steps in order,
// e.g. switch to the BRB scene, mute the mic, then post "be right back" in chat.

type PadStep struct {
	A string `json:"a"`           // action, same names as DeckDo, plus "wait"
	V string `json:"v,omitempty"` // value: scene, audio source, message, or seconds for wait
	P string `json:"p,omitempty"` // platform for chat messages
}

type PadButton struct {
	ID      string    `json:"id"`
	Label   string    `json:"label"`
	Icon    string    `json:"icon,omitempty"`
	Color   string    `json:"color,omitempty"`
	Confirm bool      `json:"confirm,omitempty"` // press and hold to run
	Image   string    `json:"image,omitempty"`   // your own picture (from My Deck's media)
	NoLabel bool      `json:"noLabel,omitempty"` // show only the picture
	PicFit  string    `json:"picFit,omitempty"`  // "icon": a small program icon, shown whole
	Steps   []PadStep `json:"steps"`
}

var padActions = map[string]bool{"scene": true, "clip": true, "replay": true, "twitchclip": true, "record": true,
	"stream-start": true, "stream-stop": true, "mute": true, "music-toggle": true, "music-skip": true, "music-prev": true,
	"requests": true, "say": true, "wait": true,
	"sound": true, "sound-stop": true, "source": true, "sbaction": true, "category": true, "launch": true}

func newPadID() string {
	b := make([]byte, 5)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func defaultPad() []PadButton {
	return []PadButton{
		{ID: newPadID(), Label: "Clip that!", Icon: "🎬", Color: "#D7263D", Steps: []PadStep{{A: "clip"}}},
		{ID: newPadID(), Label: "Be right back", Icon: "☕", Color: "#F2A541", Steps: []PadStep{{A: "say", V: "Be right back, don't go anywhere!", P: "all"}}},
		{ID: newPadID(), Label: "Hydrate!", Icon: "💧", Color: "#3FC1C9", Steps: []PadStep{{A: "say", V: "Hydration check! Everyone grab a drink 💧", P: "all"}}},
		{ID: newPadID(), Label: "Play / pause", Icon: "⏯", Color: "#3FC98B", Steps: []PadStep{{A: "music-toggle"}}},
		{ID: newPadID(), Label: "Skip song", Icon: "⏭", Color: "#3FC98B", Steps: []PadStep{{A: "music-skip"}}},
		{ID: newPadID(), Label: "Record", Icon: "⏺", Color: "#8B5CF6", Steps: []PadStep{{A: "record"}}},
	}
}

func (a *App) padButtons() []PadButton {
	c := a.st.Get()
	if c.PadButtons == nil {
		d := defaultPad()
		a.st.Update(func(c *Config) {
			if c.PadButtons == nil {
				c.PadButtons = d
			}
		})
		return a.st.Get().PadButtons
	}
	return c.PadButtons
}

func cleanPad(in []PadButton) ([]PadButton, error) {
	if len(in) > 60 {
		return nil, errors.New("that's more than 60 buttons")
	}
	seen := map[string]bool{}
	out := make([]PadButton, 0, len(in))
	for i, b := range in {
		b.Label = strings.TrimSpace(b.Label)
		if len([]rune(b.Label)) > 40 {
			b.Label = string([]rune(b.Label)[:40])
		}
		if len([]rune(b.Icon)) > 4 {
			b.Icon = string([]rune(b.Icon)[:4])
		}
		if b.Color != "" && (len(b.Color) != 7 || b.Color[0] != '#') {
			b.Color = ""
		}
		if b.Image != "" && !mediaFileRe.MatchString(b.Image) {
			b.Image = ""
		}
		if b.Image == "" {
			b.NoLabel = false
		}
		if b.PicFit != "icon" {
			b.PicFit = ""
		}
		if b.ID == "" || seen[b.ID] || len(b.ID) > 20 {
			b.ID = newPadID()
		}
		seen[b.ID] = true
		if len(b.Steps) == 0 {
			return nil, fmt.Errorf("button %d (%s) has nothing for it to do", i+1, b.Label)
		}
		if len(b.Steps) > 10 {
			return nil, fmt.Errorf("button %q has more than 10 steps", b.Label)
		}
		if b.Label == "" && b.Icon == "" {
			b.Label = "Button"
		}
		for j := range b.Steps {
			s := &b.Steps[j]
			s.A = strings.TrimSpace(s.A)
			if !padActions[s.A] {
				return nil, fmt.Errorf("button %q: step %d isn't something the deck can do", b.Label, j+1)
			}
			s.V = strings.TrimSpace(s.V)
			if len([]rune(s.V)) > 480 {
				return nil, fmt.Errorf("button %q: step %d's text is too long", b.Label, j+1)
			}
			need := map[string]string{"scene": "scene", "mute": "audio source", "say": "message", "sound": "sound", "source": "source",
				"sbaction": "Streamer.bot action name", "category": "category", "launch": "program"}
			if what, ok := need[s.A]; ok && s.V == "" {
				return nil, fmt.Errorf("button %q: step %d needs a %s", b.Label, j+1, what)
			}
			if s.A == "launch" && !launcherIDRe.MatchString(s.V) {
				return nil, fmt.Errorf("button %q: step %d needs a program. Drag one onto the deck on your PC", b.Label, j+1)
			}
			if s.A == "wait" {
				f, err := strconv.ParseFloat(s.V, 64)
				if err != nil || f < 0.1 || f > maxWait {
					return nil, fmt.Errorf("button %q: a wait can be from 0.1 seconds to 60 minutes", b.Label)
				}
			}
		}
		out = append(out, b)
	}
	return out, nil
}

const maxWait = 3600 // one wait step can be up to an hour

// buttons whose steps are still running in the background, so a second press can stop them
var padRun = struct {
	sync.Mutex
	m map[string]chan struct{}
}{m: map[string]chan struct{}{}}

func padRunning() []string {
	padRun.Lock()
	defer padRun.Unlock()
	out := []string{}
	for id := range padRun.m {
		out = append(out, id)
	}
	return out
}

func fmtWait(sec float64) string {
	d := time.Duration(sec * float64(time.Second)).Round(time.Second)
	if d < time.Minute {
		return strconv.FormatFloat(sec, 'f', -1, 64) + " s"
	}
	m, sc := int(d.Minutes()), int(d.Seconds())%60
	if sc == 0 {
		return strconv.Itoa(m) + " min"
	}
	return fmt.Sprintf("%d min %d s", m, sc)
}

// PadPress runs a My Deck button's steps in order. Buttons with short waits finish before
// answering; buttons with longer waits keep running in the background, and pressing the
// button again while it runs stops it.
func (a *App) PadPress(id string) (string, error) {
	var btn *PadButton
	for _, b := range a.padButtons() {
		if b.ID == id {
			bb := b
			btn = &bb
			break
		}
	}
	if btn == nil {
		return "", errors.New("that button doesn't exist any more. Copy its link again")
	}
	name := btn.Label
	if name == "" {
		name = btn.Icon
	}
	padRun.Lock()
	if stop, ok := padRun.m[id]; ok {
		close(stop)
		delete(padRun.m, id)
		padRun.Unlock()
		return name + ": stopped", nil
	}
	total := 0.0
	for _, s := range btn.Steps {
		if s.A == "wait" {
			f, _ := strconv.ParseFloat(s.V, 64)
			total += f
		}
	}
	stop := make(chan struct{})
	padRun.m[id] = stop
	padRun.Unlock()

	run := func() ([]string, error) {
		defer func() {
			padRun.Lock()
			if padRun.m[id] == stop {
				delete(padRun.m, id)
			}
			padRun.Unlock()
		}()
		var done []string
		for i, s := range btn.Steps {
			if s.A == "wait" {
				f, _ := strconv.ParseFloat(s.V, 64)
				if f > maxWait {
					f = maxWait
				}
				select {
				case <-time.After(time.Duration(f * float64(time.Second))):
				case <-stop:
					return done, errors.New("stopped")
				}
				continue
			}
			select {
			case <-stop:
				return done, errors.New("stopped")
			default:
			}
			msg, err := a.DeckDo(s.A, s.V, s.P)
			if err != nil {
				if len(btn.Steps) == 1 {
					return done, err
				}
				return done, fmt.Errorf("step %d stopped: %v", i+1, err)
			}
			done = append(done, msg)
		}
		return done, nil
	}

	if total > 8 {
		go func() {
			if _, err := run(); err != nil && err.Error() != "stopped" {
				log.Printf("[deck] %s: %v", name, err)
			}
		}()
		return fmt.Sprintf("%s: running (about %s). Press it again to stop.", name, fmtWait(total)), nil
	}
	done, err := run()
	if err != nil {
		return "", err
	}
	if len(done) == 1 {
		return done[0], nil
	}
	return name + ": done", nil
}

func (a *App) padRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/deck/pad", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			b, _ := io.ReadAll(io.LimitReader(r.Body, 256<<10))
			var in []PadButton
			if err := json.Unmarshal(b, &in); err != nil {
				jsonOut(w, 400, map[string]any{"ok": false, "error": "couldn't read the buttons"})
				return
			}
			clean, err := cleanPad(in)
			if err != nil {
				jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
				return
			}
			a.st.Update(func(c *Config) { c.PadButtons = clean })
		}
		jsonOut(w, 200, map[string]any{"ok": true, "buttons": a.padButtons()})
	}))
}
