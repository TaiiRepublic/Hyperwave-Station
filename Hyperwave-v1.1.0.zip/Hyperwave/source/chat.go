package main

import (
	"bufio"
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

// ChatHub is the optional built-in chat listener ("standalone mode"). It reads Twitch and Kick
// chat anonymously and runs DJ commands from mods. It can't post replies (no bot login) —
// replies come from Streamer.bot when you use that route instead.
type ChatHub struct {
	a      *App
	mu     sync.Mutex
	gen    int
	twitch string
	kick   string
	// Kick refused the chat key last time, so ask Kick for a fresh one
	kickRefused bool
}

func (h *ChatHub) Status() map[string]string {
	h.mu.Lock()
	defer h.mu.Unlock()
	return map[string]string{"twitch": h.twitch, "kick": h.kick}
}

func (h *ChatHub) set(which, v string) {
	h.mu.Lock()
	if which == "twitch" {
		h.twitch = v
	} else {
		h.kick = v
	}
	h.mu.Unlock()
}

func (h *ChatHub) alive(g int) bool {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.gen == g
}

func (h *ChatHub) Restart() {
	h.mu.Lock()
	h.gen++
	g := h.gen
	h.twitch, h.kick = "off", "off"
	h.mu.Unlock()
	c := h.a.st.Get()
	// Read chat when commands are on, or when the deck shows that platform's chat.
	if (c.ListenTwitch || c.DeckTwitch) && strings.TrimSpace(c.TwitchChannel) != "" {
		go h.loop(g, "twitch", func() error { return h.runTwitch(g, c) })
	}
	if (c.ListenKick || c.DeckKick) && (strings.TrimSpace(c.KickChannel) != "" || c.KickChatroomID != "") {
		go h.loop(g, "kick", func() error { return h.runKick(g, c) })
	}
}

func (h *ChatHub) loop(g int, which string, run func() error) {
	delay := 2 * time.Second
	for h.alive(g) {
		h.set(which, "connecting")
		start := time.Now()
		err := run()
		if !h.alive(g) {
			return
		}
		msg := "disconnected"
		if err != nil {
			msg = "error: " + err.Error()
			log.Printf("[%s chat] %v", which, err)
		}
		// It was connected and working, so this is a normal drop: reconnect quickly.
		if time.Since(start) > time.Minute {
			delay = 2 * time.Second
			msg = "reconnecting…"
		}
		h.set(which, msg)
		time.Sleep(delay)
		if delay < 60*time.Second {
			delay *= 2
		}
	}
}

// handle runs one chat line through the command rules.
func (h *ChatHub) handle(platform, user string, isMod bool, text string) {
	c := h.a.st.Get()
	p := c.CommandPrefix
	text = strings.TrimSpace(text)
	if !strings.HasPrefix(text, p) {
		return
	}
	body := strings.TrimPrefix(text, p)
	cmd, arg, _ := strings.Cut(body, " ")
	cmd = strings.ToLower(cmd)
	for _, d := range c.ExtraDJs {
		if strings.EqualFold(strings.TrimPrefix(strings.TrimSpace(d), "@"), user) {
			isMod = true
		}
	}
	switch cmd {
	case "sr", "songrequest", "request":
		if c.ViewerSRCommand || isMod {
			r := h.a.Request(arg, user, platform, false)
			log.Printf("[%s] %s !%s -> %s", platform, user, cmd, r.Reply)
		}
		return
	}
	if !c.ModCommands || !isMod {
		return
	}
	djCmds := map[string]bool{"skip": true, "next": true, "prev": true, "back": true, "pause": true, "stop": true, "play": true,
		"resume": true, "vol": true, "volume": true, "shuffle": true, "repeat": true, "playlist": true, "pl": true,
		"playnow": true, "pn": true, "sron": true, "sroff": true, "requests": true}
	if !djCmds[cmd] {
		return
	}
	reply, err := h.a.Command(cmd, arg, user)
	if err != nil {
		reply = "⚠ " + err.Error()
	}
	log.Printf("[%s] %s !%s %s -> %s", platform, user, cmd, arg, reply)
}

// ---------------- Twitch (anonymous IRC over TLS) ----------------

func (h *ChatHub) runTwitch(g int, c Config) error {
	ch := strings.ToLower(strings.TrimPrefix(strings.TrimSpace(c.TwitchChannel), "#"))
	ch = strings.TrimPrefix(ch, "https://www.twitch.tv/")
	ch = strings.TrimPrefix(ch, "twitch.tv/")
	conn, err := tls.DialWithDialer(&net.Dialer{Timeout: 10 * time.Second}, "tcp", "irc.chat.twitch.tv:6697", nil)
	if err != nil {
		return err
	}
	defer conn.Close()
	fmt.Fprintf(conn, "CAP REQ :twitch.tv/tags twitch.tv/commands\r\nPASS SCHMOOPIIE\r\nNICK justinfan%d\r\nJOIN #%s\r\n", 10000+time.Now().Nanosecond()%80000, ch)
	go func() { // close when settings change
		for h.alive(g) {
			time.Sleep(time.Second)
		}
		conn.Close()
	}()
	rd := bufio.NewReader(conn)
	for {
		conn.SetReadDeadline(time.Now().Add(6 * time.Minute))
		line, err := rd.ReadString('\n')
		if err != nil {
			return err
		}
		line = strings.TrimRight(line, "\r\n")
		if strings.HasPrefix(line, "PING") {
			fmt.Fprintf(conn, "PONG%s\r\n", strings.TrimPrefix(line, "PING"))
			continue
		}
		if strings.Contains(line, " 366 ") || strings.Contains(line, "End of /NAMES") {
			h.set("twitch", "connected #"+ch)
			log.Println("[twitch chat] listening in #" + ch)
		}
		if !strings.HasPrefix(line, "@") || !strings.Contains(line, " PRIVMSG #") {
			continue
		}
		tagStr, rest, _ := strings.Cut(line[1:], " ")
		tags := map[string]string{}
		for _, kv := range strings.Split(tagStr, ";") {
			k, v, _ := strings.Cut(kv, "=")
			tags[k] = v
		}
		i := strings.Index(rest, " :")
		if i < 0 {
			continue
		}
		text := rest[i+2:]
		user := tags["display-name"]
		if user == "" {
			if j := strings.Index(rest, "!"); j > 1 {
				user = rest[1:j]
			}
		}
		b := tags["badges"]
		isMod := tags["mod"] == "1" || strings.Contains(b, "broadcaster/") || strings.Contains(b, "moderator/") || strings.Contains(b, "lead_moderator/")
		if strings.HasPrefix(text, "\x01ACTION ") && strings.HasSuffix(text, "\x01") {
			text = strings.TrimSuffix(strings.TrimPrefix(text, "\x01ACTION "), "\x01")
		}
		if c.DeckTwitch {
			key := ""
			if tags["id"] != "" {
				key = "tw:" + tags["id"]
			}
			h.a.feed.Add(FeedMsg{Platform: "twitch", User: user, Color: tags["color"], Parts: twitchParts(text, tags["emotes"]),
				Mod: isMod, Owner: strings.Contains(b, "broadcaster/")}, key)
		}
		if c.ListenTwitch {
			h.handle("twitch", user, isMod, text)
		}
	}
}

// ---------------- Kick (public Pusher websocket) ----------------

func (h *ChatHub) runKick(g int, c Config) error {
	id := strings.TrimSpace(c.KickChatroomID)
	chanID := strings.TrimSpace(c.KickChannelID)
	slug := strings.ToLower(strings.TrimSpace(c.KickChannel))
	slug = strings.TrimPrefix(strings.TrimPrefix(slug, "https://kick.com/"), "kick.com/")
	if id == "" || (chanID == "" && slug != "") {
		room, ch, err := kickLookup(slug)
		if err != nil && id == "" {
			return err
		}
		if err == nil {
			id, chanID = room, ch
			h.a.st.Update(func(c *Config) { c.KickChatroomID, c.KickChannelID = room, ch })
		}
	}
	// Ask Kick which chat server and key to use (again right away if Kick refused the last one)
	h.mu.Lock()
	refresh := h.kickRefused
	h.kickRefused = false
	h.mu.Unlock()
	pi := kickPusherFor(chanID, refresh)
	if pi.From == "fallback" {
		log.Println("[kick chat] couldn't ask Kick for its chat server, trying the old one")
	}
	ws, err := wsDial(pi.dialURL())
	if err != nil {
		return err
	}
	defer ws.Close()
	go func() {
		for h.alive(g) {
			time.Sleep(time.Second)
		}
		ws.Close()
	}()
	sub, _ := json.Marshal(map[string]any{"event": "pusher:subscribe", "data": map[string]string{"auth": "", "channel": "chatrooms." + id + ".v2"}})
	if err := ws.WriteText(sub); err != nil {
		return err
	}
	// Kick's chat server hangs up on connections that stay silent for about two minutes,
	// so say "still here" every minute even when nobody is chatting.
	done := make(chan struct{})
	defer close(done)
	go func() {
		t := time.NewTicker(60 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-done:
				return
			case <-t.C:
				if ws.WriteText([]byte(`{"event":"pusher:ping","data":{}}`)) != nil {
					return
				}
			}
		}
	}()
	var pusherErr string
	for {
		ws.conn.SetReadDeadline(time.Now().Add(150 * time.Second))
		msg, err := ws.ReadMessage()
		if err != nil {
			if pusherErr != "" {
				return errors.New(pusherErr)
			}
			return err
		}
		var env struct {
			Event string          `json:"event"`
			Data  json.RawMessage `json:"data"`
		}
		if json.Unmarshal(msg, &env) != nil {
			continue
		}
		// Pusher sends data as a JSON string holding JSON; unwrap it
		var data string
		if json.Unmarshal(env.Data, &data) != nil {
			data = string(env.Data)
		}
		switch env.Event {
		case "pusher:error":
			var pe struct {
				Code    int    `json:"code"`
				Message string `json:"message"`
			}
			json.Unmarshal([]byte(data), &pe)
			pusherErr = fmt.Sprintf("Kick chat server said: %s (%d)", strings.TrimSpace(pe.Message), pe.Code)
			if pe.Code >= 4000 && pe.Code < 4100 { // wrong key or app: ask Kick again next time
				h.mu.Lock()
				h.kickRefused = true
				h.mu.Unlock()
			}
			log.Println("[kick chat] " + pusherErr)
		case "pusher:ping":
			ws.WriteText([]byte(`{"event":"pusher:pong","data":{}}`))
		case "pusher_internal:subscription_succeeded":
			h.set("kick", "connected room "+id)
			log.Println("[kick chat] listening in chatroom " + id)
		case `App\Events\ChatMessageEvent`:
			var m struct {
				ID      string `json:"id"`
				Content string `json:"content"`
				Sender  struct {
					Username string `json:"username"`
					Identity struct {
						Color  string `json:"color"`
						Badges []struct {
							Type string `json:"type"`
						} `json:"badges"`
					} `json:"identity"`
				} `json:"sender"`
			}
			if json.Unmarshal([]byte(data), &m) != nil {
				continue
			}
			isMod, owner := false, false
			for _, b := range m.Sender.Identity.Badges {
				if b.Type == "moderator" || b.Type == "broadcaster" {
					isMod = true
				}
				if b.Type == "broadcaster" {
					owner = true
				}
			}
			if c.DeckKick {
				key := ""
				if m.ID != "" {
					key = "kk:" + m.ID
				}
				h.a.feed.Add(FeedMsg{Platform: "kick", User: m.Sender.Username, Color: m.Sender.Identity.Color, Parts: kickParts(m.Content), Mod: isMod, Owner: owner}, key)
			}
			if c.ListenKick {
				h.handle("kick", m.Sender.Username, isMod, m.Content)
			}
		}
	}
}

// ---------------- tiny websocket client (RFC 6455, client side) ----------------

type wsConn struct {
	conn net.Conn
	rd   *bufio.Reader
	wmu  sync.Mutex
}

func wsDial(raw string) (*wsConn, error) {
	u, err := url.Parse(raw)
	if err != nil {
		return nil, err
	}
	host := u.Host
	if !strings.Contains(host, ":") {
		if u.Scheme == "wss" {
			host += ":443"
		} else {
			host += ":80"
		}
	}
	d := &net.Dialer{Timeout: 10 * time.Second}
	var c net.Conn
	if u.Scheme == "wss" {
		c, err = tls.DialWithDialer(d, "tcp", host, &tls.Config{ServerName: u.Hostname()})
	} else {
		c, err = d.Dial("tcp", host)
	}
	if err != nil {
		return nil, err
	}
	kb := make([]byte, 16)
	rand.Read(kb)
	key := base64.StdEncoding.EncodeToString(kb)
	fmt.Fprintf(c, "GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\nOrigin: https://kick.com\r\nUser-Agent: HyperwaveStation\r\n\r\n", u.RequestURI(), u.Hostname(), key)
	rd := bufio.NewReader(c)
	c.SetReadDeadline(time.Now().Add(10 * time.Second))
	res, err := http.ReadResponse(rd, nil)
	if err != nil {
		c.Close()
		return nil, err
	}
	if res.StatusCode != 101 {
		c.Close()
		return nil, fmt.Errorf("websocket handshake: %s", res.Status)
	}
	return &wsConn{conn: c, rd: rd}, nil
}

func (w *wsConn) Close() error { return w.conn.Close() }

// wsClosed is the server closing the connection, with its close code and reason.
type wsClosed struct {
	Code   int
	Reason string
}

func (e *wsClosed) Error() string {
	switch {
	case e.Code == 0:
		return "websocket closed by server"
	case e.Reason != "":
		return fmt.Sprintf("closed by server (%d: %s)", e.Code, e.Reason)
	}
	return fmt.Sprintf("closed by server (%d)", e.Code)
}

func (w *wsConn) writeFrame(op byte, p []byte) error {
	w.wmu.Lock()
	defer w.wmu.Unlock()
	hdr := []byte{0x80 | op}
	n := len(p)
	switch {
	case n < 126:
		hdr = append(hdr, 0x80|byte(n))
	case n < 65536:
		hdr = append(hdr, 0x80|126, byte(n>>8), byte(n))
	default:
		hdr = append(hdr, 0x80|127)
		var b [8]byte
		binary.BigEndian.PutUint64(b[:], uint64(n))
		hdr = append(hdr, b[:]...)
	}
	mask := make([]byte, 4)
	rand.Read(mask)
	hdr = append(hdr, mask...)
	out := make([]byte, n)
	for i := range p {
		out[i] = p[i] ^ mask[i%4]
	}
	_, err := w.conn.Write(append(hdr, out...))
	return err
}

func (w *wsConn) WriteText(p []byte) error { return w.writeFrame(1, p) }

func (w *wsConn) ReadMessage() ([]byte, error) {
	var msg []byte
	for {
		var h [2]byte
		if _, err := io.ReadFull(w.rd, h[:]); err != nil {
			return nil, err
		}
		fin := h[0]&0x80 != 0
		op := h[0] & 0x0f
		n := uint64(h[1] & 0x7f)
		if n == 126 {
			var b [2]byte
			if _, err := io.ReadFull(w.rd, b[:]); err != nil {
				return nil, err
			}
			n = uint64(binary.BigEndian.Uint16(b[:]))
		} else if n == 127 {
			var b [8]byte
			if _, err := io.ReadFull(w.rd, b[:]); err != nil {
				return nil, err
			}
			n = binary.BigEndian.Uint64(b[:])
		}
		if n > 4<<20 {
			return nil, errors.New("websocket frame too large")
		}
		var mask []byte
		if h[1]&0x80 != 0 {
			mask = make([]byte, 4)
			io.ReadFull(w.rd, mask)
		}
		p := make([]byte, n)
		if _, err := io.ReadFull(w.rd, p); err != nil {
			return nil, err
		}
		if mask != nil {
			for i := range p {
				p[i] ^= mask[i%4]
			}
		}
		switch op {
		case 8:
			ce := &wsClosed{}
			if len(p) >= 2 {
				ce.Code = int(binary.BigEndian.Uint16(p[:2]))
				ce.Reason = strings.TrimSpace(string(p[2:]))
			}
			return nil, ce
		case 9:
			w.writeFrame(10, p)
			continue
		case 10:
			continue
		}
		msg = append(msg, p...)
		if fin {
			return msg, nil
		}
	}
}
