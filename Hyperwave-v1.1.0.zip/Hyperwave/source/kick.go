package main

import (
	"bytes"
	"crypto/rand"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

// KickAPI signs in to Kick's official API (each streamer makes their own free Kick app) so
// Hyperwave can read and change your Kick category.

var (
	kickID  = envOr("HWS_KICK_ID", "https://id.kick.com")
	kickAPI = envOr("HWS_KICK_API", "https://api.kick.com")
)

const kickScopes = "user:read channel:read channel:write"

type KickAPI struct {
	st   *Store
	http *http.Client

	mu       sync.Mutex
	access   string
	exp      time.Time
	verifier string
	state    string
	LastErr  string
}

func (k *KickAPI) client() *http.Client {
	if k.http == nil {
		k.http = &http.Client{Timeout: 12 * time.Second}
	}
	return k.http
}

func (k *KickAPI) Connected() bool {
	c := k.st.Get()
	return c.KickRefresh != "" && c.KickClientID != "" && c.KickSecret != ""
}

// RedirectURI is what goes in the Kick app's Redirect URL box. Kick's sign-in page turns
// 127.0.0.1 into localhost, so localhost is used from the start.
func (k *KickAPI) RedirectURI() string {
	return fmt.Sprintf("http://localhost:%d/kick/callback", k.st.Get().Port)
}

func (k *KickAPI) Status() map[string]any {
	c := k.st.Get()
	k.mu.Lock()
	defer k.mu.Unlock()
	return map[string]any{"connected": c.KickRefresh != "" && c.KickClientID != "" && c.KickSecret != "", "login": c.KickLogin,
		"hasApp": c.KickClientID != "" && c.KickSecret != "", "redirectUri": k.RedirectURI(), "lastError": k.LastErr}
}

func (k *KickAPI) LoginURL() (string, error) {
	c := k.st.Get()
	if c.KickClientID == "" || c.KickSecret == "" {
		return "", errors.New("paste your Kick app's Client ID and Client Secret first")
	}
	v := make([]byte, 32)
	rand.Read(v)
	s := make([]byte, 16)
	rand.Read(s)
	k.mu.Lock()
	k.verifier, k.state = b64(v), b64(s)
	sum := sha256.Sum256([]byte(k.verifier))
	state := k.state
	k.mu.Unlock()
	q := url.Values{"response_type": {"code"}, "client_id": {c.KickClientID}, "redirect_uri": {k.RedirectURI()}, "scope": {kickScopes},
		"code_challenge": {b64(sum[:])}, "code_challenge_method": {"S256"}, "state": {state}}
	return kickID + "/oauth/authorize?" + q.Encode(), nil
}

type kickTok struct {
	Access  string `json:"access_token"`
	Refresh string `json:"refresh_token"`
	Expires int    `json:"expires_in"`
	Error   string `json:"error"`
	Desc    string `json:"error_description"`
	Message string `json:"message"`
}

func (k *KickAPI) tokenCall(form url.Values) (*kickTok, error) {
	res, err := k.client().PostForm(kickID+"/oauth/token", form)
	if err != nil {
		return nil, fmt.Errorf("can't reach Kick: %v", err)
	}
	defer res.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	var t kickTok
	json.Unmarshal(b, &t)
	if res.StatusCode != 200 || t.Access == "" {
		msg := strings.TrimSpace(t.Desc + " " + t.Error + " " + t.Message)
		if msg == "" {
			msg = fmt.Sprintf("status %d", res.StatusCode)
		}
		return nil, fmt.Errorf("Kick said: %s", msg)
	}
	return &t, nil
}

func (k *KickAPI) Exchange(code, state string) error {
	k.mu.Lock()
	ok := state != "" && state == k.state
	verifier := k.verifier
	k.state = ""
	k.mu.Unlock()
	if !ok {
		return errors.New("this sign-in link expired. Click Sign in to Kick again")
	}
	c := k.st.Get()
	t, err := k.tokenCall(url.Values{"grant_type": {"authorization_code"}, "client_id": {c.KickClientID}, "client_secret": {c.KickSecret},
		"redirect_uri": {k.RedirectURI()}, "code_verifier": {verifier}, "code": {code}})
	if err != nil {
		return err
	}
	k.mu.Lock()
	k.access, k.exp, k.LastErr = t.Access, time.Now().Add(time.Duration(t.Expires-60)*time.Second), ""
	k.mu.Unlock()
	k.st.Update(func(c *Config) { c.KickRefresh = t.Refresh })
	k.loadUser()
	return nil
}

func (k *KickAPI) Logout() {
	k.mu.Lock()
	k.access = ""
	k.mu.Unlock()
	k.st.Update(func(c *Config) { c.KickRefresh, c.KickLogin = "", "" })
}

func (k *KickAPI) token() (string, error) {
	k.mu.Lock()
	defer k.mu.Unlock()
	if k.access != "" && time.Now().Before(k.exp) {
		return k.access, nil
	}
	c := k.st.Get()
	if c.KickRefresh == "" || c.KickClientID == "" || c.KickSecret == "" {
		return "", errors.New("Kick isn't signed in. Sign in under OBS & Deck → Kick on the dashboard")
	}
	t, err := k.tokenCall(url.Values{"grant_type": {"refresh_token"}, "client_id": {c.KickClientID}, "client_secret": {c.KickSecret}, "refresh_token": {c.KickRefresh}})
	if err != nil {
		k.LastErr = "Kick ended this sign-in (" + err.Error() + "). Sign in again."
		if strings.Contains(strings.ToLower(err.Error()), "invalid") {
			k.st.Update(func(c *Config) { c.KickRefresh = "" })
		}
		return "", errors.New(k.LastErr)
	}
	k.access, k.exp, k.LastErr = t.Access, time.Now().Add(time.Duration(t.Expires-60)*time.Second), ""
	if t.Refresh != "" && t.Refresh != c.KickRefresh {
		k.st.Update(func(c *Config) { c.KickRefresh = t.Refresh })
	}
	return k.access, nil
}

func (k *KickAPI) do(method, path string, body any) (int, []byte, error) {
	for attempt := 0; attempt < 2; attempt++ {
		tok, err := k.token()
		if err != nil {
			return 0, nil, err
		}
		var rdr io.Reader
		if body != nil {
			b, _ := json.Marshal(body)
			rdr = bytes.NewReader(b)
		}
		req, _ := http.NewRequest(method, kickAPI+path, rdr)
		req.Header.Set("Authorization", "Bearer "+tok)
		req.Header.Set("Accept", "application/json")
		if body != nil {
			req.Header.Set("Content-Type", "application/json")
		}
		res, err := k.client().Do(req)
		if err != nil {
			return 0, nil, fmt.Errorf("can't reach Kick: %v", err)
		}
		b, _ := io.ReadAll(io.LimitReader(res.Body, 4<<20))
		res.Body.Close()
		if res.StatusCode == 401 && attempt == 0 {
			k.mu.Lock()
			k.access = ""
			k.mu.Unlock()
			continue
		}
		return res.StatusCode, b, nil
	}
	return 401, nil, errors.New("Kick rejected the sign-in. Sign in again on the dashboard")
}

func kickMsg(b []byte) string {
	var e struct {
		Message string `json:"message"`
		Error   string `json:"error"`
	}
	json.Unmarshal(b, &e)
	if e.Message != "" {
		return e.Message
	}
	return e.Error
}

func (k *KickAPI) loadUser() {
	code, b, err := k.do("GET", "/public/v1/users", nil)
	if err != nil || code != 200 {
		return
	}
	var r struct {
		Data []struct {
			ID   int64  `json:"user_id"`
			Name string `json:"name"`
		} `json:"data"`
	}
	json.Unmarshal(b, &r)
	if len(r.Data) > 0 {
		k.st.Update(func(c *Config) { c.KickLogin = r.Data[0].Name })
		log.Println("[kick] signed in as " + r.Data[0].Name)
	}
}

type kickCat struct {
	ID    int64  `json:"id"`
	Name  string `json:"name"`
	Thumb string `json:"thumbnail"`
}

func (c kickCat) ref() CatRef {
	return CatRef{ID: strconv.FormatInt(c.ID, 10), Name: c.Name, Art: c.Thumb}
}

// SearchCategories finds Kick categories by name.
func (k *KickAPI) SearchCategories(q string) ([]CatRef, error) {
	code, b, err := k.do("GET", "/public/v1/categories?q="+url.QueryEscape(q), nil)
	if err == nil && (code == 404 || code == 410) {
		// the old search went away: ask for the exact name instead
		code, b, err = k.do("GET", "/public/v2/categories?limit=12&name="+url.QueryEscape(q), nil)
	}
	if err != nil {
		return nil, err
	}
	if code != 200 {
		return nil, fmt.Errorf("Kick search said %d %s", code, kickMsg(b))
	}
	var r struct {
		Data []kickCat `json:"data"`
	}
	json.Unmarshal(b, &r)
	out := []CatRef{}
	for _, c := range r.Data {
		if c.ID > 0 && len(out) < 12 {
			out = append(out, c.ref())
		}
	}
	return out, nil
}

func (k *KickAPI) CurrentCategory() (*CatRef, error) {
	code, b, err := k.do("GET", "/public/v1/channels", nil)
	if err != nil {
		return nil, err
	}
	var r struct {
		Data []struct {
			Category *kickCat `json:"category"`
		} `json:"data"`
	}
	json.Unmarshal(b, &r)
	if code != 200 || len(r.Data) == 0 {
		return nil, fmt.Errorf("Kick said %d %s", code, kickMsg(b))
	}
	if r.Data[0].Category == nil {
		return &CatRef{}, nil
	}
	c := r.Data[0].Category.ref()
	return &c, nil
}

func (k *KickAPI) SetCategory(id string) error {
	n, err := strconv.ParseInt(id, 10, 64)
	if err != nil || n <= 0 {
		return errors.New("that isn't a Kick category")
	}
	code, b, err := k.do("PATCH", "/public/v1/channels", map[string]any{"category_id": n})
	if err != nil {
		return err
	}
	if code == 401 || code == 403 {
		return errors.New("Kick didn't allow the change. Sign in to Kick again on the dashboard")
	}
	if code != 204 && code != 200 {
		return fmt.Errorf("Kick said %d %s", code, kickMsg(b))
	}
	return nil
}

func (a *App) kickRoutes(m *http.ServeMux, g, page func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/kick/login", page(func(w http.ResponseWriter, r *http.Request) {
		u, err := a.kick.LoginURL()
		if err != nil {
			http.Redirect(w, r, "/?kickerr="+urlq(err.Error())+"#deck", 302)
			return
		}
		http.Redirect(w, r, u, 302)
	}))
	m.HandleFunc("/kick/callback", page(func(w http.ResponseWriter, r *http.Request) {
		back := fmt.Sprintf("http://127.0.0.1:%d/", a.st.Get().Port)
		if e := r.FormValue("error"); e != "" {
			http.Redirect(w, r, back+"?kickerr="+urlq(e)+"#deck", 302)
			return
		}
		if err := a.kick.Exchange(r.FormValue("code"), r.FormValue("state")); err != nil {
			log.Println("[kick] sign-in:", err)
			http.Redirect(w, r, back+"?kickerr="+urlq(err.Error())+"#deck", 302)
			return
		}
		a.cat.forget()
		http.Redirect(w, r, back+"?ok=kick#deck", 302)
	}))
	m.HandleFunc("/api/kick/status", g(func(w http.ResponseWriter, r *http.Request) { jsonOut(w, 200, a.kick.Status()) }))
	m.HandleFunc("/api/kick/logout", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		a.kick.Logout()
		a.cat.forget()
		jsonOut(w, 200, a.kick.Status())
	}))
}
