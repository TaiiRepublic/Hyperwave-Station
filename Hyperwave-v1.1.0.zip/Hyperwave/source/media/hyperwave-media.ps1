# Hyperwave Station - Windows media helper
# Reads what's playing from Windows' own media controls (the panel that pops up when you press a
# media key) and presses play / pause / next / previous for Hyperwave Station. Station starts and
# stops this by itself; it only talks to Station through its own input and output, never the network.
# One command per line in, one JSON line out:
#   state <app>          what's playing
#   art <app>            the cover picture
#   ctl <app> <cmd> <v>  play | pause | toggle | next | prev | shuffle (v=1/0) | repeat (v=0 none,1 track,2 list)
# <app> is base64 of part of the player's app id ("-" = pick automatically).

$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = $utf8
$stdin = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $utf8)

function Send($o) {
  $j = ConvertTo-Json -InputObject $o -Compress -Depth 5
  [Console]::Out.WriteLine($j)
  [Console]::Out.Flush()
}

try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $script:AsTaskOp = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  } | Select-Object -First 1
  function Await($op, [Type]$type) {
    $task = $script:AsTaskOp.MakeGenericMethod($type).Invoke($null, @($op))
    if (-not $task.Wait(5000)) { throw 'Windows took too long to answer' }
    return $task.Result
  }
  $script:Mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
} catch {
  Send @{ ok = $false; fatal = $true; error = ("Windows media controls aren't available on this PC (" + $_.Exception.Message + "). They need Windows 10 (October 2018 update) or newer.") }
  exit 1
}

$PropsType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]
$StreamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType]

function Decode($s) {
  if (-not $s -or $s -eq '-') { return '' }
  return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($s))
}

function IsPlaying($s) {
  try { return ([int]$s.GetPlaybackInfo().PlaybackStatus -eq 4) } catch { return $false }
}

function Pick($pref) {
  $all = @($script:Mgr.GetSessions())
  if ($pref) {
    foreach ($s in $all) {
      if ($s.SourceAppUserModelId.IndexOf($pref, [StringComparison]::OrdinalIgnoreCase) -ge 0) { return $s }
    }
    return $null
  }
  $cur = $script:Mgr.GetCurrentSession()
  if ($cur -and (IsPlaying $cur)) { return $cur }
  foreach ($s in $all) { if (IsPlaying $s) { return $s } }
  if ($cur) { return $cur }
  if ($all.Count -gt 0) { return $all[0] }
  return $null
}

function State($pref) {
  $list = New-Object System.Collections.ArrayList
  foreach ($x in @($script:Mgr.GetSessions())) {
    $null = $list.Add(@{ app = [string]$x.SourceAppUserModelId; playing = (IsPlaying $x) })
  }
  $out = @{ ok = $true; sessions = $list.ToArray() }
  $s = Pick $pref
  if ($s) {
    $p = Await ($s.TryGetMediaPropertiesAsync()) $PropsType
    $info = $s.GetPlaybackInfo()
    $c = $info.Controls
    $tl = $s.GetTimelineProperties()
    $repeat = -1
    if ($null -ne $info.AutoRepeatMode) { $repeat = [int]$info.AutoRepeatMode }
    $shuffle = $false
    if ($null -ne $info.IsShuffleActive) { $shuffle = [bool]$info.IsShuffleActive }
    $updated = 0
    try { $updated = $tl.LastUpdatedTime.ToUnixTimeMilliseconds() } catch { }
    $out.cur = @{
      app         = [string]$s.SourceAppUserModelId
      title       = [string]$p.Title
      artist      = [string]$p.Artist
      album       = [string]$p.AlbumTitle
      albumArtist = [string]$p.AlbumArtist
      status      = [int]$info.PlaybackStatus
      pos         = [long]$tl.Position.TotalMilliseconds
      start       = [long]$tl.StartTime.TotalMilliseconds
      end         = [long]$tl.EndTime.TotalMilliseconds
      updated     = [long]$updated
      canPlay     = [bool]$c.IsPlayEnabled
      canPause    = [bool]$c.IsPauseEnabled
      canNext     = [bool]$c.IsNextEnabled
      canPrev     = [bool]$c.IsPreviousEnabled
      canShuffle  = [bool]$c.IsShuffleEnabled
      canRepeat   = [bool]$c.IsRepeatEnabled
      shuffle     = $shuffle
      repeat      = $repeat
      hasArt      = ($null -ne $p.Thumbnail)
    }
  }
  return $out
}

function IsImage($b) {
  if ($null -eq $b -or $b.Length -lt 12) { return $false }
  if ($b[0] -eq 0xFF -and $b[1] -eq 0xD8) { return $true }                                   # JPEG
  if ($b[0] -eq 0x89 -and $b[1] -eq 0x50 -and $b[2] -eq 0x4E -and $b[3] -eq 0x47) { return $true } # PNG
  if ($b[0] -eq 0x47 -and $b[1] -eq 0x49 -and $b[2] -eq 0x46) { return $true }                # GIF
  if ($b[0] -eq 0x42 -and $b[1] -eq 0x4D) { return $true }                                   # BMP
  if ($b[0] -eq 0x52 -and $b[1] -eq 0x49 -and $b[8] -eq 0x57 -and $b[9] -eq 0x45) { return $true } # WEBP
  return $false
}

function Art($pref) {
  $s = Pick $pref
  if (-not $s) { return @{ ok = $false; error = 'nothing playing' } }
  $p = Await ($s.TryGetMediaPropertiesAsync()) $PropsType
  if ($null -eq $p.Thumbnail) { return @{ ok = $true; art = '' } }
  $type = ''
  $why = @()
  # Three ways to read the picture. Which one works depends on the Windows build, so try each
  # and keep the first that really is a picture.
  for ($way = 1; $way -le 3; $way++) {
    $bytes = $null
    try {
      $st = Await ($p.Thumbnail.OpenReadAsync()) $StreamType
      if (-not $type) { $type = [string]$st.ContentType }
      if ($way -eq 1) {
        $ns = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st)
        $ms = New-Object System.IO.MemoryStream
        $ns.CopyTo($ms)
        $bytes = $ms.ToArray()
      } elseif ($way -eq 2) {
        $ns = [System.IO.WindowsRuntimeStreamExtensions]::AsStream([Windows.Storage.Streams.IRandomAccessStream]$st)
        $ms = New-Object System.IO.MemoryStream
        $ns.CopyTo($ms)
        $bytes = $ms.ToArray()
      } else {
        $size = [uint32]$st.Size
        $reader = [Windows.Storage.Streams.DataReader]::new($st.GetInputStreamAt(0))
        $null = Await ($reader.LoadAsync($size)) ([uint32])
        $buf = $reader.ReadBuffer($size)
        $bytes = [System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferExtensions]::ToArray($buf)
      }
    } catch { $why += ('way ' + $way + ': ' + $_.Exception.Message) ; continue }
    if (IsImage $bytes) { return @{ ok = $true; art = [Convert]::ToBase64String($bytes); type = $type; way = $way } }
    $n = 0; if ($null -ne $bytes) { $n = $bytes.Length }
    $why += ('way ' + $way + ': got ' + $n + ' bytes that are not a picture')
  }
  return @{ ok = $false; error = ('the player''s cover picture could not be read (' + ($why -join '; ') + ')') }
}

function Control($cmd, $pref, $val) {
  $s = Pick $pref
  if (-not $s) { return @{ ok = $false; error = 'nothing playing' } }
  $B = [bool]
  $r = $false
  switch ($cmd) {
    'play'    { $r = Await ($s.TryPlayAsync()) $B }
    'pause'   { $r = Await ($s.TryPauseAsync()) $B }
    'toggle'  { $r = Await ($s.TryTogglePlayPauseAsync()) $B }
    'next'    { $r = Await ($s.TrySkipNextAsync()) $B }
    'prev'    { $r = Await ($s.TrySkipPreviousAsync()) $B }
    'shuffle' { $r = Await ($s.TryChangeShuffleActiveAsync(($val -eq '1'))) $B }
    'repeat'  {
      $null = [Windows.Media.MediaPlaybackAutoRepeatMode, Windows.Media, ContentType = WindowsRuntime]
      $mode = [Windows.Media.MediaPlaybackAutoRepeatMode]([int]$val)
      $r = Await ($s.TryChangeAutoRepeatModeAsync($mode)) $B
    }
    default   { return @{ ok = $false; error = 'unknown command' } }
  }
  return @{ ok = [bool]$r }
}

Send @{ ok = $true; ready = $true }
while ($true) {
  $line = $stdin.ReadLine()
  if ($null -eq $line) { break }
  $parts = $line.Trim().Split(' ')
  try {
    $pref = ''
    if ($parts.Count -gt 1) { $pref = Decode $parts[1] }
    switch ($parts[0]) {
      'state' { Send (State $pref) }
      'art'   { Send (Art $pref) }
      'ctl'   {
        $val = ''
        if ($parts.Count -gt 3) { $val = $parts[3] }
        Send (Control $parts[2] $pref $val)
      }
      'ping'  { Send @{ ok = $true } }
      default { Send @{ ok = $false; error = 'unknown command' } }
    }
  } catch {
    Send @{ ok = $false; error = [string]$_.Exception.Message }
  }
}
