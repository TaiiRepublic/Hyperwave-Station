package main

import (
	"net/http"
	"strings"
	"sync"
	"time"
)

// Overlays tag their /api/state check-ins (?from=chat or ?from=music), so the
// Connections page can say whether each overlay is live, and whether it's in OBS.
type overlaySeen struct {
	mu sync.Mutex
	at map[string]time.Time
	in map[string]bool // true when the last check-in came from an OBS browser source
}

var seenOverlays = &overlaySeen{at: map[string]time.Time{}, in: map[string]bool{}}

func (o *overlaySeen) mark(r *http.Request) {
	from := r.URL.Query().Get("from")
	if from != "chat" && from != "music" {
		return
	}
	o.mu.Lock()
	o.at[from] = time.Now()
	o.in[from] = strings.Contains(r.UserAgent(), "OBS/")
	o.mu.Unlock()
}

func (o *overlaySeen) status() map[string]any {
	o.mu.Lock()
	defer o.mu.Unlock()
	out := map[string]any{}
	for _, k := range []string{"chat", "music"} {
		t, ok := o.at[k]
		if !ok {
			out[k] = map[string]any{"seen": false}
			continue
		}
		out[k] = map[string]any{"seen": true, "ago": int(time.Since(t).Seconds()), "obs": o.in[k]}
	}
	return out
}

// phones: the last time a phone or tablet used the deck over Wi-Fi.
var phoneSeen struct {
	mu sync.Mutex
	at time.Time
	n  map[string]time.Time
}

func markPhone(ip string) {
	phoneSeen.mu.Lock()
	defer phoneSeen.mu.Unlock()
	if phoneSeen.n == nil {
		phoneSeen.n = map[string]time.Time{}
	}
	now := time.Now()
	phoneSeen.at = now
	phoneSeen.n[ip] = now
	for k, t := range phoneSeen.n { // keep only devices seen in the last minute
		if now.Sub(t) > time.Minute {
			delete(phoneSeen.n, k)
		}
	}
}

func (a *App) lanSeen() map[string]any {
	phoneSeen.mu.Lock()
	defer phoneSeen.mu.Unlock()
	if phoneSeen.at.IsZero() {
		return map[string]any{"seen": false}
	}
	live := 0
	for _, t := range phoneSeen.n {
		if time.Since(t) < time.Minute {
			live++
		}
	}
	return map[string]any{"seen": true, "ago": int(time.Since(phoneSeen.at).Seconds()), "devices": live}
}
