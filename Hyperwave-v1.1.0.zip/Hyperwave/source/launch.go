package main

import (
	"bytes"
	"crypto/rand"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
)

// ---------------- programs on deck buttons ----------------
//
// Drop a program, a desktop shortcut or a game shortcut (Steam, Epic…) from Windows onto the deck
// and it becomes a button that opens it. Programs can only be added from the streaming PC itself:
// a phone can press a launcher button, but can't create one or choose what it runs.

type Launcher struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	Path string `json:"path,omitempty"` // a program (or file) to open
	Args string `json:"args,omitempty"`
	Dir  string `json:"dir,omitempty"`
	URL  string `json:"url,omitempty"`  // a game link such as steam://rungameid/1234
	Icon string `json:"icon,omitempty"` // the program's icon, saved as a deck picture
}

var launcherIDRe = regexp.MustCompile(`^[0-9a-f]{10}$`)

func (a *App) launcher(id string) (Launcher, bool) {
	for _, l := range a.st.Get().Launchers {
		if l.ID == id {
			return l, true
		}
	}
	return Launcher{}, false
}

// Launch opens a launcher's program or game.
func (a *App) Launch(id string) (string, error) {
	l, ok := a.launcher(id)
	if !ok {
		return "", errors.New("that program isn't set up any more. Drag it onto the deck again")
	}
	if !isWindows() && devEnv("HWS_FAKE_LAUNCH") == "" {
		return "", errors.New("opening programs only works on Windows")
	}
	if l.URL != "" {
		if err := openURL(l.URL); err != nil {
			return "", fmt.Errorf("couldn't open %s: %v", l.Name, err)
		}
		return "🚀 Opening " + l.Name, nil
	}
	if _, err := os.Stat(l.Path); err != nil {
		return "", fmt.Errorf("%s isn't at %s any more. Drag it onto the deck again", l.Name, l.Path)
	}
	if err := startProgram(l.Path, l.Args, l.Dir); err != nil {
		return "", fmt.Errorf("couldn't open %s: %v", l.Name, err)
	}
	return "🚀 Opening " + l.Name, nil
}

// ---------- reading Windows shortcuts ----------

// parseURLShortcut reads a .url file (game and web shortcuts): [InternetShortcut] URL=...
func parseURLShortcut(b []byte) (url, icon string) {
	for _, ln := range strings.Split(strings.ReplaceAll(string(b), "\r", ""), "\n") {
		k, v, ok := strings.Cut(ln, "=")
		if !ok {
			continue
		}
		switch strings.ToLower(strings.TrimSpace(k)) {
		case "url":
			url = strings.TrimSpace(v)
		case "iconfile":
			icon = strings.TrimSpace(v)
		}
	}
	return
}

// parseLnk reads a Windows .lnk shortcut (MS-SHLLINK) and returns where it points.
func parseLnk(b []byte) (target, args, dir string, err error) {
	if len(b) < 0x4C || binary.LittleEndian.Uint32(b[0:4]) != 0x4C {
		return "", "", "", errors.New("not a Windows shortcut")
	}
	flags := binary.LittleEndian.Uint32(b[0x14:0x18])
	const (
		hasIDList   = 1 << 0
		hasLinkInfo = 1 << 1
		hasName     = 1 << 2
		hasRelPath  = 1 << 3
		hasWorkDir  = 1 << 4
		hasArgs     = 1 << 5
		hasIcon     = 1 << 6
		isUnicode   = 1 << 7
	)
	pos := 0x4C
	need := func(n int) bool { return pos+n <= len(b) }
	idPath := ""
	if flags&hasIDList != 0 {
		if !need(2) {
			return "", "", "", errors.New("broken shortcut")
		}
		n := int(binary.LittleEndian.Uint16(b[pos:]))
		if pos+2+n <= len(b) {
			idPath = idListPath(b[pos+2 : pos+2+n])
		}
		pos += 2 + n
	}
	cstr := func(off int) string {
		if off <= 0 || off >= len(b) {
			return ""
		}
		end := bytes.IndexByte(b[off:], 0)
		if end < 0 {
			return ""
		}
		return string(b[off : off+end])
	}
	wstr := func(off int) string {
		var u []uint16
		for i := off; i+1 < len(b); i += 2 {
			c := binary.LittleEndian.Uint16(b[i:])
			if c == 0 {
				break
			}
			u = append(u, c)
		}
		return string(utf16.Decode(u))
	}
	if flags&hasLinkInfo != 0 {
		if !need(0x1C) {
			return "", "", "", errors.New("broken shortcut")
		}
		li := pos
		size := int(binary.LittleEndian.Uint32(b[li:]))
		hdr := int(binary.LittleEndian.Uint32(b[li+4:]))
		liFlags := binary.LittleEndian.Uint32(b[li+8:])
		baseOff := int(binary.LittleEndian.Uint32(b[li+16:]))
		suffixOff := int(binary.LittleEndian.Uint32(b[li+24:]))
		if liFlags&1 != 0 {
			base, suffix := "", ""
			if hdr >= 0x24 && li+0x24 <= len(b) {
				ub := int(binary.LittleEndian.Uint32(b[li+0x1C:]))
				us := int(binary.LittleEndian.Uint32(b[li+0x20:]))
				if ub > 0 {
					base = wstr(li + ub)
				}
				if us > 0 {
					suffix = wstr(li + us)
				}
			}
			if base == "" {
				base = cstr(li + baseOff)
			}
			if suffix == "" {
				suffix = cstr(li + suffixOff)
			}
			target = base + suffix
		}
		pos += size
	}
	readStr := func() string {
		if !need(2) {
			return ""
		}
		n := int(binary.LittleEndian.Uint16(b[pos:]))
		pos += 2
		if flags&isUnicode != 0 {
			if !need(n * 2) {
				return ""
			}
			u := make([]uint16, n)
			for i := range u {
				u[i] = binary.LittleEndian.Uint16(b[pos+i*2:])
			}
			pos += n * 2
			return string(utf16.Decode(u))
		}
		if !need(n) {
			return ""
		}
		s := string(b[pos : pos+n])
		pos += n
		return s
	}
	if flags&hasName != 0 {
		readStr()
	}
	if flags&hasRelPath != 0 {
		readStr()
	}
	if flags&hasWorkDir != 0 {
		dir = readStr()
	}
	if flags&hasArgs != 0 {
		args = readStr()
	}
	if flags&hasIcon != 0 {
		readStr()
	}
	// Extra data: the environment-variable block holds the target for shortcuts like
	// %windir%\notepad.exe that have no LinkInfo.
	for need(8) {
		bs := int(binary.LittleEndian.Uint32(b[pos:]))
		if bs < 4 || pos+bs > len(b) {
			break
		}
		sig := binary.LittleEndian.Uint32(b[pos+4:])
		if sig == 0xA0000001 && bs >= 8+260+520 && target == "" {
			if t := wstr(pos + 8 + 260); t != "" {
				target = t
			} else {
				target = cstr(pos + 8)
			}
		}
		pos += bs
	}
	if target == "" {
		target = idPath
	}
	target = expandWinEnv(strings.TrimSpace(target))
	dir = expandWinEnv(strings.TrimSpace(dir))
	if target == "" {
		return "", "", "", errors.New("this shortcut points to something Hyperwave can't open (like a Microsoft Store app). Drag the program itself, or its desktop shortcut")
	}
	return target, strings.TrimSpace(args), dir, nil
}

// idListPath rebuilds a path like C:\Program Files\OBS Studio\obs64.exe from a shortcut's
// shell item list (used when the shortcut has no plain path in it).
func idListPath(ids []byte) string {
	var parts []string
	for i := 0; i+2 <= len(ids); {
		sz := int(binary.LittleEndian.Uint16(ids[i:]))
		if sz < 3 || i+sz > len(ids) {
			break
		}
		it := ids[i : i+sz]
		i += sz
		switch typ := it[2]; {
		case typ&0x70 == 0x20: // a drive, e.g. "C:\"
			if end := bytes.IndexByte(it[3:], 0); end > 0 {
				parts = []string{strings.TrimRight(string(it[3:3+end]), "\\")}
			}
		case typ&0x70 == 0x30: // a folder or file
			if len(parts) == 0 || len(it) < 15 {
				return ""
			}
			short := ""
			if end := bytes.IndexByte(it[14:], 0); end >= 0 {
				short = string(it[14 : 14+end])
			}
			name := longItemName(it)
			if name == "" {
				name = short
			}
			parts = append(parts, name)
		}
	}
	if len(parts) < 2 {
		return ""
	}
	return strings.Join(parts, "\\")
}

// longItemName finds the full (non 8.3) name stored in a shell item's 0xBEEF0004 block.
func longItemName(it []byte) string {
	k := bytes.Index(it, []byte{0x04, 0x00, 0xEF, 0xBE})
	if k < 4 {
		return ""
	}
	ext := it[k-4:]
	best := ""
	for off := 0x12; off+2 <= len(ext); off += 2 {
		var u []uint16
		ok := true
		for j := off; j+1 < len(ext); j += 2 {
			c := binary.LittleEndian.Uint16(ext[j:])
			if c == 0 {
				break
			}
			if c < 0x20 {
				ok = false
				break
			}
			u = append(u, c)
		}
		if ok && len(u) > len([]rune(best)) {
			best = string(utf16.Decode(u))
		}
	}
	return best
}

var winEnvRe = regexp.MustCompile(`%([A-Za-z0-9_()]+)%`)

func expandWinEnv(s string) string {
	return winEnvRe.ReplaceAllStringFunc(s, func(m string) string {
		k := m[1 : len(m)-1]
		if v := os.Getenv(k); v != "" {
			return v
		}
		for _, e := range os.Environ() { // Windows variable names ignore case
			if kk, v, ok := strings.Cut(e, "="); ok && strings.EqualFold(kk, k) {
				return v
			}
		}
		return m
	})
}

// findProgram looks for a dropped .exe by name (and size) in the usual install folders, because
// browsers don't say where a dropped file came from.
func findProgram(name string, size int64) string {
	name = filepath.Base(name)
	var roots []string
	for _, v := range []string{"ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "LOCALAPPDATA", "APPDATA"} {
		if p := os.Getenv(v); p != "" {
			roots = append(roots, p)
		}
	}
	if p := devEnv("HWS_PROGRAMS"); p != "" {
		roots = append(roots, p)
	}
	if home, err := os.UserHomeDir(); err == nil {
		roots = append(roots, filepath.Join(home, "Desktop"), filepath.Join(home, "Downloads"), filepath.Join(home, "OneDrive", "Desktop"))
	}
	for _, d := range []string{`C:\Games`, `D:\Games`, `C:\Program Files (x86)\Steam\steamapps\common`, `D:\SteamLibrary\steamapps\common`} {
		roots = append(roots, d)
	}
	deadline := time.Now().Add(10 * time.Second)
	stop := errors.New("stop")
	seen := map[string]bool{}
	for _, root := range roots {
		if seen[strings.ToLower(root)] {
			continue
		}
		seen[strings.ToLower(root)] = true
		found := ""
		base := strings.Count(filepath.Clean(root), string(filepath.Separator))
		filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
			if time.Now().After(deadline) {
				return stop
			}
			if err != nil {
				if d != nil && d.IsDir() {
					return fs.SkipDir
				}
				return nil
			}
			if d.IsDir() {
				if strings.Count(p, string(filepath.Separator))-base > 5 || strings.EqualFold(d.Name(), "WindowsApps") {
					return fs.SkipDir
				}
				return nil
			}
			if strings.EqualFold(d.Name(), name) {
				if info, err := d.Info(); err == nil && (size <= 0 || info.Size() == size) {
					found = p
					return stop
				}
			}
			return nil
		})
		if found != "" {
			return found
		}
		if time.Now().After(deadline) {
			break
		}
	}
	return ""
}

func isLoopback(r *http.Request) bool {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback() && r.Header.Get("X-Forwarded-For") == ""
}

func newLauncherID() string {
	b := make([]byte, 5)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// AddLauncher turns a dropped program, shortcut or typed path into a launcher.
func (a *App) AddLauncher(kind, name string, size int64, body []byte, typed string) (Launcher, error) {
	l := Launcher{ID: newLauncherID()}
	base := strings.TrimSuffix(filepath.Base(strings.ReplaceAll(name, "\\", "/")), filepath.Ext(name))
	switch kind {
	case "url":
		u, icon := parseURLShortcut(body)
		low := strings.ToLower(u)
		if u == "" || strings.HasPrefix(low, "file:") || strings.HasPrefix(low, "javascript:") {
			return l, errors.New("that shortcut doesn't have a link Hyperwave can open")
		}
		l.URL, l.Name = u, base
		if icon != "" {
			l.Path = "" // icon only
			l.Icon = a.saveProgramIcon(expandWinEnv(icon))
		}
	case "lnk":
		t, args, dir, err := parseLnk(body)
		if err != nil {
			return l, err
		}
		l.Path, l.Args, l.Dir, l.Name = t, args, dir, base
	case "exe":
		p := findProgram(name, size)
		if p == "" {
			return l, fmt.Errorf("couldn't find %s on this PC. Drag its desktop shortcut instead, or type its full path", filepath.Base(name))
		}
		l.Path, l.Name = p, base
	case "path":
		p := strings.Trim(strings.TrimSpace(typed), `"`)
		if strings.Contains(p, "://") {
			l.URL, l.Name = p, p
			break
		}
		p = expandWinEnv(p)
		if !filepath.IsAbs(p) {
			return l, errors.New("type the program's full path, like C:\\Program Files\\OBS Studio\\bin\\64bit\\obs64.exe")
		}
		l.Path = p
		l.Name = strings.TrimSuffix(filepath.Base(p), filepath.Ext(p))
		if strings.HasSuffix(strings.ToLower(p), ".lnk") {
			if b, err := os.ReadFile(p); err == nil {
				if t, args, dir, err := parseLnk(b); err == nil {
					l.Path, l.Args, l.Dir = t, args, dir
				}
			}
		}
	default:
		return l, errors.New("drop a program, a shortcut or a game shortcut")
	}
	if l.URL == "" {
		if _, err := os.Stat(l.Path); err != nil {
			return l, fmt.Errorf("Hyperwave can't find %s", l.Path)
		}
		if l.Dir == "" {
			l.Dir = filepath.Dir(l.Path)
		}
		l.Icon = a.saveProgramIcon(l.Path)
	}
	if strings.TrimSpace(l.Name) == "" {
		l.Name = "Program"
	}
	a.st.Update(func(c *Config) {
		c.Launchers = append(c.Launchers, l)
		if len(c.Launchers) > 100 {
			c.Launchers = c.Launchers[len(c.Launchers)-100:]
		}
	})
	log.Printf("[deck] added program %q (%s%s)", l.Name, l.Path, l.URL)
	return l, nil
}

// saveProgramIcon saves a program's icon as a deck picture ("" if it can't).
func (a *App) saveProgramIcon(path string) string {
	png, err := programIcon(path)
	if err != nil || len(png) == 0 {
		return ""
	}
	it, err := a.media.Add("image", strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))+" icon", bytes.NewReader(png))
	if err != nil {
		return ""
	}
	return it.File
}

func (a *App) launcherRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/deck/launchers", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			if !isLoopback(r) {
				jsonOut(w, 200, map[string]any{"ok": false, "error": "programs can only be added on the streaming PC itself"})
				return
			}
			qs := r.URL.Query()
			size, _ := strconv.ParseInt(qs.Get("size"), 10, 64)
			body, _ := io.ReadAll(io.LimitReader(r.Body, 256<<10))
			l, err := a.AddLauncher(qs.Get("kind"), qs.Get("name"), size, body, qs.Get("path"))
			if err != nil {
				jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
				return
			}
			jsonOut(w, 200, map[string]any{"ok": true, "launcher": l})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "launchers": a.st.Get().Launchers, "canAdd": isLoopback(r)})
	}))
}
