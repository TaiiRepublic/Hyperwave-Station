package main

import (
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode"
)

// ---------------- music sources ----------------
//
// Station can follow different music players. Each one is a Source. Spotify (Premium, Web API) can
// do everything; the others do as much as their player allows, and Caps says which controls work so
// the dashboard, deck, DJ page and chat commands only offer what really works.

type Caps struct {
	Play      bool `json:"play"`
	Pause     bool `json:"pause"`
	Next      bool `json:"next"`
	Prev      bool `json:"prev"`
	Volume    bool `json:"volume"`
	Shuffle   bool `json:"shuffle"`
	Repeat    bool `json:"repeat"`
	Queue     bool `json:"queue"`     // requests go straight into the player's queue
	UpNext    bool `json:"upNext"`    // can read what plays next
	Search    bool `json:"search"`    // search the player's own catalog
	Playlists bool `json:"playlists"` // start one of your playlists
	Devices   bool `json:"devices"`   // pick which device plays
	Progress  bool `json:"progress"`  // knows the song position
}

// Snapshot is one look at the player.
type Snapshot struct {
	Playing  bool
	Track    *TrackView
	Progress int
	Device   string
	Volume   int // -1 when the player doesn't share it
	Shuffle  bool
	Repeat   string
	Context  string
	Caps     *Caps // set when what works depends on the moment (Windows media)
}

type Source interface {
	ID() string
	Name() string
	Ready() bool // set up enough to try (logged in, configured, or nothing needed)
	Caps() Caps
	Poll() (*Snapshot, error) // nil snapshot: nothing playing
	Control(cmd, arg string) error
	Find(input string) (*TrackView, error)
	Search(q string, limit int) ([]TrackView, error)
	Enqueue(t *TrackView) error
	PlayNow(t *TrackView) error
	UpNext() ([]TrackView, error)
}

var (
	ErrUnsupported = errors.New("this music source can't do that")
	ErrNotOpen     = errors.New("the music player isn't open")
)

// notOpenErr is ErrNotOpen with a message that says what to do.
type notOpenErr struct{ msg string }

func (e *notOpenErr) Error() string        { return e.msg }
func (e *notOpenErr) Is(target error) bool { return target == ErrNotOpen }

// notTrackErr is a link to something that isn't a single song.
type notTrackErr struct{ kind string }

func (e *notTrackErr) Error() string { return "that's a " + e.kind + " link, not a song" }

var sourceNames = map[string]string{
	"spotify": "Spotify",
	"windows": "Windows media",
	"ytmusic": "YouTube Music",
	"lastfm":  "Last.fm",
}

func validSource(id string) bool { _, ok := sourceNames[id]; return ok }

// source returns the music source the streamer picked.
func (a *App) source() Source {
	switch a.st.Get().MusicSource {
	case "windows":
		return a.win
	case "ytmusic":
		return a.ytm
	case "lastfm":
		return a.lfm
	}
	return a.spot
}

// ---------------- album art Station serves itself ----------------
//
// Windows hands over cover art as image bytes, not a link, so Station keeps the last few and serves
// them at /api/art/<id>. State output turns that path into a full link for whoever is asking.

type artStore struct {
	mu    sync.Mutex
	m     map[string]artItem
	order []string
}

type artItem struct {
	b     []byte
	ctype string
}

var arts = &artStore{m: map[string]artItem{}}

func (s *artStore) put(b []byte, ctype string) string {
	if len(b) == 0 {
		return ""
	}
	h := sha1.Sum(b)
	id := hex.EncodeToString(h[:8])
	if ctype == "" || !strings.HasPrefix(ctype, "image/") {
		ctype = http.DetectContentType(b)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.m[id]; !ok {
		s.m[id] = artItem{b, ctype}
		s.order = append(s.order, id)
		if len(s.order) > 40 {
			delete(s.m, s.order[0])
			s.order = s.order[1:]
		}
	}
	return "/api/art/" + id
}

func (s *artStore) get(id string) (artItem, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	it, ok := s.m[id]
	return it, ok
}

func serveArt(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/art/")
	it, ok := arts.get(id)
	if !ok {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", it.ctype)
	w.Header().Set("Cache-Control", "public, max-age=86400")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Write(it.b)
}

// absArt turns "/api/art/..." into a link that works for whoever asked (OBS on this PC, a phone on
// Wi-Fi, a DJ through the tunnel).
func absArt(r *http.Request, u string) string {
	if !strings.HasPrefix(u, "/api/art/") {
		return u
	}
	scheme := "http"
	if r.TLS != nil || strings.EqualFold(r.Header.Get("X-Forwarded-Proto"), "https") {
		scheme = "https"
	}
	return scheme + "://" + r.Host + u
}

func fixStateArt(r *http.Request, s *NowState) {
	if s.Track != nil {
		t := *s.Track
		t.Art = absArt(r, t.Art)
		s.Track = &t
	}
	for i := range s.Events {
		s.Events[i].Art = absArt(r, s.Events[i].Art)
	}
}

// ---------------- matching a request to what's playing ----------------

var bracketRe = regexp.MustCompile(`[\(\[][^\)\]]*[\)\]]`)

// normSong lowercases and drops "(Official Video)", "- Remastered 2011", "feat. X" and punctuation.
func normSong(s string) string {
	s = strings.ToLower(s)
	s = bracketRe.ReplaceAllString(s, " ")
	for _, cut := range []string{" - remaster", " - live", " - radio edit", " - single version", " - mono", " - stereo", " feat. ", " ft. ", " featuring "} {
		if i := strings.Index(s, cut); i > 0 {
			s = s[:i]
		}
	}
	var b strings.Builder
	space := false
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
			space = false
		} else if !space {
			b.WriteByte(' ')
			space = true
		}
	}
	return strings.TrimSpace(b.String())
}

func firstArtist(s string) string {
	for _, sep := range []string{",", "&", " x ", " feat", " ft.", " and "} {
		if i := strings.Index(strings.ToLower(s), sep); i > 0 {
			s = s[:i]
		}
	}
	return normSong(s)
}

// sameSong decides if a request (title/artist from a search) is the song now playing. Players
// report songs differently ("Artist - Song (Official Video)" by "ArtistVEVO" in a browser), so it
// looks for the request's title and main artist anywhere in what's playing.
func sameSong(reqTitle, reqArtist, nowTitle, nowArtist string) bool {
	rt := normSong(reqTitle)
	if rt == "" {
		return false
	}
	nt := normSong(nowTitle)
	all := " " + nt + " " + normSong(nowArtist) + " "
	if nt != rt && !strings.Contains(" "+nt+" ", " "+rt+" ") {
		return false
	}
	ra := firstArtist(reqArtist)
	if ra == "" {
		return true
	}
	return strings.Contains(all, " "+ra+" ") || strings.Contains(strings.ReplaceAll(all, " ", ""), strings.ReplaceAll(ra, " ", ""))
}

func uriScheme(u string) string {
	if i := strings.Index(u, ":"); i > 0 {
		return u[:i]
	}
	return ""
}

func reqMatches(r *Req, t *TrackView) bool {
	if r.URI != "" && t.URI != "" && uriScheme(r.URI) == uriScheme(t.URI) {
		return r.URI == t.URI
	}
	return sameSong(r.Title, r.Artist, t.Title, t.Artist)
}

// ---------------- song lookup for players without a catalog ----------------
//
// Windows media and Last.fm can't search or queue, so requests go on a list the streamer plays from.
// Songs are looked up in the iTunes Search API (free, no key) to get the real title, artist, cover,
// length and explicit flag, so the request rules still work.

var (
	itunesBase  = envOr("HWS_ITUNES", "https://itunes.apple.com")
	ytOEmbed    = envOr("HWS_YT_OEMBED", "https://www.youtube.com/oembed")
	spotOEmbed  = envOr("HWS_SPOTIFY_OEMBED", "https://open.spotify.com/oembed")
	lookupHTTP  = &http.Client{Timeout: 8 * time.Second}
	ytLinkRe    = regexp.MustCompile(`(?i)(?:youtube\.com/(?:watch\?(?:[^ ]*&)?v=|shorts/|embed/|live/)|youtu\.be/|music\.youtube\.com/watch\?(?:[^ ]*&)?v=)([A-Za-z0-9_-]{11})`)
	ytmURIRe    = regexp.MustCompile(`^ytm:([A-Za-z0-9_-]{11})$`)
	itunesURIRe = regexp.MustCompile(`^itunes:(\d+)$`)
)

func ytLink(s string) string {
	if m := ytLinkRe.FindStringSubmatch(s); m != nil {
		return m[1]
	}
	if m := ytmURIRe.FindStringSubmatch(strings.TrimSpace(s)); m != nil {
		return m[1]
	}
	return ""
}

type itunesTrack struct {
	ID       int64  `json:"trackId"`
	Name     string `json:"trackName"`
	Artist   string `json:"artistName"`
	Album    string `json:"collectionName"`
	Art      string `json:"artworkUrl100"`
	Millis   int    `json:"trackTimeMillis"`
	Explicit string `json:"trackExplicitness"`
	Kind     string `json:"kind"`
	URL      string `json:"trackViewUrl"`
}

func (t itunesTrack) view() TrackView {
	art := strings.Replace(t.Art, "100x100bb", "600x600bb", 1)
	return TrackView{ID: strconv.FormatInt(t.ID, 10), URI: "itunes:" + strconv.FormatInt(t.ID, 10), Title: t.Name, Artist: t.Artist,
		Album: t.Album, Art: art, Duration: t.Millis, Explicit: t.Explicit == "explicit", Link: t.URL}
}

func getJSON(u string, v any) error {
	res, err := lookupHTTP.Get(u)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return fmt.Errorf("%s answered %d", hostOf(u), res.StatusCode)
	}
	return json.NewDecoder(io.LimitReader(res.Body, 4<<20)).Decode(v)
}

func hostOf(u string) string {
	if p, err := url.Parse(u); err == nil {
		return p.Host
	}
	return u
}

func catalogSearch(q string, limit int) ([]TrackView, error) {
	if limit <= 0 || limit > 25 {
		limit = 10
	}
	var r struct {
		Results []itunesTrack `json:"results"`
	}
	err := getJSON(itunesBase+"/search?"+url.Values{"term": {q}, "media": {"music"}, "entity": {"song"}, "limit": {strconv.Itoa(limit)}}.Encode(), &r)
	if err != nil {
		return nil, err
	}
	out := []TrackView{}
	for _, t := range r.Results {
		if t.Name != "" && (t.Kind == "" || t.Kind == "song") {
			out = append(out, t.view())
		}
	}
	return out, nil
}

// catalogFind turns a request (song name, "song - artist", a YouTube or Spotify link) into a song.
func catalogFind(input string) (*TrackView, error) {
	input = strings.TrimSpace(input)
	if m := itunesURIRe.FindStringSubmatch(input); m != nil {
		var r struct {
			Results []itunesTrack `json:"results"`
		}
		if err := getJSON(itunesBase+"/lookup?id="+m[1], &r); err != nil {
			return nil, err
		}
		if len(r.Results) == 0 {
			return nil, nil
		}
		v := r.Results[0].view()
		return &v, nil
	}
	if id := ytLink(input); id != "" {
		var o struct {
			Title  string `json:"title"`
			Author string `json:"author_name"`
			Thumb  string `json:"thumbnail_url"`
		}
		watch := "https://www.youtube.com/watch?v=" + id
		if err := getJSON(ytOEmbed+"?"+url.Values{"url": {watch}, "format": {"json"}}.Encode(), &o); err != nil || o.Title == "" {
			return nil, err
		}
		title, artist := splitVideoTitle(o.Title, o.Author)
		return &TrackView{ID: id, URI: "yt:" + id, Title: title, Artist: artist, Art: o.Thumb, Link: watch}, nil
	}
	if kind, id := ParseLink(input); kind != "" {
		if kind != "track" {
			return nil, &notTrackErr{"Spotify " + kind}
		}
		var o struct {
			Title string `json:"title"`
		}
		if err := getJSON(spotOEmbed+"?"+url.Values{"url": {"https://open.spotify.com/track/" + id}}.Encode(), &o); err != nil || o.Title == "" {
			return nil, err
		}
		input = o.Title
	}
	q := input
	low := strings.ToLower(q)
	for _, sep := range []string{" - ", " – ", " — ", " by "} {
		if i := strings.LastIndex(low, sep); i > 0 {
			q = strings.TrimSpace(q[:i]) + " " + strings.TrimSpace(q[i+len(sep):])
			break
		}
	}
	res, err := catalogSearch(q, 5)
	if err != nil || len(res) == 0 {
		return nil, err
	}
	return &res[0], nil
}

// onlineCover finds album art for a song in Apple's free music catalog (for players that don't
// share their cover). It only uses a result that really is the same song.
func onlineCover(title, artist string) string {
	title, artist = strings.TrimSpace(title), strings.TrimSpace(artist)
	if title == "" {
		return ""
	}
	// try "title artist", then a cleaned-up title ("Song - Remastered 2011" → "Song")
	tries := []string{title + " " + artist}
	if clean := normSong(title); clean != "" && clean != strings.ToLower(title) {
		tries = append(tries, clean+" "+firstArtist(artist))
	}
	for _, q := range tries {
		res, err := catalogSearch(q, 8)
		if err != nil {
			return ""
		}
		for _, t := range res {
			if t.Art != "" && sameSong(t.Title, t.Artist, title, artist) {
				return t.Art
			}
		}
	}
	return ""
}

// splitVideoTitle reads "Artist - Song (Official Video)" style titles.
func splitVideoTitle(title, channel string) (string, string) {
	channel = strings.TrimSuffix(strings.TrimSuffix(channel, " - Topic"), "VEVO")
	for _, sep := range []string{" - ", " – ", " — "} {
		if i := strings.Index(title, sep); i > 0 {
			t := strings.TrimSpace(bracketRe.ReplaceAllString(title[i+len(sep):], ""))
			if t != "" {
				return t, strings.TrimSpace(title[:i])
			}
		}
	}
	return title, strings.TrimSpace(channel)
}

// ---------------- friendly player names (Windows app ids) ----------------

func appName(id string) string {
	l := strings.ToLower(id)
	known := []struct{ key, name string }{
		{"spotify", "Spotify"}, {"applemusic", "Apple Music"}, {"itunes", "iTunes"}, {"zunemusic", "Media Player"},
		{"youtube-music", "YouTube Music"}, {"youtubemusic", "YouTube Music"}, {"th-ch", "YouTube Music"},
		{"chrome", "Chrome"}, {"msedge", "Edge"}, {"brave", "Brave"}, {"opera", "Opera"}, {"vivaldi", "Vivaldi"},
		{"firefox", "Firefox"}, {"308046b0af4a39cb", "Firefox"}, {"tidal", "TIDAL"}, {"deezer", "Deezer"},
		{"amazon", "Amazon Music"}, {"foobar", "foobar2000"}, {"musicbee", "MusicBee"}, {"aimp", "AIMP"},
		{"vlc", "VLC"}, {"winamp", "Winamp"}, {"pretzel", "Pretzel"}, {"cider", "Cider"}, {"plexamp", "Plexamp"},
		{"soundcloud", "SoundCloud"}, {"pandora", "Pandora"}, {"dopamine", "Dopamine"}, {"qobuz", "Qobuz"},
		{"discord", "Discord"}, {"steam", "Steam"},
	}
	for _, k := range known {
		if strings.Contains(l, k.key) {
			return k.name
		}
	}
	n := id
	if i := strings.Index(n, "!"); i > 0 {
		n = n[:i]
	}
	if i := strings.Index(n, "_"); i > 0 {
		n = n[:i]
	}
	n = strings.TrimSuffix(strings.TrimSuffix(n, ".exe"), ".EXE")
	if i := strings.LastIndex(n, "."); i > 0 && i < len(n)-1 {
		n = n[i+1:]
	}
	if n == "" {
		return "Unknown player"
	}
	return n
}

func isWindows() bool { return runtime.GOOS == "windows" }

// musicStatus is what the dashboard shows about every music source.
func (a *App) musicStatus() map[string]any {
	c := a.st.Get()
	src := a.source()
	now := a.State()
	return map[string]any{
		"source": src.ID(), "name": src.Name(), "ready": src.Ready(), "caps": now.Caps, "player": now.Device, "error": now.Error,
		"spotify": map[string]any{"connected": a.sp.Connected(), "lastError": a.sp.LastErr, "hasApp": c.ClientID != ""},
		"windows": map[string]any{"available": a.win.Ready(), "status": a.win.Status(), "players": a.win.Sessions(), "app": c.WinMediaApp},
		"ytmusic": a.ytm.Status(),
		"lastfm":  map[string]any{"status": a.lfm.Status(), "ready": a.lfm.Ready()},
	}
}
