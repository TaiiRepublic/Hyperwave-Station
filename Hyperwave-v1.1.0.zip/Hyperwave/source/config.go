package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"log"
	"os"
	"path/filepath"
	"sync"
)

// Templates are the chat replies. {title} {artist} {user} {pos} {max} {mins} are filled in.
type Templates struct {
	Added     string `json:"added"`
	NotFound  string `json:"notFound"`
	Closed    string `json:"closed"`
	TooLong   string `json:"tooLong"`
	Limit     string `json:"limit"`
	Explicit  string `json:"explicit"`
	Duplicate string `json:"duplicate"`
	Blocked   string `json:"blocked"`
	NoDevice  string `json:"noDevice"`
	Empty     string `json:"empty"`
	NowPlay   string `json:"nowPlaying"`
	Nothing   string `json:"nothing"`
}

type Config struct {
	ClientID     string `json:"clientId"`
	RefreshToken string `json:"refreshToken"`
	Port         int    `json:"port"`
	DJPort       int    `json:"djPort"`
	DJKey        string `json:"djKey"`         // the DJ passkey (streamer-editable)
	DJMode       string `json:"djMode"`        // quick | fixed
	DJFixedURL   string `json:"djFixedUrl"`    // permanent address (Tailscale Funnel / Cloudflare)
	DJTunnelTok  string `json:"djTunnelToken"` // optional Cloudflare named-tunnel token
	DJAutoOpen   bool   `json:"djAutoOpen"`    // open DJ access when the app starts

	RequestsOpen    bool     `json:"requestsOpen"`
	MaxPerUser      int      `json:"maxPerUser"` // pending requests per viewer, 0 = unlimited
	MaxMinutes      float64  `json:"maxMinutes"` // longest track allowed, 0 = any
	BlockExplicit   bool     `json:"blockExplicit"`
	NoDupMinutes    int      `json:"noDupMinutes"`    // same track can't be requested again within N minutes
	Blocklist       []string `json:"blocklist"`       // words / artists / track ids
	UserCooldownSec int      `json:"userCooldownSec"` // per-viewer cooldown

	// Built-in chat listener (standalone mode, no Streamer.bot needed)
	ListenTwitch    bool     `json:"listenTwitch"`
	TwitchChannel   string   `json:"twitchChannel"`
	ListenKick      bool     `json:"listenKick"`
	KickChannel     string   `json:"kickChannel"`
	KickChatroomID  string   `json:"kickChatroomId"`
	KickChannelID   string   `json:"kickChannelId"`
	SetupDone       bool     `json:"setupDone"`       // the first-run setup walkthrough was finished or skipped   // found automatically; Kick's chat server lookup needs it
	ViewerSRCommand bool     `json:"viewerSrCommand"` // let anyone use !sr in chat (standalone)
	ModCommands     bool     `json:"modCommands"`     // let mods use !skip etc in chat (standalone)
	ExtraDJs        []string `json:"extraDjs"`        // usernames treated as DJs besides mods
	CommandPrefix   string   `json:"commandPrefix"`

	// OBS & Deck
	OBSEnabled    bool   `json:"obsEnabled"`
	OBSHost       string `json:"obsHost"`
	OBSPort       int    `json:"obsPort"`
	OBSPassword   string `json:"obsPassword"`
	OBSKeepReplay bool   `json:"obsKeepReplay"` // start OBS's replay buffer automatically so Clip always works

	SBEnabled    bool   `json:"sbEnabled"`
	SBHost       string `json:"sbHost"`
	SBPort       int    `json:"sbPort"`
	SBPassword   string `json:"sbPassword"`
	SBClipAction string `json:"sbClipAction"` // Streamer.bot action that makes a Twitch clip

	TwitchAppID   string `json:"twitchAppId"`   // the streamer's own Twitch app (Public client)
	TwitchRefresh string `json:"twitchRefresh"` // protected
	TwitchUserID  string `json:"twitchUserId"`  // protected
	TwitchLogin   string `json:"twitchLogin"`   // protected

	ReplyVia   string `json:"replyVia"`   // auto | station | streamerbot
	ClipReplay bool   `json:"clipReplay"` // Clip button saves OBS's replay buffer
	ClipTwitch bool   `json:"clipTwitch"` // Clip button also makes a Twitch clip

	DeckTwitch    bool        `json:"deckTwitch"`
	DeckKick      bool        `json:"deckKick"`
	DeckYouTube   bool        `json:"deckYouTube"` // through Streamer.bot
	DeckTikTok    bool        `json:"deckTikTok"`  // through TikFinity
	TikFinityPort int         `json:"tikFinityPort"`
	DeckLAN       bool        `json:"deckLan"` // let phones/tablets on your Wi-Fi open the deck
	DeckPort      int         `json:"deckPort"`
	DeckKey       string      `json:"deckKey"` // protected; also used in Stream Deck links
	QuickMsgs     []string    `json:"quickMsgs"`
	PadButtons    []PadButton `json:"padButtons"` // My Deck, designed by the streamer (protected: edited on the deck)

	// Kick (official API, for changing your category)
	KickClientID string     `json:"kickClientId"`
	KickSecret   string     `json:"kickSecret"`  // protected: never sent back to the page
	KickRefresh  string     `json:"kickRefresh"` // protected
	KickLogin    string     `json:"kickLogin"`   // protected
	RecentCats   []CatHit   `json:"recentCats"`
	Launchers    []Launcher `json:"launchers"` // programs on deck buttons (only added from this PC)

	// Music source: spotify | windows | ytmusic | lastfm
	MusicSource string `json:"musicSource"`
	WinMediaApp string `json:"winMediaApp"` // follow only this player ("" = whatever is playing)
	YTMHost     string `json:"ytmHost"`
	YTMPort     int    `json:"ytmPort"`
	YTMToken    string `json:"ytmToken"` // protected
	LastfmUser  string `json:"lastfmUser"`
	LastfmKey   string `json:"lastfmKey"`

	CloudflaredPath string    `json:"cloudflaredPath"`
	T               Templates `json:"templates"`
}

func defaultTemplates() Templates {
	return Templates{
		Added:     "🎵 {title} by {artist} is in the queue (#{pos}) — thanks @{user}!",
		NotFound:  "@{user} couldn't find that song. Try \"song - artist\" or paste a link.",
		Closed:    "@{user} song requests are closed right now.",
		TooLong:   "@{user} that track is too long (max {max} min).",
		Limit:     "@{user} you already have {max} songs waiting — let one play first!",
		Explicit:  "@{user} explicit tracks are turned off on this stream.",
		Duplicate: "@{user} that song was just requested — pick another!",
		Blocked:   "@{user} that song isn't allowed here.",
		NoDevice:  "@{user} the music player isn't open right now, so the queue is offline.",
		Empty:     "@{user} add a song name or link after the command.",
		NowPlay:   "🎵 Now playing: {title} by {artist}{req}",
		Nothing:   "Nothing is playing right now.",
	}
}

func defaultConfig() *Config {
	return &Config{
		Port: 7575, DJPort: 7576, DJKey: newPasskey(),
		RequestsOpen: true, MaxPerUser: 3, MaxMinutes: 8, NoDupMinutes: 30, UserCooldownSec: 0,
		ModCommands: true, CommandPrefix: "!",
		OBSHost: "127.0.0.1", OBSPort: 4455, OBSKeepReplay: true,
		YTMHost: "127.0.0.1", YTMPort: 26538,
		SBHost: "127.0.0.1", SBPort: 8080, SBClipAction: "Hyperwave - Twitch Clip",
		ReplyVia: "auto", ClipReplay: true, ClipTwitch: true,
		DeckTwitch: true, DeckKick: true, TikFinityPort: 21213, DeckPort: 7577, DeckKey: newPasskey(),
		QuickMsgs: []string{"Welcome in! o7", "Be right back, don't go anywhere!", "Thanks so much for the follow! 💜", "GG!"},
		T:         defaultTemplates(),
	}
}

func newKey() string {
	b := make([]byte, 12)
	rand.Read(b)
	return hex.EncodeToString(b)
}

type Store struct {
	mu      sync.Mutex
	path    string
	C       *Config
	saveErr string
}

// SaveError is the last error writing the settings file, or "" when saving works.
func (s *Store) SaveError() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.saveErr
}

func exeDir() string {
	p, err := os.Executable()
	if err != nil {
		return "."
	}
	return filepath.Dir(p)
}

// configPath prefers the folder next to the exe; falls back to %APPDATA% when that folder is read-only.
func configPath() string {
	if p := devEnv("HWS_CONFIG"); p != "" {
		return p
	}
	dir := exeDir()
	test := filepath.Join(dir, ".hws-write-test")
	if f, err := os.Create(test); err == nil {
		f.Close()
		os.Remove(test)
		return filepath.Join(dir, "hyperwave-station.json")
	}
	if ad, err := os.UserConfigDir(); err == nil {
		d := filepath.Join(ad, "HyperwaveStation")
		os.MkdirAll(d, 0700)
		return filepath.Join(d, "hyperwave-station.json")
	}
	return "hyperwave-station.json"
}

func loadStore() *Store {
	s := &Store{path: configPath(), C: defaultConfig()}
	if b, err := os.ReadFile(s.path); err == nil {
		json.Unmarshal(b, s.C)
		// Upgrading from before 1.1.0: anyone who already set things up skips the walkthrough
		if !bytes.Contains(b, []byte(`"setupDone"`)) {
			c := s.C
			s.C.SetupDone = c.TwitchChannel != "" || c.KickChannel != "" || c.RefreshToken != "" || c.YTMToken != "" ||
				c.LastfmUser != "" || c.OBSPassword != "" || c.SBPassword != "" || len(c.PadButtons) > 0
		}
	}
	d := defaultTemplates()
	t := &s.C.T
	// replies that used to name Spotify move to the new wording unless you changed them
	old := map[*string][2]string{
		&t.NotFound: {"@{user} couldn't find that song on Spotify. Try \"song - artist\" or paste a Spotify link.", d.NotFound},
		&t.NoDevice: {"@{user} Spotify isn't playing right now, so the queue is offline.", d.NoDevice},
		&t.Empty:    {"@{user} add a song name or Spotify link after the command.", d.Empty},
	}
	for p, v := range old {
		if *p == v[0] {
			*p = v[1]
		}
	}
	fill := func(v *string, def string) {
		if *v == "" {
			*v = def
		}
	}
	fill(&t.Added, d.Added)
	fill(&t.NotFound, d.NotFound)
	fill(&t.Closed, d.Closed)
	fill(&t.TooLong, d.TooLong)
	fill(&t.Limit, d.Limit)
	fill(&t.Explicit, d.Explicit)
	fill(&t.Duplicate, d.Duplicate)
	fill(&t.Blocked, d.Blocked)
	fill(&t.NoDevice, d.NoDevice)
	fill(&t.Empty, d.Empty)
	fill(&t.NowPlay, d.NowPlay)
	fill(&t.Nothing, d.Nothing)
	if s.C.Port == 0 {
		s.C.Port = 7575
	}
	if s.C.DJPort == 0 {
		s.C.DJPort = 7576
	}
	if s.C.DJKey == "" {
		s.C.DJKey = newPasskey()
	}
	if s.C.DJMode != "fixed" {
		s.C.DJMode = "quick"
	}
	if s.C.CommandPrefix == "" {
		s.C.CommandPrefix = "!"
	}
	if s.C.DeckKey == "" {
		s.C.DeckKey = newPasskey()
	}
	if s.C.DeckPort == 0 {
		s.C.DeckPort = 7577
	}
	if s.C.ReplyVia == "" {
		s.C.ReplyVia = "auto"
	}
	if !validSource(s.C.MusicSource) {
		// existing Spotify setups stay on Spotify; new installs start on Windows media, which
		// needs no account at all
		if s.C.RefreshToken != "" || s.C.ClientID != "" {
			s.C.MusicSource = "spotify"
		} else {
			s.C.MusicSource = "windows"
		}
	}
	if s.C.YTMHost == "" {
		s.C.YTMHost = "127.0.0.1"
	}
	if s.C.YTMPort == 0 {
		s.C.YTMPort = 26538
	}
	s.Save()
	return s
}

func (s *Store) Save() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	b, _ := json.MarshalIndent(s.C, "", "  ")
	err := os.WriteFile(s.path, b, 0600)
	if err != nil {
		if s.saveErr == "" {
			log.Printf("Can't save settings to %s: %v", s.path, err)
		}
		s.saveErr = err.Error()
	} else {
		s.saveErr = ""
	}
	return err
}

// Get returns a copy so callers never race with edits. Lists inside are shared, so treat them
// as read-only (change settings through Update).
func (s *Store) Get() Config {
	s.mu.Lock()
	defer s.mu.Unlock()
	return *s.C
}

func (s *Store) Update(f func(c *Config)) {
	s.mu.Lock()
	f(s.C)
	s.mu.Unlock()
	s.Save()
}
