//go:build hwsdev

package main

import "os"

// devEnv reads HWS_* settings used when testing Hyperwave against stand-in servers.
// Only builds made with -tags hwsdev read them.
func devEnv(k string) string { return os.Getenv(k) }
