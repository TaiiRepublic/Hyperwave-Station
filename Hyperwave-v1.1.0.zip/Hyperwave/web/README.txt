Hyperwave Station looks in this folder before using its built-in pages.

about.json  - the About section on the dashboard and the console welcome screen.
              Open it in Notepad, change it, and reload the dashboard.

Want to change a page? Put your own copy of index.html, nowplaying.html,
dj.html or chat.html here and it replaces the built-in one.
Delete it to go back to the built-in page.
