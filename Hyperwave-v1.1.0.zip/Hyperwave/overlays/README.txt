Hyperwave overlays you can load in OBS straight from this folder.
Hyperwave Station doesn't need to be running for them to show.

chat.html        - the chat overlay
nowplaying.html  - the music overlay
layouts\chat     - chat layouts (default.json, plus one per OBS scene)
layouts\music    - music overlay layouts

Hyperwave Station refreshes chat.html and nowplaying.html when it starts, so
don't edit them here. See SETUP-GUIDE.md, section "Scene layouts".
