package main

import (
	"bufio"
	"crypto/rand"
	"crypto/subtle"
	"embed"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

//go:embed web
var webFS embed.FS

const Version = "1.0.0"

var oldChatOnce sync.Once

// serveWeb serves a page, preferring a file in ./web next to the exe (so users can drop in
// their own Hyperwave Chat index.html or customise pages) over the built-in copy.
func serveWeb(w http.ResponseWriter, r *http.Request, name string) {
	local := filepath.Join(exeDir(), "web", name)
	if b, err := os.ReadFile(local); err == nil {
		// An old Hyperwave Chat copied in before chat was built in would hide the newer
		// built-in one, so only use a local chat.html that's 0.9.5 or later.
		if name == "chat.html" && !strings.Contains(string(b), "connectStation") {
			oldChatOnce.Do(func() {
				log.Println("[chat] Ignoring the older web\\chat.html and using the built-in Hyperwave Chat. You can delete that file.")
			})
		} else {
			writeFile(w, name, b)
			return
		}
	}
	b, err := fs.ReadFile(webFS, "web/"+name)
	if err != nil {
		if name == "chat.html" {
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			fmt.Fprint(w, chatMissing)
			return
		}
		http.NotFound(w, r)
		return
	}
	writeFile(w, name, b)
}

func writeFile(w http.ResponseWriter, name string, b []byte) {
	ct := "text/html; charset=utf-8"
	switch {
	case strings.HasSuffix(name, ".js"):
		ct = "text/javascript; charset=utf-8"
	case strings.HasSuffix(name, ".css"):
		ct = "text/css; charset=utf-8"
	case strings.HasSuffix(name, ".png"):
		ct = "image/png"
	case strings.HasSuffix(name, ".json"):
		ct = "application/json; charset=utf-8"
	case strings.HasSuffix(name, ".svg"):
		ct = "image/svg+xml"
	case strings.HasSuffix(name, ".md"):
		ct = "text/markdown; charset=utf-8"
	case strings.HasSuffix(name, ".webm"):
		ct = "video/webm"
	case strings.HasSuffix(name, ".webp"):
		ct = "image/webp"
	}
	w.Header().Set("Content-Type", ct)
	w.Header().Set("Cache-Control", "no-cache")
	w.Write(b)
}

const chatMissing = `<!doctype html><meta charset=utf-8><title>Hyperwave Chat</title>
<body style="font:16px/1.5 system-ui;background:#15171c;color:#e8e6e3;padding:40px;max-width:640px">
<h1>Hyperwave Chat isn't installed here yet</h1>
<p>Put your Hyperwave Chat <code>index.html</code> into the <code>web</code> folder next to
<b>HyperwaveStation.exe</b> and rename it to <code>chat.html</code>. Then reload this page.</p>
<p>Your OBS link becomes <code>http://127.0.0.1:7575/chat?overlay#cfg=…</code> — or keep using the GitHub Pages copy, both work.</p></body>`

func jsonOut(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func textOut(w http.ResponseWriter, s string) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	io.WriteString(w, s)
}

func cors(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, X-DJ-Key")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Private-Network", "true")
}

// localGuard blocks DNS-rebinding and cross-site requests against the local control server.
// Streamer.bot / OBS / your own browser on 127.0.0.1 all pass; random websites don't.
// pageGuard is for plain pages and the Spotify login return: a top-level GET navigation
// arriving from another site (e.g. accounts.spotify.com sending you back) is allowed.
// Everything else still goes through the strict checks in localGuard.
func pageGuard(port int, h http.HandlerFunc) http.HandlerFunc {
	strict := localGuard(port, false, h)
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "GET" && r.Header.Get("Sec-Fetch-Mode") == "navigate" {
			localGuard(port, true, h)(w, r) // host check only
			return
		}
		strict(w, r)
	}
}

func localGuard(port int, allowCORS bool, h http.HandlerFunc) http.HandlerFunc {
	okHosts := map[string]bool{
		fmt.Sprintf("127.0.0.1:%d", port): true, fmt.Sprintf("localhost:%d", port): true,
		"127.0.0.1": true, "localhost": true,
	}
	return func(w http.ResponseWriter, r *http.Request) {
		if !okHosts[strings.ToLower(r.Host)] {
			http.Error(w, "forbidden host", 403)
			return
		}
		if allowCORS {
			cors(w)
			if r.Method == "OPTIONS" {
				return
			}
		} else {
			if r.Header.Get("Sec-Fetch-Site") == "cross-site" {
				http.Error(w, "cross-site request blocked", 403)
				return
			}
			if o := r.Header.Get("Origin"); o != "" && o != "null" {
				oh := strings.TrimPrefix(strings.TrimPrefix(o, "http://"), "https://")
				if !okHosts[strings.ToLower(oh)] {
					http.Error(w, "cross-origin request blocked", 403)
					return
				}
			}
		}
		h(w, r)
	}
}

func param(r *http.Request, names ...string) string {
	for _, n := range names {
		if v := r.FormValue(n); v != "" {
			return v
		}
	}
	return ""
}

func wantText(r *http.Request) bool {
	f := r.FormValue("format")
	return f == "text" || r.FormValue("text") == "1"
}

// ---------------- local server (127.0.0.1:7575) ----------------

func (a *App) LocalMux() http.Handler {
	c := a.st.Get()
	port := c.Port
	g := func(h http.HandlerFunc) http.HandlerFunc { return localGuard(port, false, h) }
	open := func(h http.HandlerFunc) http.HandlerFunc { return localGuard(port, true, h) }
	page := func(h http.HandlerFunc) http.HandlerFunc { return pageGuard(port, h) }
	m := http.NewServeMux()

	m.HandleFunc("/", page(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		serveWeb(w, r, "index.html")
	}))
	m.HandleFunc("/overlay", open(func(w http.ResponseWriter, r *http.Request) { serveWeb(w, r, "nowplaying.html") }))
	m.HandleFunc("/nowplaying", open(func(w http.ResponseWriter, r *http.Request) { serveWeb(w, r, "nowplaying.html") }))
	m.HandleFunc("/dj", page(func(w http.ResponseWriter, r *http.Request) { serveWeb(w, r, "dj.html") }))
	m.HandleFunc("/chat", open(func(w http.ResponseWriter, r *http.Request) { serveWeb(w, r, "chat.html") }))
	m.HandleFunc("/deck", page(func(w http.ResponseWriter, r *http.Request) { serveWeb(w, r, "deck.html") }))
	a.deckRoutes(m, g)
	// Elgato Stream Deck: Website action → "GET request in background"
	m.HandleFunc("/api/deck/run", g(a.streamDeckRun))
	// Deck passkey: POST key=<your own passkey>  or  POST random=1
	m.HandleFunc("/api/deck/key", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		k := strings.TrimSpace(r.FormValue("key"))
		if r.FormValue("random") == "1" {
			k = newPasskey()
		}
		if !passkeyRe.MatchString(k) {
			jsonOut(w, 400, map[string]string{"error": "Use 6–64 letters, numbers, dashes or underscores (no spaces)."})
			return
		}
		a.st.Update(func(c *Config) { c.DeckKey = k })
		log.Println("Deck passkey changed.")
		jsonOut(w, 200, map[string]any{"ok": true, "key": k, "deckLan": a.lan.Status()})
	}))
	// QR code that opens the deck on a phone, already signed in (i = which network address)
	m.HandleFunc("/api/deck/qr", g(a.deckQR))
	m.HandleFunc("/api/dj/qr", g(a.djQR))
	a.soundRoutes(m, open, g)
	a.kickRoutes(m, g, page)
	m.HandleFunc("/api/twitch/login", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		l, err := a.tw.StartLogin()
		if err != nil {
			jsonOut(w, 200, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "signin": l})
	}))
	m.HandleFunc("/api/twitch/status", g(func(w http.ResponseWriter, r *http.Request) { jsonOut(w, 200, a.tw.Status()) }))
	m.HandleFunc("/api/twitch/logout", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		a.tw.Logout()
		jsonOut(w, 200, map[string]any{"ok": true})
	}))
	m.HandleFunc("/api/music/status", g(func(w http.ResponseWriter, r *http.Request) { jsonOut(w, 200, a.musicStatus()) }))
	m.HandleFunc("/api/music/ytm/connect", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		a.ytm.Connect()
		jsonOut(w, 200, a.musicStatus())
	}))
	m.HandleFunc("/api/music/ytm/logout", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		a.st.Update(func(c *Config) { c.YTMToken = "" })
		jsonOut(w, 200, a.musicStatus())
	}))
	m.HandleFunc("/web/", open(func(w http.ResponseWriter, r *http.Request) {
		name := filepath.Base(r.URL.Path)
		serveWeb(w, r, name)
	}))

	// Spotify login
	m.HandleFunc("/login", page(func(w http.ResponseWriter, r *http.Request) {
		if a.st.Get().ClientID == "" {
			http.Redirect(w, r, "/?err=clientid", 302)
			return
		}
		http.Redirect(w, r, a.sp.LoginURL(), 302)
	}))
	m.HandleFunc("/callback", page(func(w http.ResponseWriter, r *http.Request) {
		if e := r.FormValue("error"); e != "" {
			http.Redirect(w, r, "/?err="+e, 302)
			return
		}
		if err := a.sp.Exchange(r.FormValue("code"), r.FormValue("state")); err != nil {
			log.Println("login:", err)
			http.Redirect(w, r, "/?err="+urlq(err.Error()), 302)
			return
		}
		log.Println("Spotify connected.")
		a.poke()
		http.Redirect(w, r, "/?ok=spotify", 302)
	}))

	// Overlay data (CORS-open & read-only, so a GitHub-hosted overlay can use the app too)
	m.HandleFunc("/api/state", open(func(w http.ResponseWriter, r *http.Request) {
		s := a.State()
		fixStateArt(r, &s)
		jsonOut(w, 200, s)
	}))
	m.HandleFunc("/api/art/", open(serveArt))
	m.HandleFunc("/api/song", open(func(w http.ResponseWriter, r *http.Request) {
		if wantText(r) || r.FormValue("format") == "" {
			textOut(w, a.NowPlayingText())
			return
		}
		s := a.State()
		fixStateArt(r, &s)
		jsonOut(w, 200, s)
	}))

	// Song request: /api/sr?q=...&user=...&platform=twitch  (plain-text reply for Streamer.bot Fetch URL)
	m.HandleFunc("/api/sr", g(func(w http.ResponseWriter, r *http.Request) {
		res := a.Request(param(r, "q", "query", "input"), param(r, "user", "u"), param(r, "platform", "p"), r.FormValue("bypass") == "1")
		if wantText(r) {
			textOut(w, res.Reply)
			return
		}
		jsonOut(w, 200, res)
	}))
	// DJ / mod command: /api/cmd?c=skip&arg=&user=
	m.HandleFunc("/api/cmd", g(func(w http.ResponseWriter, r *http.Request) {
		reply, err := a.Command(param(r, "c", "cmd"), param(r, "arg", "a"), param(r, "user", "u"))
		if err != nil {
			reply = "⚠ " + err.Error()
		}
		if wantText(r) {
			textOut(w, reply)
			return
		}
		jsonOut(w, 200, map[string]any{"ok": err == nil, "reply": reply})
	}))

	// Dashboard config
	m.HandleFunc("/api/config", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			var in Config
			b, _ := io.ReadAll(io.LimitReader(r.Body, 1<<20))
			cur := a.st.Get()
			in = cur
			// Get shares its lists with the saved settings. Give the form its own copies so
			// reading it can never write into the saved ones (deck buttons, programs...).
			in.Blocklist = append([]string(nil), cur.Blocklist...)
			in.ExtraDJs = append([]string(nil), cur.ExtraDJs...)
			in.QuickMsgs = append([]string(nil), cur.QuickMsgs...)
			in.PadButtons, in.RecentCats, in.Launchers = nil, nil, nil
			if err := json.Unmarshal(b, &in); err != nil {
				jsonOut(w, 400, map[string]string{"error": err.Error()})
				return
			}
			// protected fields can't be set from the form
			in.RefreshToken = cur.RefreshToken
			in.YTMToken = cur.YTMToken
			in.KickRefresh, in.KickLogin, in.RecentCats = cur.KickRefresh, cur.KickLogin, cur.RecentCats
			in.Launchers = cur.Launchers
			in.KickClientID = strings.TrimSpace(in.KickClientID)
			in.KickSecret = strings.TrimSpace(in.KickSecret)
			if in.KickSecret == "" {
				in.KickSecret = cur.KickSecret
			}
			if in.KickClientID != cur.KickClientID {
				in.KickRefresh, in.KickLogin = "", ""
			}
			if !validSource(in.MusicSource) {
				in.MusicSource = cur.MusicSource
			}
			in.WinMediaApp = strings.TrimSpace(in.WinMediaApp)
			in.YTMHost = strings.TrimSpace(in.YTMHost)
			if in.YTMHost == "" {
				in.YTMHost = "127.0.0.1"
			}
			if in.YTMPort <= 0 || in.YTMPort > 65535 {
				in.YTMPort = 26538
			}
			in.LastfmUser, in.LastfmKey = strings.TrimSpace(in.LastfmUser), strings.TrimSpace(in.LastfmKey)
			musicChanged := in.MusicSource != cur.MusicSource || in.WinMediaApp != cur.WinMediaApp
			in.DJKey = cur.DJKey
			in.DeckKey = cur.DeckKey
			in.PadButtons = cur.PadButtons
			in.TwitchRefresh, in.TwitchUserID, in.TwitchLogin = cur.TwitchRefresh, cur.TwitchUserID, cur.TwitchLogin
			in.TwitchAppID = strings.TrimSpace(in.TwitchAppID)
			twitchAppChanged := in.TwitchAppID != cur.TwitchAppID
			if in.OBSPort <= 0 || in.OBSPort > 65535 {
				in.OBSPort = 4455
			}
			if in.SBPort <= 0 || in.SBPort > 65535 {
				in.SBPort = 8080
			}
			if in.DeckPort <= 1024 || in.DeckPort > 65535 || in.DeckPort == in.Port || in.DeckPort == in.DJPort {
				in.DeckPort = 7577
			}
			if in.ReplyVia != "station" && in.ReplyVia != "streamerbot" {
				in.ReplyVia = "auto"
			}
			var qm []string
			for _, q := range in.QuickMsgs {
				if q = strings.TrimSpace(q); q != "" && len(qm) < 12 {
					qm = append(qm, q)
				}
			}
			in.QuickMsgs = qm
			if in.DJMode != "fixed" {
				in.DJMode = "quick"
			}
			in.DJFixedURL = strings.TrimRight(strings.TrimSpace(in.DJFixedURL), "/")
			if in.DJFixedURL != "" && !strings.HasPrefix(in.DJFixedURL, "https://") && !strings.HasPrefix(in.DJFixedURL, "http://") {
				in.DJFixedURL = "https://" + in.DJFixedURL
			}
			in.DJTunnelTok = strings.TrimSpace(in.DJTunnelTok)
			modeChanged := in.DJMode != cur.DJMode || in.DJFixedURL != cur.DJFixedURL || in.DJTunnelTok != cur.DJTunnelTok
			in.ClientID = strings.TrimSpace(in.ClientID)
			if in.ClientID != cur.ClientID && cur.RefreshToken != "" {
				in.RefreshToken = ""
			}
			// Spotify hands out a new login token every time the app renews it. Keep whichever
			// token is current at the moment of saving, so a dashboard save that started just
			// before a renewal can't put back the old, now-dead token and log you out.
			keepLogin := in.RefreshToken != ""
			a.st.Update(func(c *Config) {
				live, liveTw, liveYT, liveKick, liveCats, liveLaunch := c.RefreshToken, c.TwitchRefresh, c.YTMToken, c.KickRefresh, c.RecentCats, c.Launchers
				kickApp := in.KickClientID != c.KickClientID
				*c = in
				c.YTMToken = liveYT
				c.RecentCats = liveCats
				c.Launchers = liveLaunch
				if !kickApp {
					c.KickRefresh = liveKick
				}
				if keepLogin {
					c.RefreshToken = live
				}
				c.TwitchRefresh = liveTw
				if twitchAppChanged {
					c.TwitchRefresh, c.TwitchUserID, c.TwitchLogin = "", "", ""
				}
			})
			a.chat.Restart()
			if in.OBSEnabled != cur.OBSEnabled || in.OBSHost != cur.OBSHost || in.OBSPort != cur.OBSPort || in.OBSPassword != cur.OBSPassword {
				a.obs.Restart()
			}
			if in.SBEnabled != cur.SBEnabled || in.SBHost != cur.SBHost || in.SBPort != cur.SBPort || in.SBPassword != cur.SBPassword || in.DeckYouTube != cur.DeckYouTube {
				a.sb.Restart()
			}
			if in.DeckTikTok != cur.DeckTikTok || in.TikFinityPort != cur.TikFinityPort {
				a.tik.Restart()
			}
			if in.DeckLAN != cur.DeckLAN || in.DeckPort != cur.DeckPort {
				a.lan.Restart()
			}
			if musicChanged {
				if in.MusicSource != "windows" {
					a.win.Close()
				}
				a.qMu.Lock()
				a.qAt = time.Time{}
				a.qMu.Unlock()
				a.poke()
			}
			if modeChanged && a.tun.IsOpen() {
				a.tun.Stop()
				a.tun.Start()
			}
		}
		c := a.st.Get()
		c.RefreshToken = ""
		c.TwitchRefresh = ""
		c.YTMToken = ""
		kickSecret := c.KickSecret != ""
		c.KickSecret, c.KickRefresh = "", ""
		jsonOut(w, 200, map[string]any{
			"kick": a.kick.Status(), "kickHasSecret": kickSecret, "sounds": map[string]any{"player": a.sounds.PlayerOnline()},
			"music": a.musicStatus(),
			"obs":   a.obs.State(), "sb": a.sb.Status(), "twitch": a.tw.Status(), "deckLan": a.lan.Status(), "tiktok": a.tik.Status(),
			"config": c, "connected": a.sp.Connected(), "redirectUri": a.sp.RedirectURI(),
			"lastError": a.sp.LastErr, "tunnel": a.tun.Status(), "chat": a.chat.Status(), "version": Version,
			"saveError":  a.st.SaveError(),
			"configPath": a.st.path,
		})
	}))
	// DJ passkey: POST key=<new passkey>  or  POST random=1
	m.HandleFunc("/api/passkey", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		k := strings.TrimSpace(r.FormValue("key"))
		if r.FormValue("random") == "1" {
			k = newPasskey()
		}
		if !passkeyRe.MatchString(k) {
			jsonOut(w, 400, map[string]string{"error": "Use 6–64 letters, numbers, dashes or underscores (no spaces)."})
			return
		}
		a.st.Update(func(c *Config) { c.DJKey = k })
		log.Println("DJ passkey changed.")
		jsonOut(w, 200, map[string]any{"djKey": k, "tunnel": a.tun.Status()})
	}))
	m.HandleFunc("/api/disconnect", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		a.sp.Disconnect()
		jsonOut(w, 200, map[string]bool{"ok": true})
	}))
	m.HandleFunc("/api/tunnel", g(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			switch r.FormValue("action") {
			case "start":
				a.tun.Start()
			case "stop":
				a.tun.Stop()
			}
		}
		jsonOut(w, 200, a.tun.Status())
	}))

	// DJ API on the local server needs no key (only you, on this PC, can reach it)
	a.djRoutes(m, func(h http.HandlerFunc) http.HandlerFunc { return g(h) })
	return m
}

func urlq(s string) string {
	r := strings.NewReplacer(" ", "+", "&", "%26", "#", "%23", "?", "%3F")
	return r.Replace(s)
}

// ---------------- DJ server (127.0.0.1:7576, the only thing the tunnel exposes) ----------------

type limiter struct {
	mu     sync.Mutex
	fail   map[string][]time.Time
	global []time.Time
}

func prune(ts []time.Time) []time.Time {
	keep := ts[:0]
	for _, t := range ts {
		if time.Since(t) < 10*time.Minute {
			keep = append(keep, t)
		}
	}
	return keep
}

func (l *limiter) blocked(ip string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.fail[ip] = prune(l.fail[ip])
	l.global = prune(l.global)
	// 8 wrong guesses per visitor, 40 in total, per 10 minutes
	return len(l.fail[ip]) >= 8 || len(l.global) >= 40
}
func (l *limiter) clear(ip string) {
	l.mu.Lock()
	delete(l.fail, ip)
	l.mu.Unlock()
}
func (l *limiter) add(ip string) {
	l.mu.Lock()
	l.fail[ip] = append(l.fail[ip], time.Now())
	l.global = append(l.global, time.Now())
	l.mu.Unlock()
}

func clientIP(r *http.Request) string {
	if v := r.Header.Get("Cf-Connecting-Ip"); v != "" {
		return v
	}
	if v := r.Header.Get("X-Forwarded-For"); v != "" {
		// the proxy appends the real address last; earlier entries can be faked by the visitor
		parts := strings.Split(v, ",")
		return strings.TrimSpace(parts[len(parts)-1])
	}
	h, _, _ := net.SplitHostPort(r.RemoteAddr)
	return h
}

func (a *App) DJMux() http.Handler {
	lim := &limiter{fail: map[string][]time.Time{}}
	m := http.NewServeMux()
	secHeaders := func(w http.ResponseWriter) {
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Content-Type-Options", "nosniff")
	}
	m.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		secHeaders(w)
		if r.URL.Path == "/" || r.URL.Path == "/dj" {
			serveWeb(w, r, "dj.html")
			return
		}
		http.NotFound(w, r)
	})
	m.HandleFunc("/api/art/", func(w http.ResponseWriter, r *http.Request) {
		secHeaders(w)
		serveArt(w, r)
	})
	// lets the dashboard check a fixed address really reaches this PC
	m.HandleFunc("/api/dj/ping", func(w http.ResponseWriter, r *http.Request) {
		secHeaders(w)
		jsonOut(w, 200, map[string]any{"hyperwave": true, "nonce": r.FormValue("n")})
	})
	auth := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			secHeaders(w)
			if !a.tun.IsOpen() {
				jsonOut(w, 503, map[string]string{"error": "closed"})
				return
			}
			ip := clientIP(r)
			if lim.blocked(ip) {
				jsonOut(w, 429, map[string]string{"error": "Too many wrong passkeys. Wait 10 minutes and try again."})
				return
			}
			key := r.Header.Get("X-DJ-Key")
			want := a.st.Get().DJKey
			if key == "" || subtle.ConstantTimeCompare([]byte(key), []byte(want)) != 1 {
				lim.add(ip)
				jsonOut(w, 401, map[string]string{"error": "wrong passkey"})
				return
			}
			h(w, r)
		}
	}
	a.djRoutes(m, auth)
	return m
}

func (a *App) djRoutes(m *http.ServeMux, wrap func(http.HandlerFunc) http.HandlerFunc) {
	m.HandleFunc("/api/dj/state", wrap(func(w http.ResponseWriter, r *http.Request) {
		s := a.State()
		fixStateArt(r, &s)
		out := map[string]any{"now": s, "requestsOpen": a.st.Get().RequestsOpen, "requests": firstN(a.Requests(), 30)}
		if r.FormValue("queue") == "1" {
			q, err := a.UpNext()
			out["queue"] = q
			if err != nil {
				out["queueError"] = err.Error()
			}
		}
		jsonOut(w, 200, out)
	}))
	m.HandleFunc("/api/dj/search", wrap(func(w http.ResponseWriter, r *http.Request) {
		q := strings.TrimSpace(r.FormValue("q"))
		if q == "" {
			jsonOut(w, 400, map[string]string{"error": "empty search"})
			return
		}
		types := r.FormValue("type")
		if types == "" {
			types = "track,playlist,album"
		}
		src := a.source()
		if src.ID() != "spotify" {
			var tracks []TrackView
			var err error
			if src.Caps().Search {
				tracks, err = src.Search(q, 10)
			} else {
				tracks, err = catalogSearch(q, 10) // songs to put on the request list
			}
			if err != nil {
				jsonOut(w, 502, map[string]string{"error": err.Error()})
				return
			}
			if tracks == nil {
				tracks = []TrackView{}
			}
			jsonOut(w, 200, SearchResult{Tracks: tracks, Playlists: []ListView{}, Albums: []ListView{}})
			return
		}
		res, err := a.sp.Search(q, types, 10)
		if err != nil {
			jsonOut(w, 502, map[string]string{"error": err.Error()})
			return
		}
		jsonOut(w, 200, res)
	}))
	m.HandleFunc("/api/dj/request", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		msg, err := a.MarkRequest(r.FormValue("id"), r.FormValue("action"))
		if err != nil {
			jsonOut(w, 200, map[string]any{"ok": false, "reply": err.Error()})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "reply": msg, "requests": firstN(a.Requests(), 30)})
	}))
	m.HandleFunc("/api/dj/playlists", wrap(func(w http.ResponseWriter, r *http.Request) {
		if a.source().ID() != "spotify" {
			jsonOut(w, 200, []ListView{})
			return
		}
		p, err := a.sp.MyPlaylists()
		if err != nil {
			jsonOut(w, 502, map[string]string{"error": err.Error()})
			return
		}
		jsonOut(w, 200, p)
	}))
	m.HandleFunc("/api/dj/devices", wrap(func(w http.ResponseWriter, r *http.Request) {
		if a.source().ID() != "spotify" {
			jsonOut(w, 200, []Device{})
			return
		}
		if r.Method == "POST" {
			id := r.FormValue("id")
			_, _, err := a.sp.Do("PUT", "/me/player", nil, map[string]any{"device_ids": []string{id}, "play": r.FormValue("play") == "1"})
			if err != nil {
				jsonOut(w, 502, map[string]string{"error": err.Error()})
				return
			}
			a.poke()
		}
		d, err := a.sp.Devices()
		if err != nil {
			jsonOut(w, 502, map[string]string{"error": err.Error()})
			return
		}
		jsonOut(w, 200, d)
	}))
	m.HandleFunc("/api/dj/cmd", wrap(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST only", 405)
			return
		}
		who := r.FormValue("user")
		if who == "" {
			who = "DJ"
		}
		reply, err := a.Command(r.FormValue("c"), r.FormValue("arg"), who)
		if err != nil {
			jsonOut(w, 200, map[string]any{"ok": false, "reply": err.Error()})
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "reply": reply})
	}))
}

func firstN[T any](s []T, n int) []T {
	if len(s) > n {
		return s[:n]
	}
	return s
}

// ---------------- Remote DJ access (quick tunnel or fixed address) ----------------
//
// quick: cloudflared quick tunnel -> new random https://*.trycloudflare.com each time (no account).
// fixed: a permanent address you set up once (Tailscale Funnel, or a Cloudflare named tunnel
//        whose token we run for you). The DJ API only answers while access is "open".

type Tunnel struct {
	a     *App
	mu    sync.Mutex
	cmd   *exec.Cmd
	url   string
	state string // off | starting | on | error
	msg   string
	check string // fixed-address reachability: "", checking, ok, fail
	open  bool
}

var tryCF = regexp.MustCompile(`https://[a-z0-9-]+\.trycloudflare\.com`)
var passkeyRe = regexp.MustCompile(`^[A-Za-z0-9_-]{6,64}$`)

// newPasskey makes a readable random passkey like "nova-7k2m-quasar".
func newPasskey() string {
	words := []string{"nova", "quasar", "pulsar", "comet", "orbit", "vector", "nebula", "zenith", "ion", "flux",
		"echo", "drift", "ember", "halo", "lumen", "rift", "solar", "tide", "volt", "wave"}
	const chars = "abcdefghjkmnpqrstuvwxyz23456789"
	b := make([]byte, 8)
	rand.Read(b)
	mid := make([]byte, 4)
	for i := range mid {
		mid[i] = chars[int(b[i])%len(chars)]
	}
	return words[int(b[4])%len(words)] + "-" + string(mid) + "-" + words[int(b[5])%len(words)]
}

func (t *Tunnel) IsOpen() bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.open
}

func (t *Tunnel) binary() string {
	c := t.a.st.Get()
	cands := []string{c.CloudflaredPath}
	name := "cloudflared"
	if runtime.GOOS == "windows" {
		name = "cloudflared.exe"
		cands = append(cands, filepath.Join(exeDir(), "cloudflared-windows-amd64.exe"))
	}
	cands = append(cands, filepath.Join(exeDir(), name))
	for _, p := range cands {
		if p != "" {
			if _, err := os.Stat(p); err == nil {
				return p
			}
		}
	}
	if p, err := exec.LookPath(name); err == nil {
		return p
	}
	return ""
}

func (t *Tunnel) Status() map[string]any {
	c := t.a.st.Get()
	t.mu.Lock()
	defer t.mu.Unlock()
	st := t.state
	if st == "" {
		st = "off"
	}
	base := t.url
	if c.DJMode == "fixed" {
		base = c.DJFixedURL // the link is the same whether open or closed, so mods can bookmark it
	}
	link, linkKey := "", ""
	if base != "" {
		link = base + "/"
		linkKey = base + "/#key=" + url.QueryEscape(c.DJKey)
	}
	return map[string]any{"state": st, "open": t.open, "url": base, "djUrl": link, "djUrlWithKey": linkKey,
		"msg": t.msg, "check": t.check, "found": t.binary() != "", "mode": c.DJMode}
}

func (t *Tunnel) Start() {
	c := t.a.st.Get()
	t.mu.Lock()
	if t.open && (t.cmd != nil || c.DJMode == "fixed") {
		t.mu.Unlock()
		return
	}
	if c.DJMode == "fixed" {
		if c.DJFixedURL == "" {
			t.state, t.msg = "error", "Add your permanent DJ address first."
			t.mu.Unlock()
			return
		}
		t.open, t.url = true, c.DJFixedURL
		if c.DJTunnelTok == "" {
			// Tailscale Funnel (or anything else you run yourself) is already forwarding to the DJ port.
			t.state, t.msg = "on", "DJ access is open on your fixed address."
			t.mu.Unlock()
			log.Println("Remote DJ open on", c.DJFixedURL)
			go t.verify(c.DJFixedURL)
			return
		}
		bin := t.binary()
		if bin == "" {
			t.open = false
			t.state, t.msg = "error", "cloudflared.exe not found — put it next to HyperwaveStation.exe"
			t.mu.Unlock()
			return
		}
		cmd := exec.Command(bin, "tunnel", "--no-autoupdate", "run", "--token", c.DJTunnelTok)
		t.launch(cmd, "connecting your Cloudflare tunnel…")
		return
	}
	bin := t.binary()
	if bin == "" {
		t.state, t.msg = "error", "cloudflared.exe not found — put it next to HyperwaveStation.exe"
		t.mu.Unlock()
		return
	}
	t.open = true
	cmd := exec.Command(bin, "tunnel", "--no-autoupdate", "--url", fmt.Sprintf("http://127.0.0.1:%d", c.DJPort))
	t.url = ""
	t.launch(cmd, "opening a link… this takes about 5–15 seconds.")
}

// launch runs cloudflared; caller holds t.mu (released here).
func (t *Tunnel) launch(cmd *exec.Cmd, msg string) {
	hideWindow(cmd)
	stderr, _ := cmd.StderrPipe()
	cmd.Stdout = cmd.Stderr
	if err := cmd.Start(); err != nil {
		t.open = false
		t.state, t.msg = "error", err.Error()
		t.mu.Unlock()
		return
	}
	t.cmd, t.state, t.msg = cmd, "starting", msg
	t.mu.Unlock()
	log.Println("Remote DJ tunnel starting…")
	go func() {
		sc := bufio.NewScanner(stderr)
		for sc.Scan() {
			line := sc.Text()
			t.mu.Lock()
			if t.cmd == cmd && t.state == "starting" {
				if u := tryCF.FindString(line); u != "" && t.a.st.Get().DJMode != "fixed" {
					t.url, t.state, t.msg = u, "on", "DJ access is open."
					log.Println("Remote DJ link is live:", u)
				} else if strings.Contains(line, "Registered tunnel connection") {
					t.state, t.msg = "on", "DJ access is open on your fixed address."
					log.Println("Remote DJ open on", t.url)
				} else if strings.Contains(line, "Unauthorized") || strings.Contains(line, "invalid token") {
					t.msg = "Cloudflare rejected the tunnel token — copy it again from the Cloudflare dashboard."
				}
			}
			t.mu.Unlock()
		}
	}()
	go func() {
		err := cmd.Wait()
		t.mu.Lock()
		if t.cmd == cmd {
			t.cmd, t.open = nil, false
			if t.a.st.Get().DJMode != "fixed" {
				t.url = ""
			}
			if t.state != "off" {
				t.state = "error"
				if t.msg == "" || !strings.Contains(t.msg, "token") {
					t.msg = "The tunnel stopped"
					if err != nil {
						t.msg += ": " + err.Error()
					}
				}
			}
		}
		t.mu.Unlock()
	}()
}

// verify fetches /api/dj/ping through the fixed address to prove it reaches this PC.
func (t *Tunnel) verify(base string) {
	t.mu.Lock()
	t.check = "checking"
	t.mu.Unlock()
	n := newKey()
	ok := false
	cl := &http.Client{Timeout: 10 * time.Second}
	if res, err := cl.Get(base + "/api/dj/ping?n=" + n); err == nil {
		b, _ := io.ReadAll(io.LimitReader(res.Body, 4096))
		res.Body.Close()
		ok = strings.Contains(string(b), n)
	}
	t.mu.Lock()
	if ok {
		t.check = "ok"
	} else {
		t.check = "fail"
	}
	t.mu.Unlock()
}

func (t *Tunnel) Stop() {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.open = false
	t.state, t.msg, t.check = "off", "", ""
	if t.a.st.Get().DJMode != "fixed" {
		t.url = ""
	}
	if t.cmd != nil && t.cmd.Process != nil {
		t.cmd.Process.Kill()
	}
	t.cmd = nil
	log.Println("Remote DJ access closed.")
}

// ---------------- main ----------------

func openBrowser(u string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", u).Start()
	case "darwin":
		exec.Command("open", u).Start()
	default:
		exec.Command("xdg-open", u).Start()
	}
}

func main() {
	log.SetFlags(log.Ltime)
	st := loadStore()
	a := NewApp(st)
	a.tun = &Tunnel{a: a}
	a.chat = &ChatHub{a: a}
	c := st.Get()

	printBanner(c, st.path)

	go a.Poller()
	a.chat.Restart()
	a.obs.Restart()
	a.sb.Restart()
	a.tik.Restart()
	a.lan.Restart()

	djSrv := &http.Server{Addr: fmt.Sprintf("127.0.0.1:%d", c.DJPort), Handler: a.DJMux(), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		if err := djSrv.ListenAndServe(); err != nil {
			log.Println("DJ server:", err)
		}
	}()
	if c.DJAutoOpen {
		a.tun.Start()
	}
	ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", c.Port))
	if err != nil {
		log.Printf("Port %d is busy — is Hyperwave Station already running? (%v)", c.Port, err)
		openBrowser(fmt.Sprintf("http://127.0.0.1:%d", c.Port))
		time.Sleep(6 * time.Second)
		os.Exit(1)
	}
	if os.Getenv("HWS_NO_BROWSER") == "" {
		go openBrowser(fmt.Sprintf("http://127.0.0.1:%d", c.Port))
	}
	srv := &http.Server{Handler: a.LocalMux(), ReadHeaderTimeout: 10 * time.Second}
	log.Fatal(srv.Serve(ln))
}

var _ = strconv.Itoa
